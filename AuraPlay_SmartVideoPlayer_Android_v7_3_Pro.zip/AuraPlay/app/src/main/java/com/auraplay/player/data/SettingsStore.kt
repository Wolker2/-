package com.auraplay.player.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.DialogueBalancerStrength
import com.auraplay.player.audio.EqualizerPreset
import com.auraplay.player.audio.NormalizationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "auraplay_settings_v6")

class SettingsStore(private val context: Context) {

    private object Keys {
        val MODE = stringPreferencesKey("norm_mode")
        val TARGET_LUFS = floatPreferencesKey("target_lufs")
        val MAX_BOOST_DB = floatPreferencesKey("max_boost_db")
        val TRUE_PEAK_CEILING = floatPreferencesKey("true_peak_ceiling")
        val DIALOGUE_BAL_ENABLED = booleanPreferencesKey("dialogue_bal_enabled")
        val DIALOGUE_BAL_STRENGTH = stringPreferencesKey("dialogue_bal_strength")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_PRESET = stringPreferencesKey("eq_preset")
        val EQ_BANDS = stringPreferencesKey("eq_bands")

        val BACK_TO_HOME = booleanPreferencesKey("back_returns_to_home")
        val AUTO_NEXT = booleanPreferencesKey("auto_play_next_episode")
        val REMEMBER_POS = booleanPreferencesKey("remember_position")
        val BEST_QUALITY = booleanPreferencesKey("always_best_quality")
        val AUTO_FRAME_RATE = booleanPreferencesKey("auto_frame_rate")
        val DECODER_MODE = stringPreferencesKey("decoder_mode")
        val PREF_AUDIO_LANG = stringPreferencesKey("pref_audio_lang")
        val AUTO_DISABLE_SUBS = booleanPreferencesKey("auto_disable_subs")
        val AUDIO_DELAY_MS = intPreferencesKey("audio_delay_ms")
        val SEEK_STEP = intPreferencesKey("seek_step_seconds")
        val SUB_SIZE = stringPreferencesKey("subtitle_size")
        val SUB_BG = booleanPreferencesKey("subtitle_background")
        val SAVED_STREAMS = stringPreferencesKey("saved_streams")
        val WATCHED_EPISODES = stringSetPreferencesKey("watched_episodes")
    }

    val audioSettings: Flow<AudioNormalizationSettings> = context.dataStore.data.map { prefs ->
        val mode = prefs[Keys.MODE]?.let { runCatching { NormalizationMode.valueOf(it) }.getOrNull() }
            ?: NormalizationMode.STUDIO
        val balStrength = prefs[Keys.DIALOGUE_BAL_STRENGTH]
            ?.let { runCatching { DialogueBalancerStrength.valueOf(it) }.getOrNull() }
            ?: DialogueBalancerStrength.STANDARD
        val eqPreset = prefs[Keys.EQ_PRESET]?.let { runCatching { EqualizerPreset.valueOf(it) }.getOrNull() }
            ?: EqualizerPreset.FLAT
        val bands = prefs[Keys.EQ_BANDS]?.split(",")?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == 5 } ?: eqPreset.bandsDb
        AudioNormalizationSettings(
            mode = mode,
            targetLufs = prefs[Keys.TARGET_LUFS] ?: mode.defaultTargetLufs,
            maxBoostDb = prefs[Keys.MAX_BOOST_DB] ?: mode.defaultMaxBoostDb,
            truePeakCeilingDb = prefs[Keys.TRUE_PEAK_CEILING] ?: -1.0f,
            dialogueBalancerEnabled = prefs[Keys.DIALOGUE_BAL_ENABLED] ?: true,
            dialogueBalancerStrength = balStrength,
            eqEnabled = prefs[Keys.EQ_ENABLED] ?: false,
            eqPreset = eqPreset,
            eqBandsDb = bands
        )
    }.distinctUntilChanged()

    val playerPrefs: Flow<PlayerPreferences> = context.dataStore.data.map { prefs ->
        val decMode = prefs[Keys.DECODER_MODE]?.let { runCatching { DecoderMode.valueOf(it) }.getOrNull() }
            ?: DecoderMode.STANDARD
        val prefLang = prefs[Keys.PREF_AUDIO_LANG]?.let { runCatching { PreferredAudioLanguage.valueOf(it) }.getOrNull() }
            ?: PreferredAudioLanguage.AUTO
        val subSize = prefs[Keys.SUB_SIZE]?.let { runCatching { SubtitleSize.valueOf(it) }.getOrNull() }
            ?: SubtitleSize.LARGE
        val streams = prefs[Keys.SAVED_STREAMS]?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()

        PlayerPreferences(
            backReturnsToHome = prefs[Keys.BACK_TO_HOME] ?: false,
            autoPlayNextEpisode = prefs[Keys.AUTO_NEXT] ?: true,
            rememberPosition = prefs[Keys.REMEMBER_POS] ?: true,
            alwaysBestQuality = prefs[Keys.BEST_QUALITY] ?: true,
            autoFrameRate = prefs[Keys.AUTO_FRAME_RATE] ?: false,
            decoderMode = decMode,
            preferredAudioLanguage = prefLang,
            autoDisableSubtitles = prefs[Keys.AUTO_DISABLE_SUBS] ?: false,
            audioDelayMs = prefs[Keys.AUDIO_DELAY_MS] ?: 0,
            seekStepSeconds = prefs[Keys.SEEK_STEP] ?: 10,
            subtitleSize = subSize,
            subtitleBackground = prefs[Keys.SUB_BG] ?: true,
            savedStreams = streams
        )
    }.distinctUntilChanged()

    suspend fun saveAudioSettings(settings: AudioNormalizationSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MODE] = settings.mode.name
            prefs[Keys.TARGET_LUFS] = settings.targetLufs
            prefs[Keys.MAX_BOOST_DB] = settings.maxBoostDb
            prefs[Keys.TRUE_PEAK_CEILING] = settings.truePeakCeilingDb
            prefs[Keys.DIALOGUE_BAL_ENABLED] = settings.dialogueBalancerEnabled
            prefs[Keys.DIALOGUE_BAL_STRENGTH] = settings.dialogueBalancerStrength.name
            prefs[Keys.EQ_ENABLED] = settings.eqEnabled
            prefs[Keys.EQ_PRESET] = settings.eqPreset.name
            prefs[Keys.EQ_BANDS] = settings.eqBandsDb.joinToString(",")
        }
    }

    suspend fun savePlayerPrefs(p: PlayerPreferences) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BACK_TO_HOME] = p.backReturnsToHome
            prefs[Keys.AUTO_NEXT] = p.autoPlayNextEpisode
            prefs[Keys.REMEMBER_POS] = p.rememberPosition
            prefs[Keys.BEST_QUALITY] = p.alwaysBestQuality
            prefs[Keys.AUTO_FRAME_RATE] = p.autoFrameRate
            prefs[Keys.DECODER_MODE] = p.decoderMode.name
            prefs[Keys.PREF_AUDIO_LANG] = p.preferredAudioLanguage.name
            prefs[Keys.AUTO_DISABLE_SUBS] = p.autoDisableSubtitles
            prefs[Keys.AUDIO_DELAY_MS] = p.audioDelayMs
            prefs[Keys.SEEK_STEP] = p.seekStepSeconds
            prefs[Keys.SUB_SIZE] = p.subtitleSize.name
            prefs[Keys.SUB_BG] = p.subtitleBackground
            prefs[Keys.SAVED_STREAMS] = p.savedStreams.distinct().take(15).joinToString("\n")
        }
    }

    suspend fun savePosition(mediaKey: String, positionMs: Long) {
        val key = longPreferencesKey("pos_${mediaKey.hashCode()}")
        context.dataStore.edit { prefs ->
            if (positionMs <= 0L) prefs.remove(key) else prefs[key] = positionMs
        }
    }

    val watchedEpisodes: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[Keys.WATCHED_EPISODES] ?: emptySet()
    }.distinctUntilChanged()

    suspend fun getSavedPosition(mediaKey: String): Long {
        val key = longPreferencesKey("pos_${mediaKey.hashCode()}")
        return context.dataStore.data.first()[key] ?: 0L
    }

    suspend fun markEpisodeWatched(watchKey: String) {
        if (watchKey.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.WATCHED_EPISODES] ?: emptySet()
            if (watchKey !in current) {
                val updated = (current.toList() + watchKey).takeLast(500).toSet()
                prefs[Keys.WATCHED_EPISODES] = updated
            }
        }
    }

    suspend fun saveSavedStreams(streams: List<String>) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SAVED_STREAMS] = streams.distinct().take(15).joinToString("\n")
        }
    }
}
