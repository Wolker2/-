package com.auraplay.player.engine

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.auraplay.player.audio.SmartLoudnessAudioProcessor
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory

/**
 * Combines NextLib's FFmpeg + dav1d (AV1) + libass (ASS/SSA) decoders with our
 * 32-bit float SmartLoudnessAudioProcessor directly inside the ExoPlayer AudioSink.
 */
@OptIn(UnstableApi::class)
class SmartAudioRenderersFactory(
    context: Context,
    private val smartLoudnessProcessor: SmartLoudnessAudioProcessor
) : NextRenderersFactory(context) {

    init {
        setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        setEnableDecoderFallback(true)
    }

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink {
        return DefaultAudioSink.Builder(context)
            .setEnableFloatOutput(true) // Keep 32-bit float PCM end-to-end
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessors(arrayOf(smartLoudnessProcessor))
            .build()
    }
}
