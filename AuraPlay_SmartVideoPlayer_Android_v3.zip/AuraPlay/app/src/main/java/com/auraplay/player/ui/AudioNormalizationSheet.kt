package com.auraplay.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.AudioTelemetry
import com.auraplay.player.audio.NormalizationMode
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioNormalizationSheet(
    settings: AudioNormalizationSettings,
    telemetry: AudioTelemetry,
    onSelectMode: (NormalizationMode) -> Unit,
    onTargetLufsChange: (Float) -> Unit,
    onMaxBoostChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Умная автонормализация аудио",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = if (telemetry.isFloatPipeline) {
                    "Тракт: 32-bit Float PCM • ${telemetry.sampleRateHz / 1000} кГц • ${telemetry.channelCount}ch • EBU R128 + Look-Ahead Limiter"
                } else {
                    "Тракт: PCM • ${telemetry.sampleRateHz / 1000} кГц • ${telemetry.channelCount}ch • EBU R128 + Look-Ahead Limiter"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )

            Spacer(Modifier.height(14.dp))

            // Live DSP Telemetry Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryMetric(
                    label = "Громкость",
                    value = String.format(Locale.US, "%.1f LUFS", telemetry.shortTermLufs)
                )
                TelemetryMetric(
                    label = "Усиление",
                    value = String.format(Locale.US, "%+.1f дБ", telemetry.appliedGainDb),
                    valueColor = MaterialTheme.colorScheme.primary
                )
                TelemetryMetric(
                    label = "Лимитер",
                    value = String.format(Locale.US, "%.1f дБ", telemetry.limiterReductionDb),
                    valueColor = if (telemetry.limiterReductionDb < -0.5f) Color(0xFFFFB74D) else MaterialTheme.colorScheme.onSurface
                )
                TelemetryMetric(
                    label = "True Peak",
                    value = String.format(Locale.US, "%.1f дБ", telemetry.truePeakDbtp)
                )
            }

            Spacer(Modifier.height(16.dp))

            // Mode Cards
            NormalizationMode.entries.forEach { mode ->
                val isSelected = settings.mode == mode
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        )
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelectMode(mode) }
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = mode.titleRu,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = mode.descriptionRu,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (settings.mode != NormalizationMode.BYPASS) {
                Spacer(Modifier.height(14.dp))
                Text(
                    text = String.format(Locale.US, "Целевая громкость: %.1f LUFS", settings.targetLufs),
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = settings.targetLufs,
                    onValueChange = onTargetLufsChange,
                    valueRange = -23.0f..-11.0f
                )

                Text(
                    text = String.format(Locale.US, "Макс. усиление тихих сцен: +%.1f дБ", settings.maxBoostDb),
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = settings.maxBoostDb,
                    onValueChange = onMaxBoostChange,
                    valueRange = 0.0f..18.0f
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TelemetryMetric(
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = valueColor
        )
    }
}
