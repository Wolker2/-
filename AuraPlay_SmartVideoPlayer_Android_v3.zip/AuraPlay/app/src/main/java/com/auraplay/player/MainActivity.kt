package com.auraplay.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import com.auraplay.player.ui.AudioNormalizationSheet
import com.auraplay.player.ui.HomeScreen
import com.auraplay.player.ui.PlayerScreen
import com.auraplay.player.ui.PlayerViewModel
import com.auraplay.player.ui.theme.AuraPlayTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        setContent {
            AuraPlayTheme {
                val videos by viewModel.videos.collectAsState()
                val uiState by viewModel.uiState.collectAsState()
                val audioSettings by viewModel.audioSettings.collectAsState()
                val telemetry by viewModel.telemetry.collectAsState()

                var showAudioSheet by remember { mutableStateOf(false) }
                val storagePermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Manifest.permission.READ_MEDIA_VIDEO
                } else {
                    Manifest.permission.READ_EXTERNAL_STORAGE
                }

                var hasPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(this, storagePermission) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { granted ->
                    hasPermission = granted
                    if (granted) viewModel.refreshLocalVideos()
                }

                val filePickerLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    if (uri != null) {
                        runCatching {
                            contentResolver.takePersistableUriPermission(
                                uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                        viewModel.playMedia(uri, resolveDisplayName(uri))
                    }
                }

                LaunchedEffect(hasPermission) {
                    if (hasPermission) viewModel.refreshLocalVideos()
                }

                val isPlayerOpen = uiState.currentUri != null
                LaunchedEffect(isPlayerOpen) {
                    setImmersiveSystemBars(isPlayerOpen)
                }

                if (isPlayerOpen) {
                    BackHandler { viewModel.closePlayer() }
                    PlayerScreen(
                        exoPlayer = viewModel.exoPlayer,
                        uiState = uiState,
                        audioSettings = audioSettings,
                        telemetry = telemetry,
                        onBack = { viewModel.closePlayer() },
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSeekTo = { viewModel.seekTo(it) },
                        onSeekBy = { viewModel.seekBy(it) },
                        onSpeedChange = { viewModel.setPlaybackSpeed(it) },
                        onOpenAudioSheet = { showAudioSheet = true },
                        onSelectAudioTrack = { viewModel.selectTrack(C.TRACK_TYPE_AUDIO, it) },
                        onSelectSubtitleTrack = { viewModel.selectTrack(C.TRACK_TYPE_TEXT, it) }
                    )
                } else {
                    HomeScreen(
                        videos = videos,
                        audioSettings = audioSettings,
                        hasStoragePermission = hasPermission,
                        onRequestPermission = { permissionLauncher.launch(storagePermission) },
                        onRefresh = { viewModel.refreshLocalVideos() },
                        onPickFile = { filePickerLauncher.launch(arrayOf("video/*", "*/*")) },
                        onOpenUrl = { uri, title -> viewModel.playMedia(uri, title) },
                        onSelectVideo = { viewModel.playMedia(it.uri, it.title) },
                        onOpenAudioSettings = { showAudioSheet = true }
                    )
                }

                if (showAudioSheet) {
                    AudioNormalizationSheet(
                        settings = audioSettings,
                        telemetry = telemetry,
                        onSelectMode = { viewModel.setNormalizationMode(it) },
                        onTargetLufsChange = { viewModel.updateTargetLufs(it) },
                        onMaxBoostChange = { viewModel.updateMaxBoostDb(it) },
                        onDismiss = { showAudioSheet = false }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { uri ->
                viewModel.playMedia(uri, resolveDisplayName(uri))
            }
        }
    }

    private fun resolveDisplayName(uri: Uri): String {
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val name = cursor.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast("/") ?: "Видео"
    }

    private fun setImmersiveSystemBars(immersive: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (immersive) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
