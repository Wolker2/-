package com.auraplay.player.audio

enum class NormalizationMode(
    val titleRu: String,
    val descriptionRu: String,
    val defaultTargetLufs: Float,
    val defaultMaxBoostDb: Float,
    val attackMs: Float,
    val releaseMs: Float,
    val enableVoicePresenceEq: Boolean
) {
    STUDIO(
        titleRu = "Студийный (Прозрачный)",
        descriptionRu = "EBU R128 -16 LUFS, 32-bit float, плавное выравнивание без накачки",
        defaultTargetLufs = -16.0f,
        defaultMaxBoostDb = 9.0f,
        attackMs = 350f,
        releaseMs = 2500f,
        enableVoicePresenceEq = false
    ),
    NIGHT(
        titleRu = "Ночной кинотеатр",
        descriptionRu = "Подтягивает тихие диалоги и мягко сдерживает взрывы (-14 LUFS)",
        defaultTargetLufs = -14.0f,
        defaultMaxBoostDb = 14.0f,
        attackMs = 120f,
        releaseMs = 1100f,
        enableVoicePresenceEq = false
    ),
    VOICE(
        titleRu = "Чёткая речь",
        descriptionRu = "Выравнивание громкости + мягкий акцент на разборчивости голоса (2.4 кГц)",
        defaultTargetLufs = -15.0f,
        defaultMaxBoostDb = 11.0f,
        attackMs = 200f,
        releaseMs = 1500f,
        enableVoicePresenceEq = true
    ),
    BYPASS(
        titleRu = "Выкл (Оригинал)",
        descriptionRu = "Прямой битовый вывод без обработки для мгновенного сравнения",
        defaultTargetLufs = -16.0f,
        defaultMaxBoostDb = 0.0f,
        attackMs = 350f,
        releaseMs = 2500f,
        enableVoicePresenceEq = false
    )
}

data class AudioNormalizationSettings(
    val mode: NormalizationMode = NormalizationMode.STUDIO,
    val targetLufs: Float = NormalizationMode.STUDIO.defaultTargetLufs,
    val maxBoostDb: Float = NormalizationMode.STUDIO.defaultMaxBoostDb,
    val truePeakCeilingDb: Float = -1.0f,
    val silenceGateLufs: Float = -55.0f
)

data class AudioTelemetry(
    val momentaryLufs: Float = -70f,
    val shortTermLufs: Float = -70f,
    val appliedGainDb: Float = 0f,
    val limiterReductionDb: Float = 0f,
    val truePeakDbtp: Float = -70f,
    val sampleRateHz: Int = 48000,
    val channelCount: Int = 2,
    val isFloatPipeline: Boolean = true,
    val mode: NormalizationMode = NormalizationMode.STUDIO
)
