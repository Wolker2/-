package com.auraplay.player.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.NormalizationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "auraplay_settings")

class SettingsStore(private val context: Context) {

    private object Keys {
        val MODE = stringPreferencesKey("norm_mode")
        val TARGET_LUFS = floatPreferencesKey("target_lufs")
        val MAX_BOOST_DB = floatPreferencesKey("max_boost_db")
        val TRUE_PEAK_CEILING = floatPreferencesKey("true_peak_ceiling")
    }

    val audioSettings: Flow<AudioNormalizationSettings> = context.dataStore.data.map { prefs ->
        val mode = prefs[Keys.MODE]?.let {
            runCatching { NormalizationMode.valueOf(it) }.getOrNull()
        } ?: NormalizationMode.STUDIO
        AudioNormalizationSettings(
            mode = mode,
            targetLufs = prefs[Keys.TARGET_LUFS] ?: mode.defaultTargetLufs,
            maxBoostDb = prefs[Keys.MAX_BOOST_DB] ?: mode.defaultMaxBoostDb,
            truePeakCeilingDb = prefs[Keys.TRUE_PEAK_CEILING] ?: -1.0f
        )
    }

    suspend fun saveAudioSettings(settings: AudioNormalizationSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MODE] = settings.mode.name
            prefs[Keys.TARGET_LUFS] = settings.targetLufs
            prefs[Keys.MAX_BOOST_DB] = settings.maxBoostDb
            prefs[Keys.TRUE_PEAK_CEILING] = settings.truePeakCeilingDb
        }
    }
}
