package com.auraplay.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AuraDarkColors = darkColorScheme(
    primary = Color(0xFF4F9CFF),
    onPrimary = Color(0xFF001C3B),
    secondary = Color(0xFF38D9A9),
    onSecondary = Color(0xFF002117),
    background = Color(0xFF0D0F14),
    onBackground = Color(0xFFE8ECF4),
    surface = Color(0xFF151922),
    onSurface = Color(0xFFE8ECF4),
    surfaceVariant = Color(0xFF1F2533),
    onSurfaceVariant = Color(0xFF9BA5B7),
    error = Color(0xFFFF6B6B)
)

@Composable
fun AuraPlayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AuraDarkColors,
        content = content
    )
}
