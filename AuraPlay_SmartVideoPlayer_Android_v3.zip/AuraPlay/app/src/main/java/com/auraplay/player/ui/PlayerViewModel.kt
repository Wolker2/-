package com.auraplay.player.ui

import android.app.Application
import android.net.Uri
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.AudioTelemetry
import com.auraplay.player.audio.NormalizationMode
import com.auraplay.player.audio.SmartLoudnessAudioProcessor
import com.auraplay.player.data.LocalVideoRepository
import com.auraplay.player.data.SettingsStore
import com.auraplay.player.data.VideoItem
import com.auraplay.player.engine.SmartAudioRenderersFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class TrackOption(
    val id: String,
    val label: String,
    val groupIndex: Int,
    val trackIndex: Int,
    val isSelected: Boolean
)

data class PlayerUiState(
    val currentTitle: String = "",
    val currentUri: Uri? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val audioTracks: List<TrackOption> = emptyList(),
    val subtitleTracks: List<TrackOption> = emptyList(),
    val videoCodecInfo: String = "",
    val audioCodecInfo: String = "",
    val errorMessage: String? = null
)

@OptIn(UnstableApi::class)
class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsStore = SettingsStore(application)
    val smartAudioProcessor = SmartLoudnessAudioProcessor()

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(application)
        .setRenderersFactory(SmartAudioRenderersFactory(application, smartAudioProcessor))
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            true
        )
        .setHandleAudioBecomingNoisy(true)
        .build()

    private val _videos = MutableStateFlow<List<VideoItem>>(emptyList())
    val videos: StateFlow<List<VideoItem>> = _videos.asStateFlow()

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val _audioSettings = MutableStateFlow(AudioNormalizationSettings())
    val audioSettings: StateFlow<AudioNormalizationSettings> = _audioSettings.asStateFlow()

    val telemetry: StateFlow<AudioTelemetry> = smartAudioProcessor.telemetry

    init {
        viewModelScope.launch {
            val saved = settingsStore.audioSettings.first()
            _audioSettings.value = saved
            smartAudioProcessor.updateSettings(saved)
        }

        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
            }

            override fun onPlaybackStateChanged(state: Int) {
                _uiState.value = _uiState.value.copy(
                    isBuffering = state == Player.STATE_BUFFERING,
                    durationMs = exoPlayer.duration.coerceAtLeast(0L)
                )
            }

            override fun onTracksChanged(tracks: Tracks) {
                parseTracks(tracks)
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Ошибка воспроизведения: ${error.localizedMessage ?: error.errorCodeName}"
                )
            }
        })

        // Periodic position polling while playing
        viewModelScope.launch {
            while (true) {
                if (_uiState.value.currentUri != null) {
                    _uiState.value = _uiState.value.copy(
                        positionMs = exoPlayer.currentPosition.coerceAtLeast(0L),
                        durationMs = exoPlayer.duration.coerceAtLeast(0L)
                    )
                }
                delay(250)
            }
        }
    }

    fun refreshLocalVideos() {
        viewModelScope.launch {
            _videos.value = LocalVideoRepository.loadDeviceVideos(getApplication())
        }
    }

    fun playMedia(uri: Uri, title: String) {
        _uiState.value = _uiState.value.copy(
            currentUri = uri,
            currentTitle = title,
            errorMessage = null
        )
        exoPlayer.setMediaItem(MediaItem.fromUri(uri))
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    fun closePlayer() {
        exoPlayer.pause()
        exoPlayer.stop()
        _uiState.value = PlayerUiState()
    }

    fun togglePlayPause() {
        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
    }

    fun seekTo(positionMs: Long) {
        val clamped = positionMs.coerceIn(0L, exoPlayer.duration.coerceAtLeast(0L))
        exoPlayer.seekTo(clamped)
        _uiState.value = _uiState.value.copy(positionMs = clamped)
    }

    fun seekBy(deltaMs: Long) {
        seekTo(exoPlayer.currentPosition + deltaMs)
    }

    fun setPlaybackSpeed(speed: Float) {
        exoPlayer.setPlaybackSpeed(speed)
        _uiState.value = _uiState.value.copy(playbackSpeed = speed)
    }

    fun setNormalizationMode(mode: NormalizationMode) {
        val updated = _audioSettings.value.copy(
            mode = mode,
            targetLufs = mode.defaultTargetLufs,
            maxBoostDb = mode.defaultMaxBoostDb
        )
        applyAudioSettings(updated)
    }

    fun updateTargetLufs(lufs: Float) {
        applyAudioSettings(_audioSettings.value.copy(targetLufs = lufs))
    }

    fun updateMaxBoostDb(maxBoost: Float) {
        applyAudioSettings(_audioSettings.value.copy(maxBoostDb = maxBoost))
    }

    private fun applyAudioSettings(settings: AudioNormalizationSettings) {
        _audioSettings.value = settings
        smartAudioProcessor.updateSettings(settings)
        viewModelScope.launch { settingsStore.saveAudioSettings(settings) }
    }

    fun selectTrack(type: Int, option: TrackOption?) {
        val paramsBuilder = exoPlayer.trackSelectionParameters.buildUpon()
        if (option == null) {
            paramsBuilder.setTrackTypeDisabled(type, true)
        } else {
            paramsBuilder.setTrackTypeDisabled(type, false)
            val groups = exoPlayer.currentTracks.groups
            if (option.groupIndex in groups.indices) {
                val mediaGroup = groups[option.groupIndex].mediaTrackGroup
                paramsBuilder.setOverrideForType(
                    TrackSelectionOverride(mediaGroup, listOf(option.trackIndex))
                )
            }
        }
        exoPlayer.trackSelectionParameters = paramsBuilder.build()
    }

    private fun parseTracks(tracks: Tracks) {
        val audioList = mutableListOf<TrackOption>()
        val subList = mutableListOf<TrackOption>()
        var vInfo = ""
        var aInfo = ""

        tracks.groups.forEachIndexed { gIdx, group ->
            for (tIdx in 0 until group.length) {
                val format = group.getTrackFormat(tIdx)
                val selected = group.isTrackSelected(tIdx)
                when (group.type) {
                    C.TRACK_TYPE_VIDEO -> if (selected) {
                        val codec = format.sampleMimeType?.substringAfter("/")?.uppercase() ?: "VIDEO"
                        vInfo = "$codec ${format.width}x${format.height}"
                    }
                    C.TRACK_TYPE_AUDIO -> {
                        val lang = format.language?.uppercase() ?: "UND"
                        val ch = if (format.channelCount > 0) "${format.channelCount}ch" else ""
                        val codec = format.sampleMimeType?.substringAfter("/")?.uppercase() ?: "AUDIO"
                        val label = listOfNotNull(
                            format.label,
                            "$lang • $codec $ch".trim()
                        ).joinToString(" — ")
                        audioList.add(TrackOption("a_${gIdx}_$tIdx", label, gIdx, tIdx, selected))
                        if (selected) {
                            aInfo = "$codec ${format.sampleRate / 1000}kHz $ch".trim()
                        }
                    }
                    C.TRACK_TYPE_TEXT -> {
                        val lang = format.language?.uppercase() ?: "SUB"
                        val label = format.label ?: "Субтитры ($lang)"
                        subList.add(TrackOption("s_${gIdx}_$tIdx", label, gIdx, tIdx, selected))
                    }
                }
            }
        }

        _uiState.value = _uiState.value.copy(
            audioTracks = audioList,
            subtitleTracks = subList,
            videoCodecInfo = vInfo,
            audioCodecInfo = aInfo
        )
    }

    override fun onCleared() {
        super.onCleared()
        exoPlayer.release()
    }
}
