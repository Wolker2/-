package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение телевизора/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная плавность и стабильность, только встроенные кодеки устройства"
    )
}

enum class PictureEnhanceMode(
    val titleRu: String,
    val descriptionRu: String
) {
    OFF(
        "Отключить",
        "Чистая оригинальная картинка с заводской гаммой и сочностью телевизора (прямой SurfaceView)"
    ),
    CLARITY(
        "Чёткость",
        "Увеличенная чёткость и резкость контуров и мелких деталей с сохранением сочности картинки"
    ),
    MANUAL(
        "Ручная настройка",
        "Тонкая ручная настройка насыщенности, чёткости, резкости, яркости, чёрного и светлого"
    )
}

data class ManualPictureSettings(
    val saturationPct: Int = 10,    // -50 .. +50 (%)
    val clarityPct: Int = 20,       //   0 .. +50 (%)
    val sharpnessPct: Int = 15,     //   0 .. +50 (%)
    val brightnessPct: Int = 0,     // -30 .. +30 (%)
    val blackEnhancePct: Int = 0,   // -30 .. +30 (+ глубже чёрный, - осветлить тени)
    val whiteEnhancePct: Int = 0    // -30 .. +30 (- мягче пересветы, + ярче светлое)
)

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceMode: PictureEnhanceMode = PictureEnhanceMode.OFF,
    val manualPicture: ManualPictureSettings = ManualPictureSettings(),
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
