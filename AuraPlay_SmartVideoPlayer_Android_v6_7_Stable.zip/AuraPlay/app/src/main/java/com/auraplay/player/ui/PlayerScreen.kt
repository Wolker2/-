package com.auraplay.player.ui

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.view.ViewGroup
import android.content.Context
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.media.AudioManager
import android.os.Build
import android.view.KeyEvent
import android.view.LayoutInflater
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import com.auraplay.player.R
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.AudioTelemetry
import com.auraplay.player.data.DecoderMode
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.data.VideoItem
import com.auraplay.player.ui.theme.tvFocusBorder
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

private enum class HudMode {
    HIDDEN,
    FULL,
    QUICK_BAR,
    SEEK_BAR
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    exoPlayer: ExoPlayer,
    uiState: PlayerUiState,
    audioSettings: AudioNormalizationSettings,
    playerPrefs: PlayerPreferences,
    telemetryFlow: StateFlow<AudioTelemetry>,
    onBackPressed: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSelectDecoderMode: (DecoderMode) -> Unit,
    onSelectEpisode: (VideoItem) -> Unit,
    onPlayNextEpisode: () -> Unit,
    onPlayPrevEpisode: () -> Unit,
    onCancelNextCountdown: () -> Unit,
    onOpenAudioSheet: () -> Unit,
    onOpenSettingsSheet: () -> Unit,
    onSelectVideoTrack: (TrackOption?) -> Unit,
    onSelectAudioTrack: (TrackOption?) -> Unit,
    onSelectSubtitleTrack: (TrackOption?) -> Unit
) {
    val context = LocalContext.current
    var hudMode by remember { mutableStateOf(HudMode.FULL) }
    var interactionTick by remember { mutableIntStateOf(0) }
    var gestureHudText by remember { mutableStateOf<String?>(null) }
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    val toggleOrientationFullscreen: () -> Unit = {
        val activity = context as? Activity
        if (activity != null) {
            if (isLandscape) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                gestureHudText = "Вертикальный экран"
            } else {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                gestureHudText = "Полный экран (альбомный)"
            }
        }
    }

    // OK-button anti-double-click guard
    var swallowNextOkKeyUp by remember { mutableStateOf(false) }
    var lastHudRevealMs by remember { mutableLongStateOf(0L) }

    // Fast-seek state
    var isFastSeeking by remember { mutableStateOf(false) }
    var fastSeekTargetMs by remember { mutableLongStateOf(0L) }
    var fastSeekAccumulatedSec by remember { mutableIntStateOf(0) }
    var lastSeekPressMs by remember { mutableLongStateOf(0L) }
    var rapidSeekStreak by remember { mutableIntStateOf(0) }
    var seekCommitTick by remember { mutableIntStateOf(0) }

    var quickBarFocusedLabel by remember { mutableStateOf("Качество видео") }

    // Centered dialogs
    var showVideoQualityDialog by remember { mutableStateOf(false) }
    var showAudioTracksDialog by remember { mutableStateOf(false) }
    var showSubtitlesDialog by remember { mutableStateOf(false) }
    var showDecoderDialog by remember { mutableStateOf(false) }
    var showMediaInfoDialog by remember { mutableStateOf(false) }

    val anyDialogOpen = showVideoQualityDialog || showAudioTracksDialog ||
        showSubtitlesDialog || showDecoderDialog || showMediaInfoDialog

    val rootFocusRequester = remember { FocusRequester() }
    val playButtonFocusRequester = remember { FocusRequester() }
    val quickBarFirstFocusRequester = remember { FocusRequester() }
    val baseSeekStepSec = playerPrefs.seekStepSeconds.coerceAtLeast(5)

    fun hideHud() {
        hudMode = HudMode.HIDDEN
        isFastSeeking = false
        fastSeekAccumulatedSec = 0
        rapidSeekStreak = 0
        runCatching { rootFocusRequester.requestFocus() }
    }

    fun safeTogglePlayPause() {
        val now = System.currentTimeMillis()
        if (now - lastHudRevealMs < 380L) return
        onTogglePlayPause()
        interactionTick++
    }

    fun triggerFastSeek(direction: Int) {
        val now = System.currentTimeMillis()
        if (now - lastSeekPressMs < 450L) {
            rapidSeekStreak = (rapidSeekStreak + 1).coerceAtMost(30)
        } else {
            rapidSeekStreak = 0
            fastSeekAccumulatedSec = 0
        }
        lastSeekPressMs = now

        val stepSec = when {
            rapidSeekStreak >= 14 -> baseSeekStepSec * 6
            rapidSeekStreak >= 8 -> baseSeekStepSec * 3
            rapidSeekStreak >= 4 -> baseSeekStepSec * 2
            else -> baseSeekStepSec
        }
        val deltaSec = direction * stepSec
        val duration = uiState.durationMs.coerceAtLeast(0L)
        val basePos = if (isFastSeeking) fastSeekTargetMs else uiState.positionMs
        val newTarget = (basePos + deltaSec * 1000L).coerceIn(0L, if (duration > 0L) duration else Long.MAX_VALUE)

        isFastSeeking = true
        fastSeekTargetMs = newTarget
        fastSeekAccumulatedSec += deltaSec
        hudMode = HudMode.SEEK_BAR
        interactionTick++
        seekCommitTick++
    }

    LaunchedEffect(seekCommitTick) {
        if (seekCommitTick > 0 && isFastSeeking) {
            if (rapidSeekStreak > 0) delay(160)
            onSeekTo(fastSeekTargetMs)
            delay(350)
            isFastSeeking = false
        }
    }

    BackHandler(enabled = hudMode != HudMode.HIDDEN) {
        hideHud()
    }

    LaunchedEffect(hudMode) {
        when (hudMode) {
            HudMode.HIDDEN -> runCatching { rootFocusRequester.requestFocus() }
            HudMode.FULL -> {
                delay(40)
                runCatching { playButtonFocusRequester.requestFocus() }
            }
            HudMode.QUICK_BAR -> {
                delay(40)
                runCatching { quickBarFirstFocusRequester.requestFocus() }
            }
            HudMode.SEEK_BAR -> runCatching { rootFocusRequester.requestFocus() }
        }
    }

    LaunchedEffect(hudMode, interactionTick, anyDialogOpen) {
        if (hudMode != HudMode.HIDDEN && !anyDialogOpen) {
            val timeoutMs = if (hudMode == HudMode.SEEK_BAR) 3000L else 5000L
            delay(timeoutMs)
            hideHud()
        }
    }

    LaunchedEffect(gestureHudText) {
        if (gestureHudText != null) {
            delay(1000)
            gestureHudText = null
        }
    }



    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(rootFocusRequester)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                val code = keyEvent.nativeKeyEvent.keyCode

                // Swallow the matching KeyUp after OK revealed the HUD so Play/Pause never double-fires
                if (keyEvent.type == KeyEventType.KeyUp &&
                    (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) &&
                    swallowNextOkKeyUp
                ) {
                    swallowNextOkKeyUp = false
                    return@onPreviewKeyEvent true
                }

                if (keyEvent.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                interactionTick++

                when (code) {
                    KeyEvent.KEYCODE_BACK -> {
                        if (hudMode != HudMode.HIDDEN) {
                            hideHud()
                            true
                        } else {
                            onBackPressed()
                            true
                        }
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                        if (keyEvent.nativeKeyEvent.repeatCount == 0) {
                            onTogglePlayPause()
                            hudMode = HudMode.FULL
                        }
                        true
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY -> {
                        if (!uiState.isPlaying) onTogglePlayPause()
                        hudMode = HudMode.FULL
                        true
                    }
                    KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        if (uiState.isPlaying) onTogglePlayPause()
                        hudMode = HudMode.FULL
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        if (keyEvent.nativeKeyEvent.repeatCount > 0) return@onPreviewKeyEvent true
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            lastHudRevealMs = System.currentTimeMillis()
                            swallowNextOkKeyUp = true
                            hudMode = HudMode.FULL
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            hudMode = HudMode.QUICK_BAR
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        if (hudMode == HudMode.QUICK_BAR) {
                            hideHud()
                            true
                        } else if (hudMode == HudMode.HIDDEN) {
                            lastHudRevealMs = System.currentTimeMillis()
                            hudMode = HudMode.FULL
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            triggerFastSeek(-1)
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            triggerFastSeek(+1)
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_MENU -> {
                        onOpenSettingsSheet()
                        true
                    }
                    KeyEvent.KEYCODE_INFO -> {
                        showMediaInfoDialog = true
                        true
                    }
                    else -> false
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        hudMode = if (hudMode == HudMode.HIDDEN) HudMode.FULL else HudMode.HIDDEN
                        interactionTick++
                    },
                    onDoubleTap = { offset ->
                        if (offset.x < size.width / 2f) triggerFastSeek(-1) else triggerFastSeek(+1)
                    }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, dragAmount ->
                    val isLeftSide = change.position.x < size.width / 2f
                    val delta = -dragAmount / size.height.coerceAtLeast(1)
                    if (isLeftSide) {
                        val activity = context as? Activity ?: return@detectVerticalDragGestures
                        val lp = activity.window.attributes
                        val current = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                        val updated = (current + delta * 1.4f).coerceIn(0.05f, 1.0f)
                        lp.screenBrightness = updated
                        activity.window.attributes = lp
                        gestureHudText = "Яркость: ${(updated * 100).toInt()}%"
                    } else {
                        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                        val step = if (delta > 0.015f) 1 else if (delta < -0.015f) -1 else 0
                        if (step != 0) {
                            val nextVol = (curVol + step).coerceIn(0, maxVol)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                            gestureHudText = "Громкость: ${(nextVol * 100 / maxVol)}%"
                        }
                    }
                }
            }
    ) {
        val useTextureForEnhance = playerPrefs.pictureEnhanceEnabled && playerPrefs.decoderMode != DecoderMode.HDR_HARDWARE

        key(useTextureForEnhance, exoPlayer) {
            AndroidView(
                factory = { ctx ->
                    val layoutId = if (useTextureForEnhance) {
                        R.layout.player_view_texture
                    } else {
                        R.layout.player_view_surface
                    }
                    (LayoutInflater.from(ctx).inflate(layoutId, null) as PlayerView).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        player = exoPlayer
                        useController = false
                        keepScreenOn = true
                    }
                },
                update = { view ->
                    if (view.player !== exoPlayer) view.player = exoPlayer
                    view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT

                    view.subtitleView?.apply {
                        setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * playerPrefs.subtitleSize.scale)
                        val bg = if (playerPrefs.subtitleBackground) 0x88000000.toInt() else android.graphics.Color.TRANSPARENT
                        setStyle(
                            CaptionStyleCompat(
                                android.graphics.Color.WHITE,
                                bg,
                                android.graphics.Color.TRANSPARENT,
                                CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                                android.graphics.Color.BLACK,
                                null
                            )
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (playerPrefs.pictureEnhanceEnabled) {
                            // Vivid greens/foliage, crisp contrast & sharpness, rich saturation without black crush
                            val c = 1.15f
                            val t = (-0.5f * c + 0.5f) * 255f - 3.0f
                            val cm = ColorMatrix(
                                floatArrayOf(
                                    c * 1.01f, 0f, 0f, 0f, t,
                                    0f, c * 1.045f, 0f, 0f, t,
                                    0f, 0f, c * 1.00f, 0f, t,
                                    0f, 0f, 0f, 1f, 0f
                                )
                            )
                            val sat = ColorMatrix().apply { setSaturation(1.26f) }
                            cm.postConcat(sat)
                            view.videoSurfaceView?.setRenderEffect(
                                RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm))
                            )
                        } else {
                            view.videoSurfaceView?.setRenderEffect(null)
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (uiState.isBuffering) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (gestureHudText != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(
                    text = gestureHudText.orEmpty(),
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Auto-Next Episode Card
        val nextEp = uiState.nextEpisode
        val countdown = uiState.nextEpisodeCountdownSec
        if (nextEp != null && countdown != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 24.dp, bottom = 96.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xE6151922))
                    .padding(16.dp)
            ) {
                Text(
                    text = "Следующая серия через $countdown с",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = nextEp.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.size(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPlayNextEpisode, modifier = Modifier.tvFocusBorder()) {
                        Text("Смотреть сейчас")
                    }
                    OutlinedButton(onClick = onCancelNextCountdown, modifier = Modifier.tvFocusBorder()) {
                        Text("Отмена")
                    }
                }
            }
        }

        if (uiState.errorMessage != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.error.copy(alpha = 0.9f))
                    .padding(16.dp)
            ) {
                Text(text = uiState.errorMessage, color = Color.White)
            }
        }

        // HUD 1: FAST SEEK BAR
        AnimatedVisibility(
            visible = hudMode == HudMode.SEEK_BAR,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                val sign = if (fastSeekAccumulatedSec >= 0) "+" else "-"
                val absSec = kotlin.math.abs(fastSeekAccumulatedSec)
                val deltaLabel = if (absSec >= 60) {
                    String.format(Locale.US, "%s%d:%02d", sign, absSec / 60, absSec % 60)
                } else {
                    "$sign${absSec} сек"
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(alpha = 0.78f))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = deltaLabel,
                        color = Color.White,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 18.dp)
                ) {
                    val duration = uiState.durationMs.coerceAtLeast(1L)
                    val shownPos = if (isFastSeeking) fastSeekTargetMs else uiState.positionMs
                    Slider(
                        value = shownPos.coerceIn(0L, duration).toFloat(),
                        onValueChange = { onSeekTo(it.toLong()) },
                        valueRange = 0f..duration.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatDuration(shownPos),
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = formatDuration(uiState.durationMs),
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }

        // HUD 2: COMPACT QUICK-BAR (8 functions, opened by DPAD_UP without pausing)
        AnimatedVisibility(
            visible = hudMode == HudMode.QUICK_BAR,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .padding(bottom = 26.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.76f))
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = quickBarFocusedLabel,
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(32.dp))
                            .background(Color(0xE0141923))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        QuickBarAction(
                            icon = Icons.Default.HighQuality,
                            label = "Качество видео",
                            tint = Color.White,
                            modifier = Modifier.focusRequester(quickBarFirstFocusRequester),
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showVideoQualityDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Memory,
                            label = "Декодер: ${playerPrefs.decoderMode.titleRu}",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showDecoderDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Audiotrack,
                            label = "Аудиодорожка",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showAudioTracksDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Subtitles,
                            label = "Субтитры",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showSubtitlesDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.GraphicEq,
                            label = "Звук: ${audioSettings.mode.titleRu}",
                            tint = MaterialTheme.colorScheme.secondary,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { onOpenAudioSheet(); interactionTick++ }
                        )
                        QuickBarAction(
                            icon = if (isLandscape) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            label = if (isLandscape) "Вертикальный экран" else "На весь экран (поворот)",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { toggleOrientationFullscreen(); interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Settings,
                            label = "Настройки плеера",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { onOpenSettingsSheet(); interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Info,
                            label = "Информация (кодеки и разрешение)",
                            tint = MaterialTheme.colorScheme.primary,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showMediaInfoDialog = true; interactionTick++ }
                        )
                    }
                }
            }
        }

        // HUD 3: FULL CONTROLS (1st OK without pausing + Episode Strip under seekbar + 8 buttons)
        AnimatedVisibility(
            visible = hudMode == HudMode.FULL,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)))
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackPressed, modifier = Modifier.tvFocusBorder(CircleShape)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад", tint = Color.White)
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(
                            text = uiState.currentTitle,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val meta = listOfNotNull(
                            uiState.videoCodecInfo.takeIf { it.isNotBlank() },
                            uiState.audioCodecInfo.takeIf { it.isNotBlank() },
                            if (playerPrefs.pictureEnhanceEnabled) "Улучшение картинки: Вкл" else null,
                            if (audioSettings.dialogueBalancerEnabled) "Автобаланс речи" else null,
                            uiState.sleepTimerRemainingMin?.let { "Сон: ${it}м" }
                                ?: if (uiState.sleepAtEndOfEpisode) "Сон: конец серии" else null
                        ).joinToString(" • ")
                        if (meta.isNotBlank()) {
                            Text(
                                text = meta,
                                color = Color.White.copy(alpha = 0.78f),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .tvFocusBorder(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                            .clickable(onClick = onOpenAudioSheet)
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = "Автонормализация",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.size(4.dp))
                        val hudTelemetry by telemetryFlow.collectAsState()
                        Text(
                            text = String.format(Locale.US, "%s (%+.1f дБ)", audioSettings.mode.name, hudTelemetry.appliedGainDb),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Center Transport Controls
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (uiState.prevEpisode != null) {
                        IconButton(
                            onClick = { onPlayPrevEpisode(); interactionTick++ },
                            modifier = Modifier.size(48.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Предыдущая серия", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }

                    IconButton(
                        onClick = { triggerFastSeek(-1) },
                        modifier = Modifier.size(54.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Replay10, contentDescription = "Назад", tint = Color.White, modifier = Modifier.size(30.dp))
                    }

                    IconButton(
                        onClick = { safeTogglePlayPause() },
                        modifier = Modifier
                            .size(70.dp)
                            .focusRequester(playButtonFocusRequester)
                            .clip(CircleShape)
                            .tvFocusBorder(CircleShape, Color.White)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.92f))
                    ) {
                        Icon(
                            imageVector = if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Пауза / Старт",
                            tint = Color.Black,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    IconButton(
                        onClick = { triggerFastSeek(+1) },
                        modifier = Modifier.size(54.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Forward10, contentDescription = "Вперёд", tint = Color.White, modifier = Modifier.size(30.dp))
                    }

                    if (uiState.nextEpisode != null) {
                        IconButton(
                            onClick = { onPlayNextEpisode(); interactionTick++ },
                            modifier = Modifier.size(48.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Следующая серия", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }
                }

                // Bottom Bar: Seekbar + Compact Episode Strip + 8 Action Icons
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.90f))))
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    val duration = uiState.durationMs.coerceAtLeast(1L)
                    val shownPos = if (isFastSeeking) fastSeekTargetMs else uiState.positionMs
                    Slider(
                        value = shownPos.coerceIn(0L, duration).toFloat(),
                        onValueChange = { onSeekTo(it.toLong()); interactionTick++ },
                        valueRange = 0f..duration.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (uiState.folderEpisodes.size > 1) {
                        val epListState = rememberLazyListState()
                        LaunchedEffect(uiState.currentEpisodeIndex) {
                            if (uiState.currentEpisodeIndex >= 0) {
                                runCatching { epListState.scrollToItem(uiState.currentEpisodeIndex) }
                            }
                        }
                        LazyRow(
                            state = epListState,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp, bottom = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            itemsIndexed(uiState.folderEpisodes) { idx, ep ->
                                val isCurrent = idx == uiState.currentEpisodeIndex
                                val isWatched = idx < uiState.currentEpisodeIndex
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .tvFocusBorder(RoundedCornerShape(10.dp), Color.White)
                                        .background(
                                            if (isCurrent) Color(0xFFF28B82)
                                            else Color(0x88141820)
                                        )
                                        .border(
                                            width = if (isCurrent) 0.dp else 1.2.dp,
                                            color = if (isCurrent) Color.Transparent else Color.White.copy(alpha = 0.45f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            onSelectEpisode(ep)
                                            interactionTick++
                                        }
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "${idx + 1} серия",
                                            color = Color.White,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium
                                        )
                                        if (isCurrent || isWatched) {
                                            Text(
                                                text = "✓",
                                                color = Color.White.copy(alpha = 0.9f),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${formatDuration(shownPos)} / ${formatDuration(uiState.durationMs)}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { showVideoQualityDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.HighQuality, contentDescription = "Качество видео", tint = Color.White)
                            }
                            IconButton(onClick = { showDecoderDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Memory, contentDescription = "Видео и аудио декодер", tint = Color.White)
                            }
                            IconButton(onClick = { showAudioTracksDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Audiotrack, contentDescription = "Аудиодорожка", tint = Color.White)
                            }
                            IconButton(onClick = { showSubtitlesDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Subtitles, contentDescription = "Субтитры", tint = Color.White)
                            }
                            IconButton(onClick = onOpenAudioSheet, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.GraphicEq, contentDescription = "Звук и EQ", tint = MaterialTheme.colorScheme.secondary)
                            }
                            IconButton(onClick = toggleOrientationFullscreen, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(
                                    imageVector = if (isLandscape) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                    contentDescription = "На весь экран / Поворот",
                                    tint = Color.White
                                )
                            }
                            IconButton(onClick = onOpenSettingsSheet, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = Color.White)
                            }
                            IconButton(onClick = { showMediaInfoDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Info, contentDescription = "Информация", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showMediaInfoDialog) {
        val infoTelemetry by telemetryFlow.collectAsState()
        MediaInfoDialog(
            title = uiState.currentTitle,
            details = uiState.mediaDetails,
            audioSettings = audioSettings,
            playerPrefs = playerPrefs,
            telemetry = infoTelemetry,
            onDismiss = { showMediaInfoDialog = false }
        )
    }

    if (showVideoQualityDialog) {
        TrackPickerDialog(
            title = "Качество видео",
            tracks = uiState.videoTracks,
            autoOrDisableLabel = if (playerPrefs.alwaysBestQuality) "Авто (Максимальное)" else "Авто",
            onSelect = {
                onSelectVideoTrack(it)
                showVideoQualityDialog = false
            },
            onDismiss = { showVideoQualityDialog = false }
        )
    }

    if (showAudioTracksDialog) {
        TrackPickerDialog(
            title = "Аудиодорожка",
            tracks = uiState.audioTracks,
            autoOrDisableLabel = null,
            onSelect = {
                onSelectAudioTrack(it)
                showAudioTracksDialog = false
            },
            onDismiss = { showAudioTracksDialog = false }
        )
    }

    if (showSubtitlesDialog) {
        TrackPickerDialog(
            title = "Субтитры",
            tracks = uiState.subtitleTracks,
            autoOrDisableLabel = "Отключить",
            onSelect = {
                onSelectSubtitleTrack(it)
                showSubtitlesDialog = false
            },
            onDismiss = { showSubtitlesDialog = false }
        )
    }

    if (showDecoderDialog) {
        AlertDialog(
            onDismissRequest = { showDecoderDialog = false },
            title = { Text("Видео и аудио декодер") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DecoderMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .tvFocusBorder(RoundedCornerShape(10.dp))
                                .clickable {
                                    onSelectDecoderMode(mode)
                                    showDecoderDialog = false
                                }
                                .padding(vertical = 8.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = playerPrefs.decoderMode == mode, onClick = null)
                            Spacer(Modifier.size(8.dp))
                            Column {
                                Text(mode.titleRu, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(mode.descriptionRu, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDecoderDialog = false }) { Text("Закрыть") }
            }
        )
    }
}

@Composable
private fun MediaInfoDialog(
    title: String,
    details: MediaDetailedInfo,
    audioSettings: AudioNormalizationSettings,
    playerPrefs: PlayerPreferences,
    telemetry: AudioTelemetry,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.84f)
                .widthIn(max = 640.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Информация о видео и аудио", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onDismiss, modifier = Modifier.tvFocusBorder()) { Text("Закрыть") }
                }

                Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.secondary, maxLines = 2, overflow = TextOverflow.Ellipsis)

                InfoSectionCard("Видео") {
                    InfoRow("Разрешение", details.resolution)
                    InfoRow("Видеокодек", details.videoCodec)
                    InfoRow("Частота кадров", details.videoFps)
                    InfoRow("Битрейт видео", details.videoBitrate)
                    InfoRow("Декодер", playerPrefs.decoderMode.titleRu)
                    InfoRow("Улучшение картинки", if (playerPrefs.pictureEnhanceEnabled) "Включено" else "Отключено")
                }

                InfoSectionCard("Аудио и обработка AuraPlay") {
                    InfoRow("Аудиокодек", details.audioCodec)
                    InfoRow("Каналы / Язык", "${details.audioChannels} • ${details.audioLanguage}")
                    InfoRow("Частота / Битрейт", "${details.audioSampleRate} • ${details.audioBitrate}")
                    InfoRow(
                        "Обработка звука",
                        "${audioSettings.mode.titleRu} • Автобаланс: ${if (audioSettings.dialogueBalancerEnabled) audioSettings.dialogueBalancerStrength.titleRu else "Выкл"}"
                    )
                    InfoRow(
                        "Телеметрия (32-bit float)",
                        String.format(Locale.US, "%.1f LUFS • Усиление %+.1f дБ • Пик %.1f дБ", telemetry.shortTermLufs, telemetry.appliedGainDb, telemetry.truePeakDbtp)
                    )
                }
            }
        }
    }
}

@Composable
private fun InfoSectionCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.size(12.dp))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun QuickBarAction(
    icon: ImageVector,
    label: String,
    tint: Color,
    modifier: Modifier = Modifier,
    onFocused: (String) -> Unit,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(46.dp)
            .clip(CircleShape)
            .tvFocusBorder(CircleShape)
            .onFocusChanged { if (it.isFocused) onFocused(label) }
    ) {
        Icon(icon, contentDescription = label, tint = tint)
    }
}

@Composable
private fun TrackPickerDialog(
    title: String,
    tracks: List<TrackOption>,
    autoOrDisableLabel: String?,
    onSelect: (TrackOption?) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                if (autoOrDisableLabel != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .tvFocusBorder(RoundedCornerShape(8.dp))
                            .clickable { onSelect(null) }
                            .padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = tracks.none { it.isSelected }, onClick = null)
                        Spacer(Modifier.size(8.dp))
                        Text(autoOrDisableLabel)
                    }
                }
                if (tracks.isEmpty()) {
                    Text("Дорожки не обнаружены", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    tracks.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .tvFocusBorder(RoundedCornerShape(8.dp))
                                .clickable { onSelect(opt) }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = opt.isSelected, onClick = null)
                            Spacer(Modifier.size(8.dp))
                            Text(opt.label)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        }
    )
}
