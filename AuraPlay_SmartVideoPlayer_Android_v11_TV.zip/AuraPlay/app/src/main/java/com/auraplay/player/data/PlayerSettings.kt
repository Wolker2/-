package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение ТВ/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная экономия заряда, только системные кодеки"
    )
}

/**
 * Shadow-safe 3D-LUT & GPU shader presets (no linear black-crush!):
 * - midContrast: smooth midtone S-curve strength (0.0 = neutral)
 * - shadowLift: gentle shadow detail recovery (protects pure black < 0.015)
 * - highlightRoll: gentle highlight roll-off (negative = softer bright peaks)
 * - saturation: color saturation multiplier (1.0 = neutral)
 * - redScale / blueScale: subtle warm/cool tint
 */
enum class PictureEnhanceMode(
    val titleRu: String,
    val descriptionRu: String,
    val midContrast: Double,
    val shadowLift: Double,
    val highlightRoll: Double,
    val saturation: Double,
    val redScale: Double,
    val blueScale: Double,
    val clarity: Float = 0f,
    val sharpness: Float = 0f
) {
    OFF("Отключить", "Оригинальная картинка без обработки (лучше для HDR)", 0.0, 0.0, 0.0, 1.00, 1.00, 1.00),
    ANIME("Аниме", "Яркие сочные цвета, выразительный контраст и лёгкая чёткость без провала теней", 0.16, 0.030, -0.025, 1.32, 1.00, 1.02, clarity = 0.12f, sharpness = 0.10f),
    ANIME_2("Аниме 2", "Чёткость (Clarity) 20% + Резкость (Sharpness) 15% для контуров и мелких деталей", 0.04, 0.015, -0.015, 1.06, 1.00, 1.00, clarity = 0.20f, sharpness = 0.15f),
    MOVIE("Фильм", "Глубокий кинотеатральный контраст, тёплая цветопередача и защита деталей в тенях", 0.22, 0.025, -0.050, 1.14, 1.05, 0.93, clarity = 0.08f, sharpness = 0.0f),
    SERIES("Сериал", "Чистая живая картинка, открытые тени и чёткая детализация", 0.12, 0.065, -0.030, 1.15, 1.01, 1.00, clarity = 0.10f, sharpness = 0.06f),
    EVERYDAY("Повседневное", "Свежая сбалансированная картинка для комфортного долгого просмотра", 0.10, 0.030, -0.025, 1.10, 1.00, 1.00, clarity = 0.06f, sharpness = 0.0f),
    AUTO("Авто", "Умный 3D-LUT: заметно вытягивает тёмные тени и мягко приглушает яркие пересветы", 0.10, 0.090, -0.100, 1.10, 1.00, 1.00, clarity = 0.05f, sharpness = 0.0f)
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceMode: PictureEnhanceMode = PictureEnhanceMode.OFF,
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
