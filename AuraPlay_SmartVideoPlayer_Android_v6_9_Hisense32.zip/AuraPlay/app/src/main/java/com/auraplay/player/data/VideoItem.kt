package com.auraplay.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoItem(
    val id: Long,
    val title: String,
    val uri: Uri,
    val durationMs: Long,
    val sizeBytes: Long,
    val folderName: String,
    val mimeType: String
)

/** Normalized key for tracking watched state across sessions (strips temporary query tokens on network streams). */
fun VideoItem.watchKey(): String = normalizeWatchKey(uri, title, folderName)

fun normalizeWatchKey(uri: Uri, title: String = "", folderName: String = ""): String {
    val raw = uri.toString()
    val scheme = uri.scheme?.lowercase()
    return if (scheme in listOf("http", "https", "rtsp")) {
        val stripped = raw.substringBefore("?").trim()
        if (stripped.length >= 12) stripped else "${folderName.trim()}|${title.trim()}"
    } else {
        raw
    }
}

object LocalVideoRepository {

    private val GENERIC_FOLDERS = setOf(
        "download", "downloads", "movies", "video", "videos",
        "dcim", "camera", "telegram", "внутренняя память", "загрузки"
    )

    private val SEASON_EPISODE_REGEX = Regex("(?i)S(\\d{1,2})\\s*[EЕ](\\d{1,3})")
    private val X_EPISODE_REGEX = Regex("(?i)\\b(\\d{1,2})x(\\d{1,3})\\b")
    private val WORD_BEFORE_NUM_REGEX = Regex("(?i)(?:серия|эпизод|episode|ep\\.?|e)\\s*[-_.]*\\s*(\\d{1,3})\\b")
    private val NUM_BEFORE_WORD_REGEX = Regex("(?i)\\b(\\d{1,3})\\s*(?:серия|сер\\.?|эпизод)")
    private val EXTENSION_REGEX = Regex("(?i)\\.(mkv|mp4|avi|ts|webm|mov|m4v|wmv|flv|mpg|mpeg|m3u8|m3u)$")
    private val SERIES_PREFIX_SPLIT_REGEX = Regex(
        "(?i)(?:\\bS\\d{1,2}\\s*[EЕ]\\d{1,3}|\\b\\d{1,2}x\\d{1,3}\\b|(?:серия|эпизод|episode|ep\\.?)\\s*[-_.]*\\s*\\d{1,3}|\\b\\d{1,3}\\s*(?:серия|сер\\.?|эпизод)|[-_\\s]+\\d{1,3}$)"
    )
    private val HEX_HASH_REGEX = Regex("^[a-fA-F0-9]{12,}$")

    suspend fun loadDeviceVideos(context: Context): List<VideoItem> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

        runCatching {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    videos.add(
                        VideoItem(
                            id = id,
                            title = cursor.getString(nameCol) ?: "Видео #$id",
                            uri = uri,
                            durationMs = cursor.getLong(durCol),
                            sizeBytes = cursor.getLong(sizeCol),
                            folderName = cursor.getString(bucketCol) ?: "Внутренняя память",
                            mimeType = cursor.getString(mimeCol) ?: "video/*"
                        )
                    )
                }
            }
        }
        videos
    }

    /** Natural sorting for TV series episodes (S01E02 < S01E10, Episode 2 < Episode 10). */
    fun sortEpisodesNaturally(items: List<VideoItem>): List<VideoItem> {
        val regex = Regex("(\\d+|\\D+)")
        return items.sortedWith { a, b ->
            val aParts = regex.findAll(a.title.lowercase()).map { it.value }.toList()
            val bParts = regex.findAll(b.title.lowercase()).map { it.value }.toList()
            val len = minOf(aParts.size, bParts.size)
            for (i in 0 until len) {
                val ap = aParts[i]
                val bp = bParts[i]
                val an = ap.toLongOrNull()
                val bn = bp.toLongOrNull()
                val cmp = if (an != null && bn != null) an.compareTo(bn) else ap.compareTo(bp)
                if (cmp != 0) return@sortedWith cmp
            }
            aParts.size.compareTo(bParts.size)
        }
    }

    /**
     * Groups local folder episodes safely:
     * - Dedicated series folders return all naturally sorted files.
     * - Generic folders (Download, Movies, etc.) only group files sharing the same series prefix
     *   so unrelated movies are not merged into a fake episode strip.
     */
    fun filterRelatedEpisodes(target: VideoItem, allVideos: List<VideoItem>): List<VideoItem> {
        val sameFolder = allVideos.filter { it.folderName == target.folderName }
        if (sameFolder.size <= 1) return sameFolder

        if (target.folderName.trim().lowercase() !in GENERIC_FOLDERS) {
            return sortEpisodesNaturally(sameFolder)
        }

        val targetPrefix = extractSeriesPrefix(target.title)
        if (targetPrefix.length < 3) {
            return listOf(target)
        }

        val related = sameFolder.filter { candidate ->
            candidate.id == target.id || extractSeriesPrefix(candidate.title) == targetPrefix
        }
        return if (related.size > 1) sortEpisodesNaturally(related) else listOf(target)
    }

    private fun extractSeriesPrefix(rawTitle: String): String {
        val noExt = rawTitle.replace(EXTENSION_REGEX, "").trim()
        val match = SERIES_PREFIX_SPLIT_REGEX.find(noExt) ?: return ""
        val prefix = noExt.substring(0, match.range.first)
            .replace(Regex("[._\\-\\[\\]()]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .lowercase()
        return prefix
    }

    /** Formats a compact, readable label for the episode strip card. */
    fun formatEpisodeChipLabel(title: String, index: Int): String {
        val clean = title.replace(EXTENSION_REGEX, "").trim()
        if (clean.isBlank()) return "${index + 1} серия"

        SEASON_EPISODE_REGEX.find(clean)?.let { m ->
            val s = m.groupValues[1].toIntOrNull()
            val e = m.groupValues[2].toIntOrNull()
            if (s != null && e != null) return "S$s E$e"
        }

        X_EPISODE_REGEX.find(clean)?.let { m ->
            val s = m.groupValues[1].toIntOrNull()
            val e = m.groupValues[2].toIntOrNull()
            if (s != null && e != null) return "S$s E$e"
        }

        WORD_BEFORE_NUM_REGEX.find(clean)?.let { m ->
            val e = m.groupValues[1].toIntOrNull()
            if (e != null) return "$e серия"
        }

        NUM_BEFORE_WORD_REGEX.find(clean)?.let { m ->
            val e = m.groupValues[1].toIntOrNull()
            if (e != null) return "$e серия"
        }

        val normalized = clean
            .replace('_', ' ')
            .replace('.', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()

        if (normalized.isBlank() || HEX_HASH_REGEX.matches(normalized)) {
            return "${index + 1} серия"
        }

        val words = normalized.split(" ").filter { it.isNotBlank() }
        val twoWords = words.take(2).joinToString(" ")
        return when {
            twoWords.length in 1..16 -> twoWords
            normalized.length <= 16 -> normalized
            else -> normalized.take(15).trimEnd() + "…"
        }
    }

    /**
     * Parses a multi-item M3U playlist (ignoring HLS media/master manifests so ExoPlayer plays them natively).
     */
    fun parseM3uPlaylist(content: String): List<VideoItem> {
        if (content.isBlank()) return emptyList()
        val upper = content.uppercase()
        // Never hijack HLS streaming manifests
        if (upper.contains("#EXT-X-TARGETDURATION") ||
            upper.contains("#EXT-X-STREAM-INF") ||
            upper.contains("#EXT-X-MEDIA-SEQUENCE")
        ) {
            return emptyList()
        }

        val items = mutableListOf<VideoItem>()
        var pendingTitle: String? = null
        val lines = content.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }

        for (line in lines) {
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val commaIdx = line.indexOf(',')
                    pendingTitle = if (commaIdx >= 0 && commaIdx + 1 < line.length) {
                        line.substring(commaIdx + 1).trim().takeIf { it.isNotBlank() }
                    } else null
                }
                line.startsWith("#") -> Unit
                else -> {
                    val parsedUri = runCatching { Uri.parse(line) }.getOrNull()
                    if (parsedUri != null && !parsedUri.scheme.isNullOrBlank()) {
                        val idx = items.size + 1
                        val label = pendingTitle
                            ?: parsedUri.lastPathSegment?.substringAfterLast("/")?.takeIf { it.isNotBlank() }
                            ?: "Серия $idx"
                        items.add(
                            VideoItem(
                                id = idx.toLong(),
                                title = label,
                                uri = parsedUri,
                                durationMs = 0L,
                                sizeBytes = 0L,
                                folderName = "Плейлист",
                                mimeType = "video/*"
                            )
                        )
                    }
                    pendingTitle = null
                }
            }
        }
        return if (items.size > 1) items else emptyList()
    }
}
