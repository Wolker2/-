package com.auraplay.player.ui

import android.app.Activity
import android.content.Context
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RenderEffect
import android.media.AudioManager
import android.os.Build
import android.view.KeyEvent
import android.view.LayoutInflater
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import com.auraplay.player.R
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.AudioTelemetry
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.ui.theme.tvFocusBorder
import kotlinx.coroutines.delay
import java.util.Locale

private enum class HudMode {
    HIDDEN,
    FULL,
    QUICK_BAR,
    SEEK_BAR
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    exoPlayer: ExoPlayer,
    uiState: PlayerUiState,
    audioSettings: AudioNormalizationSettings,
    playerPrefs: PlayerPreferences,
    telemetry: AudioTelemetry,
    onBackPressed: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSeekBy: (Long) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onPlayNextEpisode: () -> Unit,
    onPlayPrevEpisode: () -> Unit,
    onCancelNextCountdown: () -> Unit,
    onOpenAudioSheet: () -> Unit,
    onOpenSettingsSheet: () -> Unit,
    onSelectVideoTrack: (TrackOption?) -> Unit,
    onSelectAudioTrack: (TrackOption?) -> Unit,
    onSelectSubtitleTrack: (TrackOption?) -> Unit
) {
    val context = LocalContext.current
    var hudMode by remember { mutableStateOf(HudMode.FULL) }
    var interactionTick by remember { mutableIntStateOf(0) }
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var gestureHudText by remember { mutableStateOf<String?>(null) }

    // Fast-seek state (optimistic preview + accelerated step on rapid/held presses)
    var isFastSeeking by remember { mutableStateOf(false) }
    var fastSeekTargetMs by remember { mutableLongStateOf(0L) }
    var fastSeekAccumulatedSec by remember { mutableIntStateOf(0) }
    var lastSeekPressMs by remember { mutableLongStateOf(0L) }
    var rapidSeekStreak by remember { mutableIntStateOf(0) }
    var seekCommitTick by remember { mutableIntStateOf(0) }

    // Quick-bar focused item label
    var quickBarFocusedLabel by remember { mutableStateOf("Качество видео") }

    // Dialogs
    var showVideoQualityDialog by remember { mutableStateOf(false) }
    var showAudioTracksDialog by remember { mutableStateOf(false) }
    var showSubtitlesDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }

    val anyDialogOpen = showVideoQualityDialog || showAudioTracksDialog || showSubtitlesDialog || showSpeedDialog

    val rootFocusRequester = remember { FocusRequester() }
    val playButtonFocusRequester = remember { FocusRequester() }
    val quickBarFirstFocusRequester = remember { FocusRequester() }
    val baseSeekStepSec = playerPrefs.seekStepSeconds.coerceAtLeast(5)

    fun hideHud() {
        hudMode = HudMode.HIDDEN
        isFastSeeking = false
        fastSeekAccumulatedSec = 0
        rapidSeekStreak = 0
        runCatching { rootFocusRequester.requestFocus() }
    }

    fun triggerFastSeek(direction: Int) {
        val now = System.currentTimeMillis()
        if (now - lastSeekPressMs < 450L) {
            rapidSeekStreak = (rapidSeekStreak + 1).coerceAtMost(30)
        } else {
            rapidSeekStreak = 0
            fastSeekAccumulatedSec = 0
        }
        lastSeekPressMs = now

        // Progressive acceleration for rapid or held D-Pad left/right
        val stepSec = when {
            rapidSeekStreak >= 14 -> baseSeekStepSec * 6
            rapidSeekStreak >= 8 -> baseSeekStepSec * 3
            rapidSeekStreak >= 4 -> baseSeekStepSec * 2
            else -> baseSeekStepSec
        }
        val deltaSec = direction * stepSec
        val duration = uiState.durationMs.coerceAtLeast(0L)
        val basePos = if (isFastSeeking) fastSeekTargetMs else uiState.positionMs
        val newTarget = (basePos + deltaSec * 1000L).coerceIn(0L, if (duration > 0L) duration else Long.MAX_VALUE)

        isFastSeeking = true
        fastSeekTargetMs = newTarget
        fastSeekAccumulatedSec += deltaSec
        hudMode = HudMode.SEEK_BAR
        interactionTick++
        seekCommitTick++
    }

    // Commit fast seek quickly (instant on single press, debounced 160 ms during continuous hold)
    LaunchedEffect(seekCommitTick) {
        if (seekCommitTick > 0 && isFastSeeking) {
            if (rapidSeekStreak > 0) {
                delay(160)
            }
            onSeekTo(fastSeekTargetMs)
            delay(350)
            isFastSeeking = false
        }
    }

    // System BackHandler: if any HUD is visible -> hide HUD; if hidden -> close player
    BackHandler(enabled = hudMode != HudMode.HIDDEN) {
        hideHud()
    }

    // Focus management when HUD mode changes
    LaunchedEffect(hudMode) {
        when (hudMode) {
            HudMode.HIDDEN -> runCatching { rootFocusRequester.requestFocus() }
            HudMode.FULL -> {
                delay(40)
                runCatching { playButtonFocusRequester.requestFocus() }
            }
            HudMode.QUICK_BAR -> {
                delay(40)
                runCatching { quickBarFirstFocusRequester.requestFocus() }
            }
            HudMode.SEEK_BAR -> runCatching { rootFocusRequester.requestFocus() }
        }
    }

    // Auto-hide HUD: 5 seconds for FULL / QUICK_BAR, 3 seconds for SEEK_BAR
    LaunchedEffect(hudMode, interactionTick, anyDialogOpen) {
        if (hudMode != HudMode.HIDDEN && !anyDialogOpen) {
            val timeoutMs = if (hudMode == HudMode.SEEK_BAR) 3000L else 5000L
            delay(timeoutMs)
            hideHud()
        }
    }

    LaunchedEffect(gestureHudText) {
        if (gestureHudText != null) {
            delay(1000)
            gestureHudText = null
        }
    }

    val cycleResizeMode: () -> Unit = {
        resizeMode = when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        gestureHudText = when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> "Масштаб: По размеру"
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Масштаб: Увеличить"
            else -> "Масштаб: Растянуть"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(rootFocusRequester)
            .focusable()
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                interactionTick++

                when (keyEvent.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_BACK -> {
                        if (hudMode != HudMode.HIDDEN) {
                            hideHud()
                            true
                        } else {
                            onBackPressed()
                            true
                        }
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                        onTogglePlayPause()
                        hudMode = HudMode.FULL
                        true
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY -> {
                        if (!uiState.isPlaying) onTogglePlayPause()
                        hudMode = HudMode.FULL
                        true
                    }
                    KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        if (uiState.isPlaying) onTogglePlayPause()
                        hudMode = HudMode.FULL
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        // 1st press when hidden -> show FULL HUD WITHOUT pausing!
                        // Subsequent presses in FULL mode -> let focused button (Play/Pause) execute.
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            hudMode = HudMode.FULL
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        // UP during playback -> open compact quick-bar WITHOUT pausing!
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            hudMode = HudMode.QUICK_BAR
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        if (hudMode == HudMode.QUICK_BAR) {
                            hideHud()
                            true
                        } else if (hudMode == HudMode.HIDDEN) {
                            hudMode = HudMode.FULL
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            triggerFastSeek(-1)
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (hudMode == HudMode.HIDDEN || hudMode == HudMode.SEEK_BAR) {
                            triggerFastSeek(+1)
                            true
                        } else {
                            false
                        }
                    }
                    KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO -> {
                        onOpenSettingsSheet()
                        true
                    }
                    else -> false
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        hudMode = if (hudMode == HudMode.HIDDEN) HudMode.FULL else HudMode.HIDDEN
                        interactionTick++
                    },
                    onDoubleTap = { offset ->
                        if (offset.x < size.width / 2f) {
                            triggerFastSeek(-1)
                        } else {
                            triggerFastSeek(+1)
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, dragAmount ->
                    val isLeftSide = change.position.x < size.width / 2f
                    val delta = -dragAmount / size.height.coerceAtLeast(1)
                    if (isLeftSide) {
                        val activity = context as? Activity ?: return@detectVerticalDragGestures
                        val lp = activity.window.attributes
                        val current = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                        val updated = (current + delta * 1.4f).coerceIn(0.05f, 1.0f)
                        lp.screenBrightness = updated
                        activity.window.attributes = lp
                        gestureHudText = "Яркость: ${(updated * 100).toInt()}%"
                    } else {
                        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                        val step = if (delta > 0.015f) 1 else if (delta < -0.015f) -1 else 0
                        if (step != 0) {
                            val nextVol = (curVol + step).coerceIn(0, maxVol)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                            gestureHudText = "Громкость: ${(nextVol * 100 / maxVol)}%"
                        }
                    }
                }
            }
    ) {
        // Video Surface
        key(playerPrefs.autoPictureEnhance, exoPlayer) {
            AndroidView(
                factory = { ctx ->
                    val layoutId = if (playerPrefs.autoPictureEnhance) {
                        R.layout.player_view_texture
                    } else {
                        R.layout.player_view_surface
                    }
                    (LayoutInflater.from(ctx).inflate(layoutId, null) as PlayerView).apply {
                        player = exoPlayer
                        useController = false
                        keepScreenOn = true
                    }
                },
                update = { view ->
                    if (view.player !== exoPlayer) view.player = exoPlayer
                    view.resizeMode = resizeMode

                    view.subtitleView?.apply {
                        setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * playerPrefs.subtitleSize.scale)
                        val bg = if (playerPrefs.subtitleBackground) 0x88000000.toInt() else android.graphics.Color.TRANSPARENT
                        setStyle(
                            CaptionStyleCompat(
                                android.graphics.Color.WHITE,
                                bg,
                                android.graphics.Color.TRANSPARENT,
                                CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                                android.graphics.Color.BLACK,
                                null
                            )
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        if (playerPrefs.autoPictureEnhance) {
                            val contrast = 1.08f
                            val translate = (-0.5f * contrast + 0.5f) * 255f
                            val contrastMatrix = ColorMatrix(
                                floatArrayOf(
                                    contrast, 0f, 0f, 0f, translate,
                                    0f, contrast, 0f, 0f, translate,
                                    0f, 0f, contrast, 0f, translate,
                                    0f, 0f, 0f, 1f, 0f
                                )
                            )
                            val satMatrix = ColorMatrix().apply { setSaturation(1.12f) }
                            contrastMatrix.postConcat(satMatrix)
                            view.videoSurfaceView?.setRenderEffect(
                                RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(contrastMatrix))
                            )
                        } else {
                            view.videoSurfaceView?.setRenderEffect(null)
                        }
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (uiState.isBuffering) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (gestureHudText != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text(
                    text = gestureHudText.orEmpty(),
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Auto-Next Episode Card
        val nextEp = uiState.nextEpisode
        val countdown = uiState.nextEpisodeCountdownSec
        if (nextEp != null && countdown != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 24.dp, bottom = 96.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xE6151922))
                    .padding(16.dp)
            ) {
                Text(
                    text = "Следующая серия через $countdown с",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = nextEp.title,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.size(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPlayNextEpisode, modifier = Modifier.tvFocusBorder()) {
                        Text("Смотреть сейчас")
                    }
                    OutlinedButton(onClick = onCancelNextCountdown, modifier = Modifier.tvFocusBorder()) {
                        Text("Отмена")
                    }
                }
            }
        }

        if (uiState.errorMessage != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.error.copy(alpha = 0.9f))
                    .padding(16.dp)
            ) {
                Text(text = uiState.errorMessage, color = Color.White)
            }
        }

        // -------------------------------------------------------------------
        // HUD MODE 1: FAST SEEK BAR (shows progress bar + delta during seek)
        // -------------------------------------------------------------------
        AnimatedVisibility(
            visible = hudMode == HudMode.SEEK_BAR,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                val sign = if (fastSeekAccumulatedSec >= 0) "+" else "-"
                val absSec = kotlin.math.abs(fastSeekAccumulatedSec)
                val deltaLabel = if (absSec >= 60) {
                    String.format(Locale.US, "%s%d:%02d", sign, absSec / 60, absSec % 60)
                } else {
                    "$sign${absSec} сек"
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.Black.copy(alpha = 0.78f))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = deltaLabel,
                        color = Color.White,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 18.dp)
                ) {
                    val duration = uiState.durationMs.coerceAtLeast(1L)
                    val shownPos = if (isFastSeeking) fastSeekTargetMs else uiState.positionMs
                    Slider(
                        value = shownPos.coerceIn(0L, duration).toFloat(),
                        onValueChange = { onSeekTo(it.toLong()) },
                        valueRange = 0f..duration.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatDuration(shownPos),
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = formatDuration(uiState.durationMs),
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }

        // -------------------------------------------------------------------
        // HUD MODE 2: COMPACT QUICK-BAR (opened by DPAD_UP without pausing)
        // -------------------------------------------------------------------
        AnimatedVisibility(
            visible = hudMode == HudMode.QUICK_BAR,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .navigationBarsPadding()
                    .padding(bottom = 26.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.72f))
                            .padding(horizontal = 14.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = quickBarFocusedLabel,
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(32.dp))
                            .background(Color(0xE0141923))
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        QuickBarAction(
                            icon = Icons.Default.HighQuality,
                            label = "Качество видео",
                            tint = Color.White,
                            modifier = Modifier.focusRequester(quickBarFirstFocusRequester),
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showVideoQualityDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Speed,
                            label = "Скорость (${uiState.playbackSpeed}x)",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showSpeedDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Audiotrack,
                            label = "Аудиодорожка",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showAudioTracksDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Subtitles,
                            label = "Субтитры",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { showSubtitlesDialog = true; interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.GraphicEq,
                            label = "Звук: ${audioSettings.mode.titleRu}",
                            tint = MaterialTheme.colorScheme.secondary,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { onOpenAudioSheet(); interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.AspectRatio,
                            label = "Масштаб экрана",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { cycleResizeMode(); interactionTick++ }
                        )
                        QuickBarAction(
                            icon = Icons.Default.Settings,
                            label = "Настройки плеера",
                            tint = Color.White,
                            onFocused = { quickBarFocusedLabel = it; interactionTick++ },
                            onClick = { onOpenSettingsSheet(); interactionTick++ }
                        )
                    }
                }
            }
        }

        // -------------------------------------------------------------------
        // HUD MODE 3: FULL CONTROLS (opened by 1st OK press without pausing)
        // -------------------------------------------------------------------
        AnimatedVisibility(
            visible = hudMode == HudMode.FULL,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)))
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackPressed, modifier = Modifier.tvFocusBorder(CircleShape)) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад", tint = Color.White)
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(
                            text = uiState.currentTitle,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val meta = listOfNotNull(
                            uiState.videoCodecInfo.takeIf { it.isNotBlank() },
                            uiState.audioCodecInfo.takeIf { it.isNotBlank() },
                            if (playerPrefs.autoPictureEnhance) "Улучшение картинки" else null,
                            uiState.sleepTimerRemainingMin?.let { "Сон: ${it}м" }
                                ?: if (uiState.sleepAtEndOfEpisode) "Сон: конец серии" else null
                        ).joinToString(" • ")
                        if (meta.isNotBlank()) {
                            Text(
                                text = meta,
                                color = Color.White.copy(alpha = 0.78f),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .tvFocusBorder(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                            .clickable(onClick = onOpenAudioSheet)
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = "Автонормализация",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.size(4.dp))
                        Text(
                            text = String.format(Locale.US, "%s (%+.1f дБ)", audioSettings.mode.name, telemetry.appliedGainDb),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Center Transport Controls
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (uiState.prevEpisode != null) {
                        IconButton(
                            onClick = { onPlayPrevEpisode(); interactionTick++ },
                            modifier = Modifier.size(48.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Предыдущая серия", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }

                    IconButton(
                        onClick = { triggerFastSeek(-1) },
                        modifier = Modifier.size(54.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Replay10, contentDescription = "Назад", tint = Color.White, modifier = Modifier.size(30.dp))
                    }

                    IconButton(
                        onClick = {
                            onTogglePlayPause()
                            interactionTick++
                        },
                        modifier = Modifier
                            .size(70.dp)
                            .focusRequester(playButtonFocusRequester)
                            .clip(CircleShape)
                            .tvFocusBorder(CircleShape, Color.White)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.92f))
                    ) {
                        Icon(
                            imageVector = if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Пауза / Старт",
                            tint = Color.Black,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    IconButton(
                        onClick = { triggerFastSeek(+1) },
                        modifier = Modifier.size(54.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Forward10, contentDescription = "Вперёд", tint = Color.White, modifier = Modifier.size(30.dp))
                    }

                    if (uiState.nextEpisode != null) {
                        IconButton(
                            onClick = { onPlayNextEpisode(); interactionTick++ },
                            modifier = Modifier.size(48.dp).clip(CircleShape).tvFocusBorder(CircleShape).background(Color.Black.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Следующая серия", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                    }
                }

                // Bottom Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.88f))))
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    val duration = uiState.durationMs.coerceAtLeast(1L)
                    val shownPos = if (isFastSeeking) fastSeekTargetMs else uiState.positionMs
                    Slider(
                        value = shownPos.coerceIn(0L, duration).toFloat(),
                        onValueChange = { onSeekTo(it.toLong()); interactionTick++ },
                        valueRange = 0f..duration.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${formatDuration(shownPos)} / ${formatDuration(uiState.durationMs)}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            IconButton(onClick = { showVideoQualityDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.HighQuality, contentDescription = "Качество видео", tint = Color.White)
                            }
                            IconButton(onClick = { showSpeedDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Speed, contentDescription = "Скорость", tint = Color.White)
                            }
                            IconButton(onClick = { showAudioTracksDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Audiotrack, contentDescription = "Аудиодорожка", tint = Color.White)
                            }
                            IconButton(onClick = { showSubtitlesDialog = true }, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Subtitles, contentDescription = "Субтитры", tint = Color.White)
                            }
                            IconButton(onClick = onOpenAudioSheet, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.GraphicEq, contentDescription = "Нормализация и EQ", tint = MaterialTheme.colorScheme.secondary)
                            }
                            IconButton(onClick = cycleResizeMode, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.AspectRatio, contentDescription = "Масштаб", tint = Color.White)
                            }
                            IconButton(onClick = onOpenSettingsSheet, modifier = Modifier.tvFocusBorder(CircleShape)) {
                                Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showVideoQualityDialog) {
        TrackPickerDialog(
            title = "Качество видео",
            tracks = uiState.videoTracks,
            autoOrDisableLabel = if (playerPrefs.alwaysBestQuality) "Авто (Максимальное)" else "Авто",
            onSelect = {
                onSelectVideoTrack(it)
                showVideoQualityDialog = false
            },
            onDismiss = { showVideoQualityDialog = false }
        )
    }

    if (showAudioTracksDialog) {
        TrackPickerDialog(
            title = "Аудиодорожка",
            tracks = uiState.audioTracks,
            autoOrDisableLabel = null,
            onSelect = {
                onSelectAudioTrack(it)
                showAudioTracksDialog = false
            },
            onDismiss = { showAudioTracksDialog = false }
        )
    }

    if (showSubtitlesDialog) {
        TrackPickerDialog(
            title = "Субтитры",
            tracks = uiState.subtitleTracks,
            autoOrDisableLabel = "Отключить",
            onSelect = {
                onSelectSubtitleTrack(it)
                showSubtitlesDialog = false
            },
            onDismiss = { showSubtitlesDialog = false }
        )
    }

    if (showSpeedDialog) {
        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Скорость воспроизведения") },
            text = {
                Column {
                    speeds.forEach { spd ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .tvFocusBorder(RoundedCornerShape(8.dp))
                                .clickable {
                                    onSpeedChange(spd)
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = uiState.playbackSpeed == spd, onClick = null)
                            Spacer(Modifier.size(8.dp))
                            Text("${spd}x")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) { Text("Закрыть") }
            }
        )
    }
}

@Composable
private fun QuickBarAction(
    icon: ImageVector,
    label: String,
    tint: Color,
    modifier: Modifier = Modifier,
    onFocused: (String) -> Unit,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(46.dp)
            .clip(CircleShape)
            .tvFocusBorder(CircleShape)
            .onFocusChanged { if (it.isFocused) onFocused(label) }
    ) {
        Icon(icon, contentDescription = label, tint = tint)
    }
}

@Composable
private fun TrackPickerDialog(
    title: String,
    tracks: List<TrackOption>,
    autoOrDisableLabel: String?,
    onSelect: (TrackOption?) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                if (autoOrDisableLabel != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .tvFocusBorder(RoundedCornerShape(8.dp))
                            .clickable { onSelect(null) }
                            .padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = tracks.none { it.isSelected }, onClick = null)
                        Spacer(Modifier.size(8.dp))
                        Text(autoOrDisableLabel)
                    }
                }
                if (tracks.isEmpty()) {
                    Text("Дорожки не обнаружены", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    tracks.forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .tvFocusBorder(RoundedCornerShape(8.dp))
                                .clickable { onSelect(opt) }
                                .padding(vertical = 8.dp, horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = opt.isSelected, onClick = null)
                            Spacer(Modifier.size(8.dp))
                            Text(opt.label)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Закрыть") }
        }
    )
}
