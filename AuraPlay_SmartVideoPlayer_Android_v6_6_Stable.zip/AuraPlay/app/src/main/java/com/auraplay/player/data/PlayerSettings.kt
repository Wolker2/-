package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение телевизора/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная плавность и стабильность, только встроенные кодеки устройства"
    )
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceEnabled: Boolean = false,
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
