package com.auraplay.player.audio

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.tanh

/**
 * Lossless-path 32-bit float PCM DSP engine:
 * 1. Multiband LR4 (250 Hz / 3.5 kHz) + Stereo Mid/Side + 5.1 Center Auto-Dialogue Balancer:
 *    tames explosions, gunfire, and loud music independently while keeping speech clear & steady.
 * 2. 5-band 64-bit parametric Equalizer.
 * 3. ITU-R BS.1770-4 / EBU R128 K-weighted loudness normalization with -55 LUFS silence gate.
 * 4. Channel-linked 5 ms look-ahead True-Peak Limiter (-1.0 dBTP ceiling).
 */
@OptIn(UnstableApi::class)
class SmartLoudnessAudioProcessor : BaseAudioProcessor() {

    private val settingsRef = AtomicReference(AudioNormalizationSettings())
    private val _telemetry = MutableStateFlow(AudioTelemetry())
    val telemetry: StateFlow<AudioTelemetry> = _telemetry.asStateFlow()

    private var sampleRate = 48000
    private var channelCount = 2
    private var isFloatEncoding = true

    private var preFilters: Array<BiquadFilter> = emptyArray()
    private var rlbFilters: Array<BiquadFilter> = emptyArray()
    private var voiceEqFilters: Array<BiquadFilter> = emptyArray()
    private var eqFilters: Array<Array<BiquadFilter>> = emptyArray()

    // 3-band Linkwitz-Riley 4th-order crossover per channel (250 Hz & 3500 Hz)
    private var lowLp: Array<LR4Filter> = emptyArray()
    private var lowHp: Array<LR4Filter> = emptyArray()
    private var highLp: Array<LR4Filter> = emptyArray()
    private var highHp: Array<LR4Filter> = emptyArray()

    // Smooth band RMS envelopes (shared across channels to preserve stereo/surround imaging)
    private var envLowSq = 1e-7
    private var envMidSq = 1e-7
    private var envHighSq = 1e-7
    private var envSideSq = 1e-7
    private var envCenterSq = 1e-7
    private var envEffectsSq = 1e-7

    private var gainLowLin = 1.0
    private var gainMidLin = 1.0
    private var gainHighLin = 1.0
    private var gainSideLin = 1.0
    private var gainCenterLin = 1.0
    private var gainEffectsLin = 1.0

    @Volatile
    private var appliedEqBands: List<Float> = listOf(0f, 0f, 0f, 0f, 0f)

    private var momentaryMeanSq = 1e-7
    private var shortTermMeanSq = 1e-7
    private var currentAgcGainDb = 0.0

    private var lookAheadFrames = 240
    private var delayBuffer = FloatArray(0)
    private var peakRingBuffer = FloatArray(0)
    private var delayWritePos = 0
    private var limiterGain = 1.0

    private var framesSinceTelemetry = 0
    private var telemetryIntervalFrames = 3200
    private var peakTrackerLinear = 1e-7f

    fun updateSettings(settings: AudioNormalizationSettings) {
        settingsRef.set(settings)
    }

    fun getSettings(): AudioNormalizationSettings = settingsRef.get()

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val encoding = inputAudioFormat.encoding
        if (encoding != C.ENCODING_PCM_FLOAT && encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(8000)
        channelCount = inputAudioFormat.channelCount.coerceAtLeast(1)
        isFloatEncoding = (encoding == C.ENCODING_PCM_FLOAT)
        initDspState()
        return inputAudioFormat
    }

    private fun initDspState() {
        val sr = sampleRate.toDouble()
        preFilters = Array(channelCount) { BiquadFilter.kWeightingPreFilter(sr) }
        rlbFilters = Array(channelCount) { BiquadFilter.kWeightingRlbFilter(sr) }
        voiceEqFilters = Array(channelCount) { BiquadFilter.peakingEq(sr, 2400.0, 1.1, 3.0) }
        rebuildEqFilters(settingsRef.get().eqBandsDb)

        lowLp = Array(channelCount) { LR4Filter.lowPass(sr, 250.0) }
        lowHp = Array(channelCount) { LR4Filter.highPass(sr, 250.0) }
        highLp = Array(channelCount) { LR4Filter.lowPass(sr, 3500.0) }
        highHp = Array(channelCount) { LR4Filter.highPass(sr, 3500.0) }

        envLowSq = 1e-7
        envMidSq = 1e-7
        envHighSq = 1e-7
        envSideSq = 1e-7
        envCenterSq = 1e-7
        envEffectsSq = 1e-7
        gainLowLin = 1.0
        gainMidLin = 1.0
        gainHighLin = 1.0
        gainSideLin = 1.0
        gainCenterLin = 1.0
        gainEffectsLin = 1.0

        lookAheadFrames = max(32, (sampleRate * 0.005).toInt())
        delayBuffer = FloatArray(lookAheadFrames * channelCount)
        peakRingBuffer = FloatArray(lookAheadFrames)
        delayWritePos = 0

        momentaryMeanSq = 1e-7
        shortTermMeanSq = 1e-7
        currentAgcGainDb = 0.0
        limiterGain = 1.0
        peakTrackerLinear = 1e-7f
        framesSinceTelemetry = 0
        telemetryIntervalFrames = max(4096, sampleRate / 2)
    }

    private fun rebuildEqFilters(bands: List<Float>) {
        val sr = sampleRate.toDouble()
        val freqs = doubleArrayOf(60.0, 230.0, 910.0, 3600.0, 14000.0)
        val qs = doubleArrayOf(0.9, 1.0, 1.0, 1.0, 0.85)
        eqFilters = Array(channelCount) {
            Array(5) { b ->
                val gain = bands.getOrElse(b) { 0f }.toDouble().coerceIn(-8.0, 8.0)
                BiquadFilter.peakingEq(sr, freqs[b], qs[b], gain)
            }
        }
        appliedEqBands = bands.toList()
    }

    override fun onFlush(streamMetadata: AudioProcessor.StreamMetadata) {
        initDspState()
    }

    override fun onReset() {
        delayBuffer = FloatArray(0)
        peakRingBuffer = FloatArray(0)
        preFilters = emptyArray()
        rlbFilters = emptyArray()
        voiceEqFilters = emptyArray()
        eqFilters = emptyArray()
        lowLp = emptyArray()
        lowHp = emptyArray()
        highLp = emptyArray()
        highHp = emptyArray()
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val settings = settingsRef.get()
        val outputBuffer = replaceOutputBuffer(remaining)

        val anyProcessing = (settings.mode != NormalizationMode.BYPASS) ||
            settings.eqEnabled ||
            settings.dialogueBalancerEnabled

        if (!anyProcessing) {
            outputBuffer.put(inputBuffer)
            outputBuffer.flip()
            emitTelemetry(-70f, -70f, 0f, 0f, -70f, NormalizationMode.BYPASS)
            return
        }

        if (settings.eqEnabled && settings.eqBandsDb != appliedEqBands && channelCount > 0) {
            rebuildEqFilters(settings.eqBandsDb)
        }

        val bytesPerSample = if (isFloatEncoding) 4 else 2
        val frameSizeBytes = bytesPerSample * channelCount
        val frameCount = remaining / frameSizeBytes
        if (frameCount <= 0) {
            outputBuffer.flip()
            return
        }

        val sr = sampleRate.toDouble()
        val momentaryAlpha = 1.0 - exp(-1.0 / (0.400 * sr))
        val shortTermAlpha = 1.0 - exp(-1.0 / (3.000 * sr))
        val agcAttackAlpha = 1.0 - exp(-1.0 / ((settings.mode.attackMs / 1000.0) * sr))
        val agcReleaseAlpha = 1.0 - exp(-1.0 / ((settings.mode.releaseMs / 1000.0) * sr))
        val limiterAttackAlpha = 1.0 - exp(-1.0 / (0.0015 * sr))
        val limiterReleaseAlpha = 1.0 - exp(-1.0 / (0.080 * sr))

        // Multiband smooth time constants (transparent, zero pumping)
        val bandEnvAlpha = 1.0 - exp(-1.0 / (0.045 * sr))
        val bandAttackAlpha = 1.0 - exp(-1.0 / (0.015 * sr))
        val bandReleaseAlpha = 1.0 - exp(-1.0 / (0.220 * sr))

        val ceilingLinear = dbToLinear(settings.truePeakCeilingDb.toDouble())
        val softKneeStart = ceilingLinear * 0.944
        val enableVoiceEq = settings.mode.enableVoicePresenceEq
        val enableNorm = settings.mode != NormalizationMode.BYPASS
        val enableEq = settings.eqEnabled && eqFilters.size == channelCount
        val enableBalancer = settings.dialogueBalancerEnabled && lowLp.size == channelCount
        val bal = settings.dialogueBalancerStrength

        val frameSamples = DoubleArray(channelCount)
        val lowBand = DoubleArray(channelCount)
        val midBand = DoubleArray(channelCount)
        val highBand = DoubleArray(channelCount)

        for (f in 0 until frameCount) {
            // 1. Read frame in 64-bit double precision
            for (ch in 0 until channelCount) {
                frameSamples[ch] = if (isFloatEncoding) {
                    inputBuffer.float.toDouble()
                } else {
                    inputBuffer.short.toDouble() / 32768.0
                }
            }

            // 2. Smart Auto-Dialogue Balancer (3-Band LR4 + Stereo Mid/Side + 5.1 Center Priority)
            if (enableBalancer) {
                // 2a. Multi-channel 5.1/7.1 Center vs Effects separation
                if (channelCount >= 6) {
                    val cSq = frameSamples[2] * frameSamples[2]
                    var effSq = 0.0
                    for (ch in 0 until channelCount) {
                        if (ch != 2) effSq += frameSamples[ch] * frameSamples[ch]
                    }
                    effSq /= (channelCount - 1).toDouble()
                    envCenterSq += bandEnvAlpha * (cSq - envCenterSq)
                    envEffectsSq += bandEnvAlpha * (effSq - envEffectsSq)

                    val centerDb = 10.0 * log10(max(envCenterSq, 1e-10))
                    val effectsDb = 10.0 * log10(max(envEffectsSq, 1e-10))
                    val excessEffectsDb = (effectsDb - centerDb - 2.0).coerceIn(0.0, 18.0)

                    val targetEffectsGain = if (centerDb > -48.0 && excessEffectsDb > 0.0) {
                        dbToLinear(-minOf(excessEffectsDb * 0.45, bal.sideDuckMaxDb))
                    } else 1.0
                    val targetCenterGain = if (centerDb > -48.0) {
                        dbToLinear(bal.centerLiftDb)
                    } else 1.0

                    val ea = if (targetEffectsGain < gainEffectsLin) bandAttackAlpha else bandReleaseAlpha
                    gainEffectsLin += ea * (targetEffectsGain - gainEffectsLin)
                    val ca = if (targetCenterGain < gainCenterLin) bandAttackAlpha else bandReleaseAlpha
                    gainCenterLin += ca * (targetCenterGain - gainCenterLin)

                    for (ch in 0 until channelCount) {
                        frameSamples[ch] *= if (ch == 2) gainCenterLin else gainEffectsLin
                    }
                } else if (channelCount == 2) {
                    // 2b. Stereo Mid/Side balance (voice in Mid, music/explosions wider in Side)
                    val mid = 0.5 * (frameSamples[0] + frameSamples[1])
                    val side = 0.5 * (frameSamples[0] - frameSamples[1])
                    envSideSq += bandEnvAlpha * (side * side - envSideSq)
                    val midDb = 10.0 * log10(max(mid * mid, 1e-10))
                    val sideDb = 10.0 * log10(max(envSideSq, 1e-10))
                    val sideExcess = (sideDb - max(midDb, -42.0) - 1.5).coerceIn(0.0, 14.0)
                    val targetSideGain = if (sideDb > -45.0 && sideExcess > 0.0) {
                        dbToLinear(-minOf(sideExcess * 0.45, bal.sideDuckMaxDb))
                    } else 1.0
                    val sa = if (targetSideGain < gainSideLin) bandAttackAlpha else bandReleaseAlpha
                    gainSideLin += sa * (targetSideGain - gainSideLin)

                    val balancedSide = side * gainSideLin
                    frameSamples[0] = mid + balancedSide
                    frameSamples[1] = mid - balancedSide
                }

                // 2c. 3-Band LR4 Dynamic Balance (Low <250Hz, Voice 250-3500Hz, High >3500Hz)
                var sumLowSq = 0.0
                var sumMidSq = 0.0
                var sumHighSq = 0.0
                for (ch in 0 until channelCount) {
                    val x = frameSamples[ch]
                    val lo = lowLp[ch].process(x)
                    val midHigh = lowHp[ch].process(x)
                    val mi = highLp[ch].process(midHigh)
                    val hi = highHp[ch].process(midHigh)
                    lowBand[ch] = lo
                    midBand[ch] = mi
                    highBand[ch] = hi
                    sumLowSq += lo * lo
                    sumMidSq += mi * mi
                    sumHighSq += hi * hi
                }
                val invCh = 1.0 / channelCount.toDouble()
                envLowSq += bandEnvAlpha * (sumLowSq * invCh - envLowSq)
                envMidSq += bandEnvAlpha * (sumMidSq * invCh - envMidSq)
                envHighSq += bandEnvAlpha * (sumHighSq * invCh - envHighSq)

                val lowDb = 10.0 * log10(max(envLowSq, 1e-10))
                val midDb = 10.0 * log10(max(envMidSq, 1e-10))
                val highDb = 10.0 * log10(max(envHighSq, 1e-10))

                // Soft-knee compression on explosions/bass (> -18 dBFS) & harsh highs (> -20 dBFS)
                val targetLowGain = computeSoftKneeGain(lowDb, -18.0, bal.bassCompressionRatio, 6.0)
                val targetHighGain = computeSoftKneeGain(highDb, -20.0, bal.highCompressionRatio, 6.0)

                // Subtle speech presence lift when speech band is active & bass/highs are loud
                val speechPresent = midDb > -48.0
                val actionActivity = ((max(lowDb, highDb) - midDb) / 12.0).coerceIn(0.0, 1.0)
                val targetMidGain = if (speechPresent) {
                    dbToLinear(bal.voiceLiftDb * (0.45 + 0.55 * actionActivity))
                } else 1.0

                gainLowLin += (if (targetLowGain < gainLowLin) bandAttackAlpha else bandReleaseAlpha) * (targetLowGain - gainLowLin)
                gainMidLin += (if (targetMidGain < gainMidLin) bandAttackAlpha else bandReleaseAlpha) * (targetMidGain - gainMidLin)
                gainHighLin += (if (targetHighGain < gainHighLin) bandAttackAlpha else bandReleaseAlpha) * (targetHighGain - gainHighLin)

                for (ch in 0 until channelCount) {
                    frameSamples[ch] = lowBand[ch] * gainLowLin +
                        midBand[ch] * gainMidLin +
                        highBand[ch] * gainHighLin
                }
            }

            // 3. Optional 5-band Equalizer + Voice Clarity EQ + K-weighted Loudness Metering
            var kWeightedEnergySum = 0.0
            for (ch in 0 until channelCount) {
                var sampleDouble = frameSamples[ch]
                if (enableEq) {
                    val chEq = eqFilters[ch]
                    for (b in 0 until 5) {
                        sampleDouble = chEq[b].process(sampleDouble)
                    }
                }
                if (enableVoiceEq) {
                    sampleDouble = voiceEqFilters[ch].process(sampleDouble)
                }
                frameSamples[ch] = sampleDouble

                val chWeight = getChannelWeight(ch, channelCount)
                if (chWeight > 0.0) {
                    val stage1 = preFilters[ch].process(sampleDouble)
                    val kWeighted = rlbFilters[ch].process(stage1)
                    kWeightedEnergySum += chWeight * kWeighted * kWeighted
                }
            }

            // 4. EBU R128 Adaptive Loudness Leveler with Silence Gate
            momentaryMeanSq += momentaryAlpha * (kWeightedEnergySum - momentaryMeanSq)
            shortTermMeanSq += shortTermAlpha * (kWeightedEnergySum - shortTermMeanSq)

            val momentaryLufs = -0.691 + 10.0 * log10(max(momentaryMeanSq, 1e-10))
            val shortTermLufs = -0.691 + 10.0 * log10(max(shortTermMeanSq, 1e-10))

            if (enableNorm) {
                val blendedLufs = if (settings.mode == NormalizationMode.NIGHT) {
                    0.55 * momentaryLufs + 0.45 * shortTermLufs
                } else {
                    0.25 * momentaryLufs + 0.75 * shortTermLufs
                }

                if (momentaryLufs > settings.silenceGateLufs) {
                    val desiredGainDb = (settings.targetLufs - blendedLufs)
                        .coerceIn(-18.0, settings.maxBoostDb.toDouble())
                    val alpha = if (desiredGainDb < currentAgcGainDb) agcAttackAlpha else agcReleaseAlpha
                    currentAgcGainDb += alpha * (desiredGainDb - currentAgcGainDb)
                } else {
                    currentAgcGainDb += (agcReleaseAlpha * 0.15) * (0.0 - currentAgcGainDb)
                }
            } else {
                currentAgcGainDb = 0.0
            }

            val agcLinear = dbToLinear(currentAgcGainDb)

            // 5. Channel-linked 5 ms Look-Ahead True-Peak Limiter
            var framePeak = 0.0f
            val writeBase = delayWritePos * channelCount
            for (ch in 0 until channelCount) {
                val scaled = (frameSamples[ch] * agcLinear).toFloat()
                delayBuffer[writeBase + ch] = scaled
                val absVal = abs(scaled)
                if (absVal > framePeak) framePeak = absVal
            }
            peakRingBuffer[delayWritePos] = framePeak

            val readPos = (delayWritePos + 1) % lookAheadFrames
            delayWritePos = readPos

            var windowMaxPeak = 0.0f
            for (i in 0 until lookAheadFrames) {
                val p = peakRingBuffer[i]
                if (p > windowMaxPeak) windowMaxPeak = p
            }

            val targetLimiterGain = if (windowMaxPeak > ceilingLinear) {
                ceilingLinear / windowMaxPeak.toDouble()
            } else {
                1.0
            }

            val limAlpha = if (targetLimiterGain < limiterGain) limiterAttackAlpha else limiterReleaseAlpha
            limiterGain += limAlpha * (targetLimiterGain - limiterGain)

            val readBase = readPos * channelCount
            for (ch in 0 until channelCount) {
                var outSample = (delayBuffer[readBase + ch] * limiterGain).toDouble()
                val absOut = abs(outSample)
                if (absOut > softKneeStart) {
                    val excess = absOut - softKneeStart
                    val headroom = (ceilingLinear - softKneeStart).coerceAtLeast(1e-4)
                    val shaped = softKneeStart + headroom * tanh(excess / headroom)
                    outSample = if (outSample >= 0.0) shaped else -shaped
                }

                val outFloat = outSample.toFloat()
                val absFinal = abs(outFloat)
                if (absFinal > peakTrackerLinear) peakTrackerLinear = absFinal

                if (isFloatEncoding) {
                    outputBuffer.putFloat(outFloat)
                } else {
                    val pcm16 = (outFloat * 32767.0f).toInt().coerceIn(-32768, 32767).toShort()
                    outputBuffer.putShort(pcm16)
                }
            }

            framesSinceTelemetry++
            if (framesSinceTelemetry >= telemetryIntervalFrames) {
                framesSinceTelemetry = 0
                val limRedDb = if (limiterGain < 0.9999) (20.0 * log10(limiterGain)).toFloat() else 0f
                val peakDb = (20.0 * log10(max(peakTrackerLinear.toDouble(), 1e-6))).toFloat()
                peakTrackerLinear = 1e-7f
                emitTelemetry(
                    momentaryLufs = momentaryLufs.toFloat().coerceIn(-70f, 0f),
                    shortTermLufs = shortTermLufs.toFloat().coerceIn(-70f, 0f),
                    appliedGainDb = currentAgcGainDb.toFloat(),
                    limiterReductionDb = limRedDb,
                    truePeakDbtp = peakDb.coerceIn(-70f, 0f),
                    mode = settings.mode
                )
            }
        }

        outputBuffer.flip()
    }

    private fun computeSoftKneeGain(levelDb: Double, thresholdDb: Double, ratio: Double, kneeDb: Double): Double {
        val halfKnee = kneeDb * 0.5
        val gainReductionDb = when {
            levelDb <= thresholdDb - halfKnee -> 0.0
            levelDb >= thresholdDb + halfKnee -> (levelDb - thresholdDb) * (1.0 - 1.0 / ratio)
            else -> {
                val x = levelDb - thresholdDb + halfKnee
                ((1.0 - 1.0 / ratio) * x * x) / (2.0 * kneeDb)
            }
        }
        return dbToLinear(-gainReductionDb.coerceAtMost(12.0))
    }

    private fun emitTelemetry(
        momentaryLufs: Float,
        shortTermLufs: Float,
        appliedGainDb: Float,
        limiterReductionDb: Float,
        truePeakDbtp: Float,
        mode: NormalizationMode
    ) {
        _telemetry.value = AudioTelemetry(
            momentaryLufs = momentaryLufs,
            shortTermLufs = shortTermLufs,
            appliedGainDb = appliedGainDb,
            limiterReductionDb = limiterReductionDb,
            truePeakDbtp = truePeakDbtp,
            sampleRateHz = sampleRate,
            channelCount = channelCount,
            isFloatPipeline = isFloatEncoding,
            mode = mode
        )
    }

    private fun getChannelWeight(channelIndex: Int, totalChannels: Int): Double {
        if (totalChannels <= 2) return 1.0
        return when (channelIndex) {
            3 -> 0.0
            4, 5, 6, 7 -> 1.4125375446227544
            else -> 1.0
        }
    }

    private fun dbToLinear(db: Double): Double = 10.0.pow(db / 20.0)
}
