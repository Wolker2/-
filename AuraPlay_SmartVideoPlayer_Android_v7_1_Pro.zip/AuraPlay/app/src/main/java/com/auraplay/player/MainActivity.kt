package com.auraplay.player

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import com.auraplay.player.ui.AudioNormalizationSheet
import com.auraplay.player.ui.HomeScreen
import com.auraplay.player.ui.PlayerScreen
import com.auraplay.player.ui.PlayerViewModel
import com.auraplay.player.ui.SettingsSheet
import com.auraplay.player.ui.theme.AuraPlayTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PlayerViewModel by viewModels()
    private var returnResultRequested: Boolean = false
    private var resultDelivered: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        setContent {
            AuraPlayTheme {
                val exoPlayer by viewModel.playerInstance.collectAsState()
                val videos by viewModel.videos.collectAsState()
                val uiState by viewModel.uiState.collectAsState()
                val audioSettings by viewModel.audioSettings.collectAsState()
                val playerPrefs by viewModel.playerPrefs.collectAsState()

                var showAudioSheet by remember { mutableStateOf(false) }
                var showSettingsSheet by remember { mutableStateOf(false) }

                val storagePermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    Manifest.permission.READ_MEDIA_VIDEO
                } else {
                    Manifest.permission.READ_EXTERNAL_STORAGE
                }

                var hasPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(this, storagePermission) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { granted ->
                    hasPermission = granted
                    if (granted) viewModel.refreshLocalVideos()
                }

                val filePickerLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri: Uri? ->
                    if (uri != null) {
                        runCatching {
                            contentResolver.takePersistableUriPermission(
                                uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                        viewModel.playMedia(uri, resolveDisplayName(uri), launchedExternally = false)
                    }
                }

                val isPlayerOpen = uiState.currentUri != null
                LaunchedEffect(hasPermission, isPlayerOpen) {
                    if (hasPermission && !isPlayerOpen) viewModel.refreshLocalVideos()
                }
                LaunchedEffect(isPlayerOpen) {
                    setImmersiveSystemBars(isPlayerOpen)
                    requestedOrientation = if (isPlayerOpen) {
                        ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                    } else {
                        ActivityInfo.SCREEN_ORIENTATION_FULL_USER
                    }
                }

                val handlePlayerBack: () -> Unit = {
                    if (playerPrefs.backReturnsToHome) {
                        viewModel.closePlayerToHome()
                    } else {
                        // Do NOT clear currentUri before finish() — eliminates HomeScreen flicker!
                        deliverPlaybackResultIfNeeded()
                        viewModel.stopForExit()
                        finish()
                    }
                }

                if (isPlayerOpen) {
                    BackHandler { handlePlayerBack() }
                    PlayerScreen(
                        exoPlayer = exoPlayer,
                        uiState = uiState,
                        audioSettings = audioSettings,
                        playerPrefs = playerPrefs,
                        telemetryFlow = viewModel.telemetry,
                        onBackPressed = handlePlayerBack,
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSeekTo = { viewModel.seekTo(it) },
                        onSelectDecoderMode = { viewModel.updatePlayerPrefs(playerPrefs.copy(decoderMode = it)) },
                        onCycleAudioMode = { viewModel.cycleNormalizationMode() },
                        onSelectEpisode = { viewModel.playVideoItem(it) },
                        onPlayNextEpisode = { viewModel.playNextEpisode() },
                        onPlayPrevEpisode = { viewModel.playPreviousEpisode() },
                        onCancelNextCountdown = { viewModel.cancelNextEpisodeCountdown() },
                        onOpenAudioSheet = { showAudioSheet = true },
                        onOpenSettingsSheet = { showSettingsSheet = true },
                        onSelectVideoTrack = { viewModel.selectTrack(C.TRACK_TYPE_VIDEO, it) },
                        onSelectAudioTrack = { viewModel.selectTrack(C.TRACK_TYPE_AUDIO, it) },
                        onSelectSubtitleTrack = { viewModel.selectTrack(C.TRACK_TYPE_TEXT, it) },
                        onHudVisibilityChanged = { viewModel.setHudVisible(it) }
                    )
                } else {
                    HomeScreen(
                        videos = videos,
                        audioSettings = audioSettings,
                        playerPrefs = playerPrefs,
                        hasStoragePermission = hasPermission,
                        onRequestPermission = { permissionLauncher.launch(storagePermission) },
                        onRefresh = { viewModel.refreshLocalVideos() },
                        onPickFile = { filePickerLauncher.launch(arrayOf("video/*", "*/*")) },
                        onOpenUrl = { uri, title -> viewModel.playMedia(uri, title, launchedExternally = false) },
                        onSelectVideo = { viewModel.playVideoItem(it) },
                        onOpenAudioSettings = { showAudioSheet = true },
                        onOpenSettings = { showSettingsSheet = true }
                    )
                }

                if (showAudioSheet) {
                    val audioTelemetry by viewModel.telemetry.collectAsState()
                    AudioNormalizationSheet(
                        settings = audioSettings,
                        telemetry = audioTelemetry,
                        onSelectMode = { viewModel.setNormalizationMode(it) },
                        onTargetLufsChange = { viewModel.updateTargetLufs(it) },
                        onMaxBoostChange = { viewModel.updateMaxBoostDb(it) },
                        onDialogueBalancerToggle = { viewModel.setDialogueBalancerEnabled(it) },
                        onDialogueBalancerStrength = { viewModel.setDialogueBalancerStrength(it) },
                        onEqEnabledChange = { viewModel.setEqEnabled(it) },
                        onEqPresetSelect = { viewModel.setEqPreset(it) },
                        onEqBandChange = { idx, gain -> viewModel.setEqBand(idx, gain) },
                        onDismiss = { showAudioSheet = false }
                    )
                }

                if (showSettingsSheet) {
                    SettingsSheet(
                        prefs = playerPrefs,
                        uiState = uiState,
                        isInsidePlayer = isPlayerOpen,
                        onUpdatePrefs = { viewModel.updatePlayerPrefs(it) },
                        onSleepTimerSelect = { viewModel.setSleepTimerMinutes(it) },
                        onOpenAudioSheet = { showAudioSheet = true },
                        onGoToHomeLibrary = { viewModel.closePlayerToHome() },
                        onDismiss = { showSettingsSheet = false }
                    )
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Close player completely when user presses Home or minimizes app (ignore phone rotation)
        if (!isChangingConfigurations) {
            deliverPlaybackResultIfNeeded()
            viewModel.stopForExit()
            finishAndRemoveTask()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { uri ->
                val explicitTitle = intent.getStringExtra("title")
                    ?: intent.getStringExtra(Intent.EXTRA_TITLE)
                    ?: resolveDisplayName(uri)

                // Parse playlist extras from Lampa, TorrServe, MX-compatible apps, Kodi, Nova
                val uriList = mutableListOf<Uri>()
                for (key in listOf("video_list", "playlist", "episodes", "urls")) {
                    if (uriList.isNotEmpty()) break
                    @Suppress("DEPRECATION")
                    intent.getParcelableArrayExtra(key)?.forEach { p ->
                        if (p is Uri) uriList.add(p)
                    }
                    if (uriList.isEmpty()) {
                        @Suppress("DEPRECATION")
                        intent.getParcelableArrayListExtra<Uri>(key)?.let { uriList.addAll(it) }
                    }
                    if (uriList.isEmpty()) {
                        intent.getStringArrayExtra(key)?.forEach { s ->
                            if (s.isNotBlank()) uriList.add(Uri.parse(s))
                        }
                    }
                    if (uriList.isEmpty()) {
                        intent.getStringArrayListExtra(key)?.forEach { s ->
                            if (s.isNotBlank()) uriList.add(Uri.parse(s))
                        }
                    }
                }
                val nameList = intent.getStringArrayExtra("video_list.name")?.toList()
                    ?: intent.getStringArrayListExtra("video_list.name")?.toList()
                    ?: intent.getStringArrayExtra("video_list.filename")?.toList()
                    ?: intent.getStringArrayListExtra("video_list.filename")?.toList()
                    ?: intent.getStringArrayExtra("playlist.name")?.toList()
                    ?: emptyList()

                // Parse HTTP headers (MX Player String[] pairs, Bundle, or direct Referer/User-Agent)
                val headers = mutableMapOf<String, String>()
                intent.getStringArrayExtra("headers")?.let { arr ->
                    var i = 0
                    while (i + 1 < arr.size) {
                        val k = arr[i]?.trim().orEmpty()
                        val v = arr[i + 1]?.trim().orEmpty()
                        if (k.isNotEmpty() && v.isNotEmpty()) headers[k] = v
                        i += 2
                    }
                }
                intent.getBundleExtra("headers")?.let { b ->
                    for (k in b.keySet()) {
                        b.getString(k)?.trim()?.takeIf { it.isNotEmpty() }?.let { v -> headers[k] = v }
                    }
                }
                intent.getStringExtra("referer")?.let { headers["Referer"] = it }
                intent.getStringExtra("user_agent")?.let { headers["User-Agent"] = it }

                val startPositionMs: Long? = if (intent.hasExtra("position")) {
                    val longPos = intent.getLongExtra("position", -1L)
                    val intPos = intent.getIntExtra("position", -1)
                    when {
                        longPos > 0L -> longPos
                        intPos > 0 -> intPos.toLong()
                        else -> null
                    }
                } else null

                returnResultRequested = intent.getBooleanExtra("return_result", false)
                resultDelivered = false

                val subUris = mutableListOf<Uri>()
                @Suppress("DEPRECATION")
                intent.getParcelableArrayExtra("subs")?.forEach { p -> if (p is Uri) subUris.add(p) }
                if (subUris.isEmpty()) {
                    @Suppress("DEPRECATION")
                    intent.getParcelableArrayListExtra<Uri>("subs")?.let { subUris.addAll(it) }
                }
                val subNames = intent.getStringArrayExtra("subs.name")?.toList()
                    ?: intent.getStringArrayListExtra("subs.name")?.toList()
                    ?: intent.getStringArrayExtra("subs.filename")?.toList()
                    ?: emptyList()
                val externalSubtitles = subUris.mapIndexed { idx, subUri ->
                    subUri to subNames.getOrNull(idx)?.takeIf { it.isNotBlank() }
                }

                viewModel.playExternalWithPlaylist(
                    uri = uri,
                    title = explicitTitle,
                    playlistUris = uriList,
                    playlistNames = nameList,
                    httpHeaders = headers,
                    startPositionMs = startPositionMs,
                    externalSubtitles = externalSubtitles
                )
            }
        }
    }

    private fun deliverPlaybackResultIfNeeded() {
        if (!returnResultRequested || resultDelivered) return
        resultDelivered = true
        val (posMs, durMs, endedNaturally) = viewModel.getPlaybackResultSnapshot()
        val resultIntent = Intent("com.mxtech.intent.result.VIEW").apply {
            data = viewModel.uiState.value.currentUri
            putExtra("end_by", if (endedNaturally) "playback_completion" else "user")
            if (!endedNaturally && posMs > 0L) {
                putExtra("position", posMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            }
            if (durMs > 0L) {
                putExtra("duration", durMs.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            }
        }
        setResult(Activity.RESULT_OK, resultIntent)
    }

    private fun resolveDisplayName(uri: Uri): String {
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val name = cursor.getString(0)
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast("/") ?: "Видео"
    }

    private fun setImmersiveSystemBars(immersive: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (immersive) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}
