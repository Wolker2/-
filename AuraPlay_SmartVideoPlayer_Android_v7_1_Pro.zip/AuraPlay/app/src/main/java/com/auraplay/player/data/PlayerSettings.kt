package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    STANDARD(
        "Аппаратный + FFmpeg (Стандарт)",
        "Фиксированное лучшее качество: видео декодирует чип ТВ, а FFmpeg подключается для DTS/AC3/TrueHD/AV1"
    ),
    HDR_HARDWARE(
        "Аппаратный HDR (10-bit)",
        "Прямой аппаратный вывод HDR10 / HLG / 10-bit на телевизор без программных фильтров"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Программное декодирование FFmpeg/dav1d, если аппаратный чип даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Только встроенные системные кодеки устройства без FFmpeg"
    )
}

enum class PreferredAudioLanguage(val titleRu: String, val isoCodes: List<String>) {
    AUTO("Авто (как в файле)", emptyList()),
    RUSSIAN("Русский (RU)", listOf("ru", "rus")),
    UKRAINIAN("Украинский (UK)", listOf("uk", "ukr")),
    ENGLISH("Английский (EN)", listOf("en", "eng"))
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.STANDARD,
    val preferredAudioLanguage: PreferredAudioLanguage = PreferredAudioLanguage.AUTO,
    val autoDisableSubtitles: Boolean = false,
    val audioDelayMs: Int = 0, // 0 .. 500 ms (audio sync delay for Bluetooth / out-of-sync rips)
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
