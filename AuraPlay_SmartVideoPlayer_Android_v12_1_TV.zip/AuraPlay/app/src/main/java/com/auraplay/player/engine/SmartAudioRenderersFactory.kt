package com.auraplay.player.engine

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.auraplay.player.audio.SmartLoudnessAudioProcessor
import com.auraplay.player.data.DecoderMode
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory

@OptIn(UnstableApi::class)
class SmartAudioRenderersFactory(
    context: Context,
    private val smartLoudnessProcessor: SmartLoudnessAudioProcessor,
    decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    private val lowEndTvMode: Boolean = false
) : NextRenderersFactory(context) {

    init {
        val effectiveMode = if (lowEndTvMode) DecoderMode.HARDWARE_ONLY else decoderMode
        val extMode = when (effectiveMode) {
            DecoderMode.AUTO_HYBRID -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
            DecoderMode.PREFER_FFMPEG -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
            DecoderMode.HARDWARE_ONLY -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF
        }
        setExtensionRendererMode(extMode)
        setEnableDecoderFallback(true)
    }

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink {
        return DefaultAudioSink.Builder(context)
            .setEnableFloatOutput(!lowEndTvMode) // Native 16-bit PCM on weak TVs avoids OS float resampling stutter
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessors(arrayOf(smartLoudnessProcessor))
            .build()
    }
}
