package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение ТВ/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная плавность и экономия ресурсов, только системные кодеки"
    )
}

enum class PictureEnhanceMode(
    val titleRu: String,
    val descriptionRu: String,
    val midContrast: Double,
    val shadowLift: Double,
    val highlightRoll: Double,
    val saturation: Double,
    val redScale: Double,
    val blueScale: Double,
    val clarity: Float = 0f,
    val sharpness: Float = 0f
) {
    OFF("Отключить", "Оригинальная картинка без GPU-обработки (максимальная плавность и HDR)", 0.0, 0.0, 0.0, 1.00, 1.00, 1.00),
    ANIME("Аниме", "Сочные чистые цвета и контраст в 1 лёгкий проход 3D-LUT без провала теней", 0.16, 0.030, -0.025, 1.30, 1.00, 1.02),
    ANIME_2("Аниме 2", "Чёткость (Clarity) 20% + Резкость (Sharpness) 15% в 1 быстрый GPU-проход", 0.0, 0.0, 0.0, 1.05, 1.00, 1.00, clarity = 0.20f, sharpness = 0.15f),
    AUTO("Авто", "Умный 3D-LUT: мягко осветляет тёмные тени и слегка приглушает пересветы", 0.09, 0.085, -0.095, 1.08, 1.00, 1.00)
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val lowEndTvMode: Boolean = false,
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceMode: PictureEnhanceMode = PictureEnhanceMode.OFF,
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
