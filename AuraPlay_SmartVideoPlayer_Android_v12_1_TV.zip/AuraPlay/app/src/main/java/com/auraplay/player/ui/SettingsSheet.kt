package com.auraplay.player.ui

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.auraplay.player.data.DecoderMode
import com.auraplay.player.data.PictureEnhanceMode
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.data.SubtitleSize
import com.auraplay.player.ui.theme.tvFocusBorder

@Composable
fun SettingsSheet(
    prefs: PlayerPreferences,
    uiState: PlayerUiState,
    isInsidePlayer: Boolean,
    onUpdatePrefs: (PlayerPreferences) -> Unit,
    onSleepTimerSelect: (Int?) -> Unit,
    onOpenAudioSheet: () -> Unit,
    onGoToHomeLibrary: () -> Unit,
    onDismiss: () -> Unit
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }

    val seekSteps = listOf(5, 10, 15, 30)
    val sleepOptions = listOf(null to "Выкл", 15 to "15 мин", 30 to "30 мин", 60 to "60 мин", -1 to "Конец серии")
    val currentSleepIdx = sleepOptions.indexOfFirst { (v, _) ->
        when (v) {
            null -> uiState.sleepTimerRemainingMin == null && !uiState.sleepAtEndOfEpisode
            -1 -> uiState.sleepAtEndOfEpisode
            else -> uiState.sleepTimerRemainingMin == v
        }
    }.coerceAtLeast(0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.86f)
                .widthIn(max = 720.dp)
                .fillMaxHeight(0.86f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Настройки AuraPlay",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "▲▼ выбор пункта • ◄► или OK изменить • Назад закрыть",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        TvActionRow(
                            title = "Звук: Автобалансировка, Нормализация и Эквалайзер",
                            valueText = "Открыть →",
                            modifier = Modifier.focusRequester(firstFocus),
                            onClick = {
                                onDismiss()
                                onOpenAudioSheet()
                            }
                        )
                    }

                    if (isInsidePlayer) {
                        item {
                            TvActionRow(
                                title = "Открыть библиотеку AuraPlay",
                                valueText = "Перейти →",
                                onClick = {
                                    onDismiss()
                                    onGoToHomeLibrary()
                                }
                            )
                        }
                    }

                    item { TvSectionHeader("Производительность Android TV") }

                    item {
                        TvToggleRow(
                            title = "Режим для слабого Android TV (Макс. плавность)",
                            subtitle = "HW-декодер, 16-bit AudioTrack, отключает GPU-фильтры и тяжёлый DSP",
                            checked = prefs.lowEndTvMode,
                            onToggle = { onUpdatePrefs(prefs.copy(lowEndTvMode = it)) }
                        )
                    }

                    item { TvSectionHeader("Видео и картинка") }

                    item {
                        val modes = PictureEnhanceMode.entries
                        val curIdx = modes.indexOf(prefs.pictureEnhanceMode).coerceAtLeast(0)
                        TvStepperRow(
                            title = "Авто-улучшение картинки",
                            subtitle = prefs.pictureEnhanceMode.descriptionRu,
                            valueText = prefs.pictureEnhanceMode.titleRu,
                            onPrev = {
                                val next = modes[(curIdx - 1 + modes.size) % modes.size]
                                onUpdatePrefs(prefs.copy(pictureEnhanceMode = next))
                            },
                            onNext = {
                                val next = modes[(curIdx + 1) % modes.size]
                                onUpdatePrefs(prefs.copy(pictureEnhanceMode = next))
                            }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Всегда максимальное качество",
                            subtitle = "Автовыбор наилучшего разрешения и битрейта в потоках и файлах",
                            checked = prefs.alwaysBestQuality,
                            onToggle = { onUpdatePrefs(prefs.copy(alwaysBestQuality = it)) }
                        )
                    }

                    item {
                        val decs = DecoderMode.entries
                        val curIdx = decs.indexOf(prefs.decoderMode).coerceAtLeast(0)
                        TvStepperRow(
                            title = "Видео и аудио декодер",
                            subtitle = prefs.decoderMode.descriptionRu,
                            valueText = prefs.decoderMode.titleRu,
                            onPrev = {
                                val next = decs[(curIdx - 1 + decs.size) % decs.size]
                                onUpdatePrefs(prefs.copy(decoderMode = next))
                            },
                            onNext = {
                                val next = decs[(curIdx + 1) % decs.size]
                                onUpdatePrefs(prefs.copy(decoderMode = next))
                            }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Автоподстройка частоты кадров (AFR)",
                            subtitle = "Подгонять герцовку экрана под FPS видео",
                            checked = prefs.autoFrameRate,
                            onToggle = { onUpdatePrefs(prefs.copy(autoFrameRate = it)) }
                        )
                    }

                    item { TvSectionHeader("Воспроизведение и пульт ТВ") }

                    item {
                        TvToggleRow(
                            title = "Автозапуск следующей серии",
                            subtitle = "Автоматически переходить к следующей серии в плейлисте/папке",
                            checked = prefs.autoPlayNextEpisode,
                            onToggle = { onUpdatePrefs(prefs.copy(autoPlayNextEpisode = it)) }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Запоминать позицию просмотра",
                            subtitle = "Продолжать видео с места остановки",
                            checked = prefs.rememberPosition,
                            onToggle = { onUpdatePrefs(prefs.copy(rememberPosition = it)) }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Кнопка «Назад» открывает библиотеку",
                            subtitle = "Если выкл — «Назад» сразу выходит в предыдущее приложение",
                            checked = prefs.backReturnsToHome,
                            onToggle = { onUpdatePrefs(prefs.copy(backReturnsToHome = it)) }
                        )
                    }

                    item {
                        val curIdx = seekSteps.indexOf(prefs.seekStepSeconds).coerceAtLeast(0)
                        TvStepperRow(
                            title = "Шаг перемотки с пульта",
                            subtitle = "Базовый шаг при нажатии Влево / Вправо",
                            valueText = "${prefs.seekStepSeconds} сек",
                            onPrev = {
                                val next = seekSteps[(curIdx - 1 + seekSteps.size) % seekSteps.size]
                                onUpdatePrefs(prefs.copy(seekStepSeconds = next))
                            },
                            onNext = {
                                val next = seekSteps[(curIdx + 1) % seekSteps.size]
                                onUpdatePrefs(prefs.copy(seekStepSeconds = next))
                            }
                        )
                    }

                    item {
                        TvStepperRow(
                            title = "Таймер сна",
                            subtitle = "Автоматическая пауза по таймеру или в конце серии",
                            valueText = sleepOptions[currentSleepIdx].second,
                            onPrev = {
                                val next = sleepOptions[(currentSleepIdx - 1 + sleepOptions.size) % sleepOptions.size]
                                onSleepTimerSelect(next.first)
                            },
                            onNext = {
                                val next = sleepOptions[(currentSleepIdx + 1) % sleepOptions.size]
                                onSleepTimerSelect(next.first)
                            }
                        )
                    }

                    item { TvSectionHeader("Субтитры") }

                    item {
                        val sizes = SubtitleSize.entries
                        val curIdx = sizes.indexOf(prefs.subtitleSize).coerceAtLeast(0)
                        TvStepperRow(
                            title = "Размер шрифта субтитров",
                            subtitle = "Удобный размер для чтения с телевизора",
                            valueText = prefs.subtitleSize.titleRu,
                            onPrev = {
                                val next = sizes[(curIdx - 1 + sizes.size) % sizes.size]
                                onUpdatePrefs(prefs.copy(subtitleSize = next))
                            },
                            onNext = {
                                val next = sizes[(curIdx + 1) % sizes.size]
                                onUpdatePrefs(prefs.copy(subtitleSize = next))
                            }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Тёмная подложка субтитров",
                            subtitle = "Улучшает читаемость на светлых сценах",
                            checked = prefs.subtitleBackground,
                            onToggle = { onUpdatePrefs(prefs.copy(subtitleBackground = it)) }
                        )
                    }

                    item {
                        Spacer(Modifier.height(6.dp))
                        TvActionRow(
                            title = "Закрыть настройки",
                            valueText = "OK",
                            onClick = onDismiss
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun TvSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp, start = 4.dp)
    )
}

@Composable
internal fun TvActionRow(
    title: String,
    valueText: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun TvToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onToggle: (Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            )
            .onPreviewKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown &&
                    (ev.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_LEFT || ev.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
                ) {
                    onToggle(!checked)
                    true
                } else false
            }
            .clickable { onToggle(!checked) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        // Non-focusable Switch prevents Android TV double-focus / lost cursor bugs!
        Switch(
            checked = checked,
            onCheckedChange = null,
            modifier = Modifier.focusProperties { canFocus = false }
        )
    }
}

@Composable
internal fun TvStepperRow(
    title: String,
    subtitle: String,
    valueText: String,
    modifier: Modifier = Modifier,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            )
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (ev.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        onPrev()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        onNext()
                        true
                    }
                    else -> false
                }
            }
            .clickable(onClick = onNext)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            text = "◄  $valueText  ►",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = if (focused) Color.White else MaterialTheme.colorScheme.primary
        )
    }
}
