package com.auraplay.player.engine

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Single-pass 5-tap GPU shader for Anime 2:
 * Clarity 20% (midtone detail/contour contrast) + Sharpness 15% (crisp lines) + gentle +5% color clarity.
 * Only 5 texture reads total (1 pass) so even low-end Android TV GPUs run smoothly.
 */
@OptIn(UnstableApi::class)
class ClaritySharpnessEffect(
    private val clarity: Float = 0.20f,
    private val sharpness: Float = 0.15f
) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return ClaritySharpnessShaderProgram(useHdr, clarity, sharpness)
    }

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean {
        return clarity <= 0f && sharpness <= 0f
    }
}

@OptIn(UnstableApi::class)
private class ClaritySharpnessShaderProgram(
    useHdr: Boolean,
    clarity: Float,
    sharpness: Float
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram: GlProgram

    init {
        try {
            glProgram = GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.setFloatUniform("uClarity", clarity)
            glProgram.setFloatUniform("uSharpness", sharpness)
            glProgram.setFloatsUniform("uTexelSize", floatArrayOf(1f / 1920f, 1f / 1080f))
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        glProgram.setFloatsUniform(
            "uTexelSize",
            floatArrayOf(1.0f / inputWidth.coerceAtLeast(1), 1.0f / inputHeight.coerceAtLeast(1))
        )
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform vec2 uTexelSize;
            uniform float uClarity;
            uniform float uSharpness;
            varying vec2 vTexSamplingCoord;

            void main() {
                vec4 center = texture2D(uTexSampler, vTexSamplingCoord);
                vec3 c = center.rgb;

                // Single 4-neighbor sample shared for both Sharpness 15% and midtone Clarity 20%
                vec3 n1 = texture2D(uTexSampler, vTexSamplingCoord + vec2(uTexelSize.x, uTexelSize.y)).rgb;
                vec3 n2 = texture2D(uTexSampler, vTexSamplingCoord + vec2(-uTexelSize.x, uTexelSize.y)).rgb;
                vec3 n3 = texture2D(uTexSampler, vTexSamplingCoord + vec2(uTexelSize.x, -uTexelSize.y)).rgb;
                vec3 n4 = texture2D(uTexSampler, vTexSamplingCoord + vec2(-uTexelSize.x, -uTexelSize.y)).rgb;
                vec3 avg = (n1 + n2 + n3 + n4) * 0.25;
                vec3 detail = clamp(c - avg, vec3(-0.14), vec3(0.14));

                float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
                float midtoneMask = clamp(4.0 * luma * (1.0 - luma), 0.0, 1.0);

                vec3 enhanced = c + detail * (uSharpness * 2.2 + uClarity * 1.8 * midtoneMask);
                // Subtle +5% saturation polish without extra FBO pass
                float outLuma = dot(enhanced, vec3(0.2126, 0.7152, 0.0722));
                vec3 finalRgb = clamp(mix(vec3(outLuma), enhanced, 1.05), 0.0, 1.0);
                gl_FragColor = vec4(finalRgb, center.a);
            }
        """
    }
}
