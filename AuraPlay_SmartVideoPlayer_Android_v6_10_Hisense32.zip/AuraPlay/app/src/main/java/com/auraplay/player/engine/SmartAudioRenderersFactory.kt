package com.auraplay.player.engine

import android.content.Context
import android.os.Build
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.auraplay.player.audio.SmartLoudnessAudioProcessor
import com.auraplay.player.data.DecoderMode
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory

@OptIn(UnstableApi::class)
class SmartAudioRenderersFactory(
    context: Context,
    private val smartLoudnessProcessor: SmartLoudnessAudioProcessor,
    decoderMode: DecoderMode = DecoderMode.STANDARD
) : NextRenderersFactory(context) {

    init {
        val extMode = when (decoderMode) {
            DecoderMode.STANDARD -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
            DecoderMode.HDR_HARDWARE -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
            DecoderMode.PREFER_FFMPEG -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
            DecoderMode.HARDWARE_ONLY -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF
        }
        setExtensionRendererMode(extMode)
        setEnableDecoderFallback(true)
    }

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink {
        // Android TV 9 (API 28) on MStar MSD6683 works natively in 16-bit PCM without AudioFlinger float resampling overhead
        val useFloatSink = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        return DefaultAudioSink.Builder(context)
            .setEnableFloatOutput(useFloatSink)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessors(arrayOf(smartLoudnessProcessor))
            .build()
    }
}
