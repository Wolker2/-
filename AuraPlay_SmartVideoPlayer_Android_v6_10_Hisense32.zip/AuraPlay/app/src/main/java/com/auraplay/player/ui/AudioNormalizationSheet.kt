package com.auraplay.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.AudioTelemetry
import com.auraplay.player.audio.DialogueBalancerStrength
import com.auraplay.player.audio.EqualizerPreset
import com.auraplay.player.audio.NormalizationMode
import java.util.Locale

private sealed class AudioLiveKey {
    data object BalancerStrength : AudioLiveKey()
    data object NormMode : AudioLiveKey()
    data object TargetLufs : AudioLiveKey()
    data object MaxBoost : AudioLiveKey()
    data object EqPreset : AudioLiveKey()
    data class EqBand(val index: Int) : AudioLiveKey()
}

@Composable
fun AudioNormalizationSheet(
    settings: AudioNormalizationSettings,
    telemetry: AudioTelemetry,
    onSelectMode: (NormalizationMode) -> Unit,
    onTargetLufsChange: (Float) -> Unit,
    onMaxBoostChange: (Float) -> Unit,
    onDialogueBalancerToggle: (Boolean) -> Unit,
    onDialogueBalancerStrength: (DialogueBalancerStrength) -> Unit,
    onEqEnabledChange: (Boolean) -> Unit,
    onEqPresetSelect: (EqualizerPreset) -> Unit,
    onEqBandChange: (Int, Float) -> Unit,
    onDismiss: () -> Unit
) {
    val firstFocus = remember { FocusRequester() }
    var liveKey by remember { mutableStateOf<AudioLiveKey?>(null) }

    val bandLabels = listOf("60 Гц (Суббас)", "230 Гц (Бас)", "910 Гц (Середина)", "3.6 кГц (Голос)", "14 кГц (Высокие)")

    Dialog(
        onDismissRequest = {
            if (liveKey != null) liveKey = null else onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val dialogWindow = (LocalView.current.parent as? DialogWindowProvider)?.window
        LaunchedEffect(liveKey) {
            dialogWindow?.setDimAmount(if (liveKey != null) 0.0f else 0.62f)
            if (liveKey == null) {
                runCatching { firstFocus.requestFocus() }
            }
        }

        val activeLive = liveKey
        if (activeLive != null) {
            when (activeLive) {
                AudioLiveKey.BalancerStrength -> {
                    val list = DialogueBalancerStrength.entries
                    val idx = list.indexOf(settings.dialogueBalancerStrength).coerceAtLeast(0)
                    TvLiveBottomBar(
                        title = "Сила автобалансировки речи",
                        valueText = settings.dialogueBalancerStrength.titleRu,
                        subtitle = "Прижимает громкие эффекты и удерживает речь чёткой",
                        onPrev = { onDialogueBalancerStrength(list[(idx - 1 + list.size) % list.size]) },
                        onNext = { onDialogueBalancerStrength(list[(idx + 1) % list.size]) },
                        onBackToMenu = { liveKey = null }
                    )
                }
                AudioLiveKey.NormMode -> {
                    val list = NormalizationMode.entries
                    val idx = list.indexOf(settings.mode).coerceAtLeast(0)
                    TvLiveBottomBar(
                        title = "Режим автонормализации",
                        valueText = settings.mode.titleRu,
                        subtitle = settings.mode.descriptionRu,
                        onPrev = { onSelectMode(list[(idx - 1 + list.size) % list.size]) },
                        onNext = { onSelectMode(list[(idx + 1) % list.size]) },
                        onBackToMenu = { liveKey = null }
                    )
                }
                AudioLiveKey.TargetLufs -> TvLiveBottomBar(
                    title = "Целевая громкость (LUFS)",
                    valueText = String.format(Locale.US, "%.1f LUFS", settings.targetLufs),
                    subtitle = "Оптимум -16 LUFS (кино), -14 LUFS (громче ночью)",
                    onPrev = { onTargetLufsChange((settings.targetLufs - 1.0f).coerceIn(-23f, -11f)) },
                    onNext = { onTargetLufsChange((settings.targetLufs + 1.0f).coerceIn(-23f, -11f)) },
                    onBackToMenu = { liveKey = null }
                )
                AudioLiveKey.MaxBoost -> TvLiveBottomBar(
                    title = "Макс. усиление тихих сцен",
                    valueText = String.format(Locale.US, "+%.0f дБ", settings.maxBoostDb),
                    subtitle = "Предел подъёма громкости в тихих диалогах",
                    onPrev = { onMaxBoostChange((settings.maxBoostDb - 1.0f).coerceIn(0f, 18f)) },
                    onNext = { onMaxBoostChange((settings.maxBoostDb + 1.0f).coerceIn(0f, 18f)) },
                    onBackToMenu = { liveKey = null }
                )
                AudioLiveKey.EqPreset -> {
                    val list = EqualizerPreset.entries
                    val idx = list.indexOf(settings.eqPreset).coerceAtLeast(0)
                    TvLiveBottomBar(
                        title = "Пресет эквалайзера",
                        valueText = settings.eqPreset.titleRu,
                        subtitle = "5-полосный 32-bit float эквалайзер до лимитера",
                        onPrev = { onEqPresetSelect(list[(idx - 1 + list.size) % list.size]) },
                        onNext = { onEqPresetSelect(list[(idx + 1) % list.size]) },
                        onBackToMenu = { liveKey = null }
                    )
                }
                is AudioLiveKey.EqBand -> {
                    val curDb = settings.eqBandsDb.getOrElse(activeLive.index) { 0f }
                    TvLiveBottomBar(
                        title = "Эквалайзер: ${bandLabels[activeLive.index]}",
                        valueText = String.format(Locale.US, "%+.1f дБ", curDb),
                        subtitle = "Регулировка от -6.0 до +6.0 дБ без клиппинга",
                        onPrev = { onEqBandChange(activeLive.index, (curDb - 0.5f).coerceIn(-6f, 6f)) },
                        onNext = { onEqBandChange(activeLive.index, (curDb + 0.5f).coerceIn(-6f, 6f)) },
                        onBackToMenu = { liveKey = null }
                    )
                }
            }
        } else {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .widthIn(max = 720.dp)
                    .fillMaxHeight(0.86f),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = "Звук: Автобалансировка, Нормализация и EQ",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "▲▼ выбор • ◄► переключить • OK настроить прямо на видео • ${telemetry.sampleRateHz / 1000} кГц • ${telemetry.channelCount}ch",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TelemetryMetric("Громкость", String.format(Locale.US, "%.1f LUFS", telemetry.shortTermLufs))
                        TelemetryMetric(
                            "Усиление",
                            String.format(Locale.US, "%+.1f дБ", telemetry.appliedGainDb),
                            MaterialTheme.colorScheme.primary
                        )
                        TelemetryMetric(
                            "Лимитер",
                            String.format(Locale.US, "%.1f дБ", telemetry.limiterReductionDb),
                            if (telemetry.limiterReductionDb < -0.5f) Color(0xFFFFB74D) else MaterialTheme.colorScheme.onSurface
                        )
                        TelemetryMetric("True Peak", String.format(Locale.US, "%.1f дБ", telemetry.truePeakDbtp))
                    }

                    Spacer(Modifier.height(10.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item { TvSectionHeader("Автобалансировка речи и спецэффектов") }

                        item {
                            TvToggleRow(
                                title = "Умная автобалансировка речи и эффектов",
                                subtitle = "В экшене прижимает взрывы/музыку, сохраняя чёткую речь без скачков",
                                checked = settings.dialogueBalancerEnabled,
                                modifier = Modifier.focusRequester(firstFocus),
                                onToggle = onDialogueBalancerToggle
                            )
                        }

                        if (settings.dialogueBalancerEnabled) {
                            item {
                                val strengths = DialogueBalancerStrength.entries
                                val idx = strengths.indexOf(settings.dialogueBalancerStrength).coerceAtLeast(0)
                                TvStepperRow(
                                    title = "Сила автобалансировки",
                                    subtitle = "Насколько мягко или сильно прижимать эффекты на фоне речи",
                                    valueText = settings.dialogueBalancerStrength.titleRu,
                                    onPrev = { onDialogueBalancerStrength(strengths[(idx - 1 + strengths.size) % strengths.size]) },
                                    onNext = { onDialogueBalancerStrength(strengths[(idx + 1) % strengths.size]) },
                                    onOpenLive = { liveKey = AudioLiveKey.BalancerStrength }
                                )
                            }
                        }

                        item { TvSectionHeader("Автонормализация громкости (EBU R128)") }

                        item {
                            val modes = NormalizationMode.entries
                            val idx = modes.indexOf(settings.mode).coerceAtLeast(0)
                            TvStepperRow(
                                title = "Режим нормализации",
                                subtitle = settings.mode.descriptionRu,
                                valueText = settings.mode.titleRu,
                                onPrev = { onSelectMode(modes[(idx - 1 + modes.size) % modes.size]) },
                                onNext = { onSelectMode(modes[(idx + 1) % modes.size]) },
                                onOpenLive = { liveKey = AudioLiveKey.NormMode }
                            )
                        }

                        if (settings.mode != NormalizationMode.BYPASS) {
                            item {
                                TvStepperRow(
                                    title = "Целевая громкость",
                                    subtitle = "Оптимум для кино -16 LUFS, для ночи -14 LUFS",
                                    valueText = String.format(Locale.US, "%.1f LUFS", settings.targetLufs),
                                    onPrev = { onTargetLufsChange((settings.targetLufs - 1.0f).coerceIn(-23f, -11f)) },
                                    onNext = { onTargetLufsChange((settings.targetLufs + 1.0f).coerceIn(-23f, -11f)) },
                                    onOpenLive = { liveKey = AudioLiveKey.TargetLufs }
                                )
                            }
                            item {
                                TvStepperRow(
                                    title = "Макс. усиление тихих сцен",
                                    subtitle = "Ограничение подъёма громкости в тихих диалогах",
                                    valueText = String.format(Locale.US, "+%.0f дБ", settings.maxBoostDb),
                                    onPrev = { onMaxBoostChange((settings.maxBoostDb - 1.0f).coerceIn(0f, 18f)) },
                                    onNext = { onMaxBoostChange((settings.maxBoostDb + 1.0f).coerceIn(0f, 18f)) },
                                    onOpenLive = { liveKey = AudioLiveKey.MaxBoost }
                                )
                            }
                        }

                        item { TvSectionHeader("5-полосный эквалайзер (до лимитера)") }

                        item {
                            TvToggleRow(
                                title = "Включить эквалайзер",
                                subtitle = "Работает в 32-bit float до лимитера — без хрипов и клиппинга",
                                checked = settings.eqEnabled,
                                onToggle = onEqEnabledChange
                            )
                        }

                        if (settings.eqEnabled) {
                            item {
                                val presets = EqualizerPreset.entries
                                val idx = presets.indexOf(settings.eqPreset).coerceAtLeast(0)
                                TvStepperRow(
                                    title = "Пресет эквалайзера",
                                    subtitle = "Быстрый выбор звукового профиля",
                                    valueText = settings.eqPreset.titleRu,
                                    onPrev = { onEqPresetSelect(presets[(idx - 1 + presets.size) % presets.size]) },
                                    onNext = { onEqPresetSelect(presets[(idx + 1) % presets.size]) },
                                    onOpenLive = { liveKey = AudioLiveKey.EqPreset }
                                )
                            }
                            items(5) { bIdx ->
                                val curDb = settings.eqBandsDb.getOrElse(bIdx) { 0f }
                                TvStepperRow(
                                    title = bandLabels[bIdx],
                                    subtitle = "",
                                    valueText = String.format(Locale.US, "%+.1f дБ", curDb),
                                    onPrev = { onEqBandChange(bIdx, (curDb - 0.5f).coerceIn(-6f, 6f)) },
                                    onNext = { onEqBandChange(bIdx, (curDb + 0.5f).coerceIn(-6f, 6f)) },
                                    onOpenLive = { liveKey = AudioLiveKey.EqBand(bIdx) }
                                )
                            }
                        }

                        item {
                            Spacer(Modifier.height(6.dp))
                            TvActionRow(
                                title = "Закрыть меню звука",
                                valueText = "OK",
                                onClick = onDismiss
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetric(
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
