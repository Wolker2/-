package com.auraplay.player.ui

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import com.auraplay.player.data.DecoderMode
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.data.SubtitleSize
import com.auraplay.player.ui.theme.tvFocusBorder

private enum class SettingsLiveKey {
    PICTURE,
    DECODER,
    SEEK_STEP,
    SLEEP_TIMER,
    SUBTITLE_SIZE
}

@Composable
fun SettingsSheet(
    prefs: PlayerPreferences,
    uiState: PlayerUiState,
    isInsidePlayer: Boolean,
    onUpdatePrefs: (PlayerPreferences) -> Unit,
    onSleepTimerSelect: (Int?) -> Unit,
    onOpenAudioSheet: () -> Unit,
    onGoToHomeLibrary: () -> Unit,
    onDismiss: () -> Unit
) {
    val firstFocus = remember { FocusRequester() }
    var liveKey by remember { mutableStateOf<SettingsLiveKey?>(null) }

    val seekSteps = listOf(5, 10, 15, 30)
    val sleepOptions = listOf(
        Triple(null, "Выкл", "Таймер сна отключён"),
        Triple(15, "15 мин", "Пауза через 15 минут"),
        Triple(30, "30 мин", "Пауза через 30 минут"),
        Triple(60, "60 мин", "Пауза через 1 час"),
        Triple(-1, "Конец серии", "Остановка после окончания текущей серии")
    )
    val currentSleepIdx = sleepOptions.indexOfFirst { (v, _, _) ->
        when (v) {
            null -> uiState.sleepTimerRemainingMin == null && !uiState.sleepAtEndOfEpisode
            -1 -> uiState.sleepAtEndOfEpisode
            else -> uiState.sleepTimerRemainingMin == v
        }
    }.coerceAtLeast(0)

    Dialog(
        onDismissRequest = {
            if (liveKey != null) liveKey = null else onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        // Remove dark background dim during live bottom-bar editing so the user sees the real video!
        val dialogWindow = (LocalView.current.parent as? DialogWindowProvider)?.window
        LaunchedEffect(liveKey) {
            dialogWindow?.setDimAmount(if (liveKey != null) 0.0f else 0.62f)
            if (liveKey == null) {
                runCatching { firstFocus.requestFocus() }
            }
        }

        val activeLive = liveKey
        if (activeLive != null) {
            when (activeLive) {
                SettingsLiveKey.PICTURE -> TvLiveBottomBar(
                    title = "Улучшение картинки",
                    valueText = if (prefs.pictureEnhanceEnabled) "Включено" else "Отключено",
                    subtitle = if (prefs.pictureEnhanceEnabled)
                        "Повышенная чёткость, резкость и сочная зелень"
                    else
                        "Оригинальная заводская картинка телевизора",
                    onPrev = { onUpdatePrefs(prefs.copy(pictureEnhanceEnabled = !prefs.pictureEnhanceEnabled)) },
                    onNext = { onUpdatePrefs(prefs.copy(pictureEnhanceEnabled = !prefs.pictureEnhanceEnabled)) },
                    onBackToMenu = { liveKey = null }
                )
                SettingsLiveKey.DECODER -> {
                    val decs = DecoderMode.entries
                    val curIdx = decs.indexOf(prefs.decoderMode).coerceAtLeast(0)
                    TvLiveBottomBar(
                        title = "Видео и аудио декодер",
                        valueText = prefs.decoderMode.titleRu,
                        subtitle = prefs.decoderMode.descriptionRu,
                        onPrev = { onUpdatePrefs(prefs.copy(decoderMode = decs[(curIdx - 1 + decs.size) % decs.size])) },
                        onNext = { onUpdatePrefs(prefs.copy(decoderMode = decs[(curIdx + 1) % decs.size])) },
                        onBackToMenu = { liveKey = null }
                    )
                }
                SettingsLiveKey.SEEK_STEP -> {
                    val curIdx = seekSteps.indexOf(prefs.seekStepSeconds).coerceAtLeast(0)
                    TvLiveBottomBar(
                        title = "Шаг перемотки с пульта",
                        valueText = "${prefs.seekStepSeconds} сек",
                        subtitle = "Шаг при одиночном нажатии Влево/Вправо (при удержании ускоряется)",
                        onPrev = { onUpdatePrefs(prefs.copy(seekStepSeconds = seekSteps[(curIdx - 1 + seekSteps.size) % seekSteps.size])) },
                        onNext = { onUpdatePrefs(prefs.copy(seekStepSeconds = seekSteps[(curIdx + 1) % seekSteps.size])) },
                        onBackToMenu = { liveKey = null }
                    )
                }
                SettingsLiveKey.SLEEP_TIMER -> TvLiveBottomBar(
                    title = "Таймер сна",
                    valueText = sleepOptions[currentSleepIdx].second,
                    subtitle = sleepOptions[currentSleepIdx].third,
                    onPrev = { onSleepTimerSelect(sleepOptions[(currentSleepIdx - 1 + sleepOptions.size) % sleepOptions.size].first) },
                    onNext = { onSleepTimerSelect(sleepOptions[(currentSleepIdx + 1) % sleepOptions.size].first) },
                    onBackToMenu = { liveKey = null }
                )
                SettingsLiveKey.SUBTITLE_SIZE -> {
                    val sizes = SubtitleSize.entries
                    val curIdx = sizes.indexOf(prefs.subtitleSize).coerceAtLeast(0)
                    TvLiveBottomBar(
                        title = "Размер шрифта субтитров",
                        valueText = prefs.subtitleSize.titleRu,
                        subtitle = "Масштаб ${(prefs.subtitleSize.scale * 100).toInt()}%",
                        onPrev = { onUpdatePrefs(prefs.copy(subtitleSize = sizes[(curIdx - 1 + sizes.size) % sizes.size])) },
                        onNext = { onUpdatePrefs(prefs.copy(subtitleSize = sizes[(curIdx + 1) % sizes.size])) },
                        onBackToMenu = { liveKey = null }
                    )
                }
            }
        } else {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .widthIn(max = 720.dp)
                    .fillMaxHeight(0.86f),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = "Настройки AuraPlay",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "▲▼ выбор • ◄► переключить • OK настроить прямо на видео • Назад закрыть",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )

                    Spacer(Modifier.height(10.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            TvActionRow(
                                title = "Звук: Автобалансировка, Нормализация и Эквалайзер",
                                valueText = "Открыть →",
                                modifier = Modifier.focusRequester(firstFocus),
                                onClick = {
                                    onDismiss()
                                    onOpenAudioSheet()
                                }
                            )
                        }

                        if (isInsidePlayer) {
                            item {
                                TvActionRow(
                                    title = "Открыть библиотеку AuraPlay",
                                    valueText = "Перейти →",
                                    onClick = {
                                        onDismiss()
                                        onGoToHomeLibrary()
                                    }
                                )
                            }
                        }

                        item { TvSectionHeader("Видео и картинка") }

                        item {
                            TvStepperRow(
                                title = "Улучшение картинки",
                                subtitle = "Увеличивает чёткость, резкость и сочность цветов (зелень и детали живее)",
                                valueText = if (prefs.pictureEnhanceEnabled) "Вкл" else "Выкл",
                                onPrev = { onUpdatePrefs(prefs.copy(pictureEnhanceEnabled = !prefs.pictureEnhanceEnabled)) },
                                onNext = { onUpdatePrefs(prefs.copy(pictureEnhanceEnabled = !prefs.pictureEnhanceEnabled)) },
                                onOpenLive = { liveKey = SettingsLiveKey.PICTURE }
                            )
                        }

                        item {
                            TvToggleRow(
                                title = "Всегда максимальное качество",
                                subtitle = "Автовыбор наилучшего разрешения и битрейта в потоках и файлах",
                                checked = prefs.alwaysBestQuality,
                                onToggle = { onUpdatePrefs(prefs.copy(alwaysBestQuality = it)) }
                            )
                        }

                        item {
                            val decs = DecoderMode.entries
                            val curIdx = decs.indexOf(prefs.decoderMode).coerceAtLeast(0)
                            TvStepperRow(
                                title = "Видео и аудио декодер",
                                subtitle = prefs.decoderMode.descriptionRu,
                                valueText = prefs.decoderMode.titleRu,
                                onPrev = { onUpdatePrefs(prefs.copy(decoderMode = decs[(curIdx - 1 + decs.size) % decs.size])) },
                                onNext = { onUpdatePrefs(prefs.copy(decoderMode = decs[(curIdx + 1) % decs.size])) },
                                onOpenLive = { liveKey = SettingsLiveKey.DECODER }
                            )
                        }

                        item {
                            TvToggleRow(
                                title = "Автоподстройка частоты кадров (AFR)",
                                subtitle = "Подгонять герцовку экрана под FPS видео",
                                checked = prefs.autoFrameRate,
                                onToggle = { onUpdatePrefs(prefs.copy(autoFrameRate = it)) }
                            )
                        }

                        item { TvSectionHeader("Воспроизведение и пульт ТВ") }

                        item {
                            TvToggleRow(
                                title = "Автозапуск следующей серии",
                                subtitle = "Автоматически переходить к следующей серии в плейлисте/папке",
                                checked = prefs.autoPlayNextEpisode,
                                onToggle = { onUpdatePrefs(prefs.copy(autoPlayNextEpisode = it)) }
                            )
                        }

                        item {
                            TvToggleRow(
                                title = "Запоминать позицию просмотра",
                                subtitle = "Продолжать видео с места остановки",
                                checked = prefs.rememberPosition,
                                onToggle = { onUpdatePrefs(prefs.copy(rememberPosition = it)) }
                            )
                        }

                        item {
                            TvToggleRow(
                                title = "Кнопка «Назад» открывает библиотеку",
                                subtitle = "Если выкл — «Назад» сразу выходит в предыдущее приложение",
                                checked = prefs.backReturnsToHome,
                                onToggle = { onUpdatePrefs(prefs.copy(backReturnsToHome = it)) }
                            )
                        }

                        item {
                            val curIdx = seekSteps.indexOf(prefs.seekStepSeconds).coerceAtLeast(0)
                            TvStepperRow(
                                title = "Шаг перемотки с пульта",
                                subtitle = "Базовый шаг при нажатии Влево / Вправо",
                                valueText = "${prefs.seekStepSeconds} сек",
                                onPrev = { onUpdatePrefs(prefs.copy(seekStepSeconds = seekSteps[(curIdx - 1 + seekSteps.size) % seekSteps.size])) },
                                onNext = { onUpdatePrefs(prefs.copy(seekStepSeconds = seekSteps[(curIdx + 1) % seekSteps.size])) },
                                onOpenLive = { liveKey = SettingsLiveKey.SEEK_STEP }
                            )
                        }

                        item {
                            TvStepperRow(
                                title = "Таймер сна",
                                subtitle = sleepOptions[currentSleepIdx].third,
                                valueText = sleepOptions[currentSleepIdx].second,
                                onPrev = { onSleepTimerSelect(sleepOptions[(currentSleepIdx - 1 + sleepOptions.size) % sleepOptions.size].first) },
                                onNext = { onSleepTimerSelect(sleepOptions[(currentSleepIdx + 1) % sleepOptions.size].first) },
                                onOpenLive = { liveKey = SettingsLiveKey.SLEEP_TIMER }
                            )
                        }

                        item { TvSectionHeader("Субтитры") }

                        item {
                            val sizes = SubtitleSize.entries
                            val curIdx = sizes.indexOf(prefs.subtitleSize).coerceAtLeast(0)
                            TvStepperRow(
                                title = "Размер шрифта субтитров",
                                subtitle = "Удобный размер для чтения с телевизора",
                                valueText = prefs.subtitleSize.titleRu,
                                onPrev = { onUpdatePrefs(prefs.copy(subtitleSize = sizes[(curIdx - 1 + sizes.size) % sizes.size])) },
                                onNext = { onUpdatePrefs(prefs.copy(subtitleSize = sizes[(curIdx + 1) % sizes.size])) },
                                onOpenLive = { liveKey = SettingsLiveKey.SUBTITLE_SIZE }
                            )
                        }

                        item {
                            TvToggleRow(
                                title = "Тёмная подложка субтитров",
                                subtitle = "Улучшает читаемость на светлых сценах",
                                checked = prefs.subtitleBackground,
                                onToggle = { onUpdatePrefs(prefs.copy(subtitleBackground = it)) }
                            )
                        }

                        item {
                            Spacer(Modifier.height(6.dp))
                            TvActionRow(
                                title = "Закрыть настройки",
                                valueText = "OK",
                                onClick = onDismiss
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Compact live-edit bottom bar: hides the full menu so the user sees the entire video unobstructed.
 * LEFT/RIGHT (or OK) changes the setting immediately; BACK returns to the main menu.
 */
@Composable
internal fun TvLiveBottomBar(
    title: String,
    valueText: String,
    subtitle: String,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onBackToMenu: () -> Unit
) {
    val barFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { barFocus.requestFocus() } }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 22.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 760.dp)
                .focusRequester(barFocus)
                .focusable()
                .clip(RoundedCornerShape(16.dp))
                .tvFocusBorder(RoundedCornerShape(16.dp), Color.White)
                .background(Color(0xE011151E))
                .onPreviewKeyEvent { ev ->
                    if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    when (ev.nativeKeyEvent.keyCode) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            onPrev()
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                            onNext()
                            true
                        }
                        KeyEvent.KEYCODE_BACK -> {
                            onBackToMenu()
                            true
                        }
                        else -> false
                    }
                }
                .clickable(onClick = onNext)
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "◄   $valueText   ►",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = "$subtitle  •  ◄► изменить  •  Назад — вернуться в меню",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.78f)
            )
        }
    }
}

@Composable
internal fun TvSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp, start = 4.dp)
    )
}

@Composable
internal fun TvActionRow(
    title: String,
    valueText: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun TvToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onToggle: (Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            )
            .onPreviewKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown &&
                    (ev.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_LEFT || ev.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
                ) {
                    onToggle(!checked)
                    true
                } else false
            }
            .clickable { onToggle(!checked) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = null,
            modifier = Modifier.focusProperties { canFocus = false }
        )
    }
}

@Composable
internal fun TvStepperRow(
    title: String,
    subtitle: String,
    valueText: String,
    modifier: Modifier = Modifier,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onOpenLive: (() -> Unit)? = null
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            )
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (ev.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        onPrev()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        onNext()
                        true
                    }
                    else -> false
                }
            }
            .clickable { (onOpenLive ?: onNext)() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            text = "◄  $valueText  ►",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = if (focused) Color.White else MaterialTheme.colorScheme.primary
        )
    }
}
