package com.auraplay.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.auraplay.player.data.DecoderMode
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.data.SubtitleSize
import com.auraplay.player.ui.theme.tvFocusBorder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    prefs: PlayerPreferences,
    uiState: PlayerUiState,
    isInsidePlayer: Boolean,
    onUpdatePrefs: (PlayerPreferences) -> Unit,
    onSleepTimerSelect: (Int?) -> Unit,
    onOpenAudioSheet: () -> Unit,
    onGoToHomeLibrary: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Настройки AuraPlay",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            // Quick jump to Audio & EQ or Home Library
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        onDismiss()
                        onOpenAudioSheet()
                    },
                    modifier = Modifier.weight(1f).tvFocusBorder()
                ) {
                    Text("Звук и Эквалайзер")
                }
                if (isInsidePlayer) {
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onGoToHomeLibrary()
                        },
                        modifier = Modifier.weight(1f).tvFocusBorder()
                    ) {
                        Text("Библиотека AuraPlay")
                    }
                }
            }

            // Active Codec Info Card
            if (uiState.videoCodecInfo.isNotBlank() || uiState.audioCodecInfo.isNotBlank()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(12.dp)
                ) {
                    Text("Активные кодеки", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                    if (uiState.videoCodecInfo.isNotBlank()) {
                        Text("Видео: ${uiState.videoCodecInfo}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (uiState.audioCodecInfo.isNotBlank()) {
                        Text("Аудио: ${uiState.audioCodecInfo}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Quality & Picture Section
            SectionHeader("Качество видео и картинка")

            ToggleRow(
                title = "Всегда максимальное качество",
                subtitle = "Автоматически выбирать наилучшее разрешение и битрейт в потоках (HLS/DASH) и файлах",
                checked = prefs.alwaysBestQuality,
                onCheckedChange = { onUpdatePrefs(prefs.copy(alwaysBestQuality = it)) }
            )

            ToggleRow(
                title = "Авто-улучшение картинки",
                subtitle = "Кино-контраст, глубина теней и насыщенность (GPU-фильтр)",
                checked = prefs.autoPictureEnhance,
                onCheckedChange = { onUpdatePrefs(prefs.copy(autoPictureEnhance = it)) }
            )

            ToggleRow(
                title = "Автоподстройка частоты кадров (AFR)",
                subtitle = "Подгонять герцовку экрана под FPS фильма для плавности",
                checked = prefs.autoFrameRate,
                onCheckedChange = { onUpdatePrefs(prefs.copy(autoFrameRate = it)) }
            )

            // Codecs / Decoders Section
            SectionHeader("Видео и аудио кодеки (Декодер)")
            DecoderMode.entries.forEach { mode ->
                val selected = prefs.decoderMode == mode
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .tvFocusBorder()
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                        .clickable { onUpdatePrefs(prefs.copy(decoderMode = mode)) }
                        .padding(10.dp)
                ) {
                    Text(
                        text = mode.titleRu,
                        style = MaterialTheme.typography.titleSmall,
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = mode.descriptionRu,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Playback & TV Remote Section
            SectionHeader("Воспроизведение и пульт ТВ")

            ToggleRow(
                title = "Автозапуск следующей серии",
                subtitle = "Автоматически переключаться на следующую серию в папке",
                checked = prefs.autoPlayNextEpisode,
                onCheckedChange = { onUpdatePrefs(prefs.copy(autoPlayNextEpisode = it)) }
            )

            ToggleRow(
                title = "Запоминать позицию просмотра",
                subtitle = "Продолжать фильм с того места, где остановились",
                checked = prefs.rememberPosition,
                onCheckedChange = { onUpdatePrefs(prefs.copy(rememberPosition = it)) }
            )

            ToggleRow(
                title = "Кнопка «Назад» открывает библиотеку",
                subtitle = "Если выкл — «Назад» на пульте сразу возвращает в предыдущее приложение",
                checked = prefs.backReturnsToHome,
                onCheckedChange = { onUpdatePrefs(prefs.copy(backReturnsToHome = it)) }
            )

            Text("Шаг перемотки с пульта / двойного тапа", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 15, 30).forEach { sec ->
                    FilterChip(
                        selected = prefs.seekStepSeconds == sec,
                        onClick = { onUpdatePrefs(prefs.copy(seekStepSeconds = sec)) },
                        label = { Text("${sec}с") },
                        modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                    )
                }
            }

            // Sleep Timer
            SectionHeader("Таймер сна")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val timers = listOf(null to "Выкл", 15 to "15м", 30 to "30м", 60 to "60м", -1 to "Конец серии")
                timers.forEach { (minVal, label) ->
                    val isSel = when (minVal) {
                        null -> uiState.sleepTimerRemainingMin == null && !uiState.sleepAtEndOfEpisode
                        -1 -> uiState.sleepAtEndOfEpisode
                        else -> uiState.sleepTimerRemainingMin == minVal
                    }
                    FilterChip(
                        selected = isSel,
                        onClick = { onSleepTimerSelect(minVal) },
                        label = { Text(label) },
                        modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                    )
                }
            }

            // Subtitles Style
            SectionHeader("Субтитры")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SubtitleSize.entries.forEach { sz ->
                    FilterChip(
                        selected = prefs.subtitleSize == sz,
                        onClick = { onUpdatePrefs(prefs.copy(subtitleSize = sz)) },
                        label = { Text(sz.titleRu) },
                        modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                    )
                }
            }

            ToggleRow(
                title = "Тёмная подложка субтитров",
                subtitle = "Улучшает читаемость субтитров на светлых сценах",
                checked = prefs.subtitleBackground,
                onCheckedChange = { onUpdatePrefs(prefs.copy(subtitleBackground = it)) }
            )

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 6.dp)
    )
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .tvFocusBorder()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp, horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
