package com.auraplay.player.audio

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.tanh

/**
 * 32-bit float PCM DSP engine:
 * - ITU-R BS.1770-4 / EBU R128 K-weighted loudness normalization
 * - 5-band 64-bit parametric Equalizer (60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz)
 * - Adaptive silence gate (-55 LUFS)
 * - Channel-linked 5 ms look-ahead True-Peak Limiter (-1.0 dBTP)
 */
@OptIn(UnstableApi::class)
class SmartLoudnessAudioProcessor : BaseAudioProcessor() {

    private val settingsRef = AtomicReference(AudioNormalizationSettings())
    private val _telemetry = MutableStateFlow(AudioTelemetry())
    val telemetry: StateFlow<AudioTelemetry> = _telemetry.asStateFlow()

    private var sampleRate = 48000
    private var channelCount = 2
    private var isFloatEncoding = true

    private var preFilters: Array<BiquadFilter> = emptyArray()
    private var rlbFilters: Array<BiquadFilter> = emptyArray()
    private var voiceEqFilters: Array<BiquadFilter> = emptyArray()

    // 5-band parametric EQ [channel][band]
    private var eqFilters: Array<Array<BiquadFilter>> = emptyArray()
    @Volatile
    private var appliedEqBands: List<Float> = listOf(0f, 0f, 0f, 0f, 0f)

    private var momentaryMeanSq = 1e-7
    private var shortTermMeanSq = 1e-7
    private var currentAgcGainDb = 0.0

    private var lookAheadFrames = 240
    private var delayBuffer = FloatArray(0)
    private var peakRingBuffer = FloatArray(0)
    private var delayWritePos = 0
    private var limiterGain = 1.0

    private var framesSinceTelemetry = 0
    private var telemetryIntervalFrames = 3200
    private var peakTrackerLinear = 1e-7f

    fun updateSettings(settings: AudioNormalizationSettings) {
        settingsRef.set(settings)
    }

    fun getSettings(): AudioNormalizationSettings = settingsRef.get()

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val encoding = inputAudioFormat.encoding
        if (encoding != C.ENCODING_PCM_FLOAT && encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate.coerceAtLeast(8000)
        channelCount = inputAudioFormat.channelCount.coerceAtLeast(1)
        isFloatEncoding = (encoding == C.ENCODING_PCM_FLOAT)
        initDspState()
        return inputAudioFormat
    }

    private fun initDspState() {
        val sr = sampleRate.toDouble()
        preFilters = Array(channelCount) { BiquadFilter.kWeightingPreFilter(sr) }
        rlbFilters = Array(channelCount) { BiquadFilter.kWeightingRlbFilter(sr) }
        voiceEqFilters = Array(channelCount) { BiquadFilter.peakingEq(sr, 2400.0, 1.1, 3.0) }
        rebuildEqFilters(settingsRef.get().eqBandsDb)

        lookAheadFrames = max(32, (sampleRate * 0.005).toInt())
        delayBuffer = FloatArray(lookAheadFrames * channelCount)
        peakRingBuffer = FloatArray(lookAheadFrames)
        delayWritePos = 0

        momentaryMeanSq = 1e-7
        shortTermMeanSq = 1e-7
        currentAgcGainDb = 0.0
        limiterGain = 1.0
        peakTrackerLinear = 1e-7f
        framesSinceTelemetry = 0
        telemetryIntervalFrames = max(1024, sampleRate / 15)
    }

    private fun rebuildEqFilters(bands: List<Float>) {
        val sr = sampleRate.toDouble()
        val freqs = doubleArrayOf(60.0, 230.0, 910.0, 3600.0, 14000.0)
        val qs = doubleArrayOf(0.9, 1.0, 1.0, 1.0, 0.85)
        eqFilters = Array(channelCount) {
            Array(5) { b ->
                val gain = bands.getOrElse(b) { 0f }.toDouble().coerceIn(-8.0, 8.0)
                BiquadFilter.peakingEq(sr, freqs[b], qs[b], gain)
            }
        }
        appliedEqBands = bands.toList()
    }

    override fun onFlush(streamMetadata: AudioProcessor.StreamMetadata) {
        initDspState()
    }

    override fun onReset() {
        delayBuffer = FloatArray(0)
        peakRingBuffer = FloatArray(0)
        preFilters = emptyArray()
        rlbFilters = emptyArray()
        voiceEqFilters = emptyArray()
        eqFilters = emptyArray()
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val settings = settingsRef.get()
        val outputBuffer = replaceOutputBuffer(remaining)

        // Bit-exact bypass when both normalization and EQ are off
        if (settings.mode == NormalizationMode.BYPASS && !settings.eqEnabled) {
            outputBuffer.put(inputBuffer)
            outputBuffer.flip()
            emitTelemetry(-70f, -70f, 0f, 0f, -70f, NormalizationMode.BYPASS)
            return
        }

        if (settings.eqEnabled && settings.eqBandsDb != appliedEqBands && channelCount > 0) {
            rebuildEqFilters(settings.eqBandsDb)
        }

        val bytesPerSample = if (isFloatEncoding) 4 else 2
        val frameSizeBytes = bytesPerSample * channelCount
        val frameCount = remaining / frameSizeBytes
        if (frameCount <= 0) {
            outputBuffer.flip()
            return
        }

        val sr = sampleRate.toDouble()
        val momentaryAlpha = 1.0 - exp(-1.0 / (0.400 * sr))
        val shortTermAlpha = 1.0 - exp(-1.0 / (3.000 * sr))
        val agcAttackAlpha = 1.0 - exp(-1.0 / ((settings.mode.attackMs / 1000.0) * sr))
        val agcReleaseAlpha = 1.0 - exp(-1.0 / ((settings.mode.releaseMs / 1000.0) * sr))
        val limiterAttackAlpha = 1.0 - exp(-1.0 / (0.0015 * sr))
        val limiterReleaseAlpha = 1.0 - exp(-1.0 / (0.080 * sr))

        val ceilingLinear = dbToLinear(settings.truePeakCeilingDb.toDouble())
        val softKneeStart = ceilingLinear * 0.944
        val enableVoiceEq = settings.mode.enableVoicePresenceEq
        val enableNorm = settings.mode != NormalizationMode.BYPASS
        val enableEq = settings.eqEnabled && eqFilters.size == channelCount

        val frameSamples = FloatArray(channelCount)

        for (f in 0 until frameCount) {
            var kWeightedEnergySum = 0.0

            for (ch in 0 until channelCount) {
                var sampleDouble = if (isFloatEncoding) {
                    inputBuffer.float.toDouble()
                } else {
                    inputBuffer.short.toDouble() / 32768.0
                }

                if (enableEq) {
                    val chEq = eqFilters[ch]
                    for (b in 0 until 5) {
                        sampleDouble = chEq[b].process(sampleDouble)
                    }
                }
                if (enableVoiceEq) {
                    sampleDouble = voiceEqFilters[ch].process(sampleDouble)
                }
                frameSamples[ch] = sampleDouble.toFloat()

                val chWeight = getChannelWeight(ch, channelCount)
                if (chWeight > 0.0) {
                    val stage1 = preFilters[ch].process(sampleDouble)
                    val kWeighted = rlbFilters[ch].process(stage1)
                    kWeightedEnergySum += chWeight * kWeighted * kWeighted
                }
            }

            momentaryMeanSq += momentaryAlpha * (kWeightedEnergySum - momentaryMeanSq)
            shortTermMeanSq += shortTermAlpha * (kWeightedEnergySum - shortTermMeanSq)

            val momentaryLufs = -0.691 + 10.0 * log10(max(momentaryMeanSq, 1e-10))
            val shortTermLufs = -0.691 + 10.0 * log10(max(shortTermMeanSq, 1e-10))

            if (enableNorm) {
                val blendedLufs = if (settings.mode == NormalizationMode.NIGHT) {
                    0.55 * momentaryLufs + 0.45 * shortTermLufs
                } else {
                    0.25 * momentaryLufs + 0.75 * shortTermLufs
                }

                if (momentaryLufs > settings.silenceGateLufs) {
                    val desiredGainDb = (settings.targetLufs - blendedLufs)
                        .coerceIn(-18.0, settings.maxBoostDb.toDouble())
                    val alpha = if (desiredGainDb < currentAgcGainDb) agcAttackAlpha else agcReleaseAlpha
                    currentAgcGainDb += alpha * (desiredGainDb - currentAgcGainDb)
                } else {
                    currentAgcGainDb += (agcReleaseAlpha * 0.15) * (0.0 - currentAgcGainDb)
                }
            } else {
                currentAgcGainDb = 0.0
            }

            val agcLinear = dbToLinear(currentAgcGainDb)

            var framePeak = 0.0f
            val writeBase = delayWritePos * channelCount
            for (ch in 0 until channelCount) {
                val scaled = (frameSamples[ch] * agcLinear).toFloat()
                delayBuffer[writeBase + ch] = scaled
                val absVal = abs(scaled)
                if (absVal > framePeak) framePeak = absVal
            }
            peakRingBuffer[delayWritePos] = framePeak

            val readPos = (delayWritePos + 1) % lookAheadFrames
            delayWritePos = readPos

            var windowMaxPeak = 0.0f
            for (i in 0 until lookAheadFrames) {
                val p = peakRingBuffer[i]
                if (p > windowMaxPeak) windowMaxPeak = p
            }

            val targetLimiterGain = if (windowMaxPeak > ceilingLinear) {
                ceilingLinear / windowMaxPeak.toDouble()
            } else {
                1.0
            }

            val limAlpha = if (targetLimiterGain < limiterGain) limiterAttackAlpha else limiterReleaseAlpha
            limiterGain += limAlpha * (targetLimiterGain - limiterGain)

            val readBase = readPos * channelCount
            for (ch in 0 until channelCount) {
                var outSample = (delayBuffer[readBase + ch] * limiterGain).toDouble()
                val absOut = abs(outSample)
                if (absOut > softKneeStart) {
                    val excess = absOut - softKneeStart
                    val headroom = (ceilingLinear - softKneeStart).coerceAtLeast(1e-4)
                    val shaped = softKneeStart + headroom * tanh(excess / headroom)
                    outSample = if (outSample >= 0.0) shaped else -shaped
                }

                val outFloat = outSample.toFloat()
                val absFinal = abs(outFloat)
                if (absFinal > peakTrackerLinear) peakTrackerLinear = absFinal

                if (isFloatEncoding) {
                    outputBuffer.putFloat(outFloat)
                } else {
                    val pcm16 = (outFloat * 32767.0f).toInt().coerceIn(-32768, 32767).toShort()
                    outputBuffer.putShort(pcm16)
                }
            }

            framesSinceTelemetry++
            if (framesSinceTelemetry >= telemetryIntervalFrames) {
                framesSinceTelemetry = 0
                val limRedDb = if (limiterGain < 0.9999) (20.0 * log10(limiterGain)).toFloat() else 0f
                val peakDb = (20.0 * log10(max(peakTrackerLinear.toDouble(), 1e-6))).toFloat()
                peakTrackerLinear = 1e-7f
                emitTelemetry(
                    momentaryLufs = momentaryLufs.toFloat().coerceIn(-70f, 0f),
                    shortTermLufs = shortTermLufs.toFloat().coerceIn(-70f, 0f),
                    appliedGainDb = currentAgcGainDb.toFloat(),
                    limiterReductionDb = limRedDb,
                    truePeakDbtp = peakDb.coerceIn(-70f, 0f),
                    mode = settings.mode
                )
            }
        }

        outputBuffer.flip()
    }

    private fun emitTelemetry(
        momentaryLufs: Float,
        shortTermLufs: Float,
        appliedGainDb: Float,
        limiterReductionDb: Float,
        truePeakDbtp: Float,
        mode: NormalizationMode
    ) {
        _telemetry.value = AudioTelemetry(
            momentaryLufs = momentaryLufs,
            shortTermLufs = shortTermLufs,
            appliedGainDb = appliedGainDb,
            limiterReductionDb = limiterReductionDb,
            truePeakDbtp = truePeakDbtp,
            sampleRateHz = sampleRate,
            channelCount = channelCount,
            isFloatPipeline = isFloatEncoding,
            mode = mode
        )
    }

    private fun getChannelWeight(channelIndex: Int, totalChannels: Int): Double {
        if (totalChannels <= 2) return 1.0
        return when (channelIndex) {
            3 -> 0.0
            4, 5, 6, 7 -> 1.4125375446227544
            else -> 1.0
        }
    }

    private fun dbToLinear(db: Double): Double = 10.0.pow(db / 20.0)
}
