package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение ТВ/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная экономия заряда, только системные кодеки"
    )
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,       // По умолчанию ВЫКЛ: Назад выходит в вызвавшее приложение
    val autoPlayNextEpisode: Boolean = true,      // Автозапуск следующей серии
    val rememberPosition: Boolean = true,         // Запоминать позицию просмотра
    val alwaysBestQuality: Boolean = true,        // Всегда максимальное качество (потоки и файлы)
    val autoPictureEnhance: Boolean = false,      // Авто-улучшение картинки (кино-контраст/насыщенность)
    val autoFrameRate: Boolean = true,            // Автоподстройка частоты кадров экрана (AFR)
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,                // Шаг перемотки с пульта/двойного тапа
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,       // Полупрозрачная подложка субтитров
    val savedStreams: List<String> = emptyList()  // Закладки сетевых адресов (URL / TorrServe / IPTV)
)
