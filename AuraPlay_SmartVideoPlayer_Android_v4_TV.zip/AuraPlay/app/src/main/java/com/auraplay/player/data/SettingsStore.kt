package com.auraplay.player.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.EqualizerPreset
import com.auraplay.player.audio.NormalizationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "auraplay_settings_v4")

class SettingsStore(private val context: Context) {

    private object Keys {
        val MODE = stringPreferencesKey("norm_mode")
        val TARGET_LUFS = floatPreferencesKey("target_lufs")
        val MAX_BOOST_DB = floatPreferencesKey("max_boost_db")
        val TRUE_PEAK_CEILING = floatPreferencesKey("true_peak_ceiling")
        val EQ_ENABLED = booleanPreferencesKey("eq_enabled")
        val EQ_PRESET = stringPreferencesKey("eq_preset")
        val EQ_BANDS = stringPreferencesKey("eq_bands")

        val BACK_TO_HOME = booleanPreferencesKey("back_returns_to_home")
        val AUTO_NEXT = booleanPreferencesKey("auto_play_next_episode")
        val REMEMBER_POS = booleanPreferencesKey("remember_position")
        val BEST_QUALITY = booleanPreferencesKey("always_best_quality")
        val AUTO_PICTURE = booleanPreferencesKey("auto_picture_enhance")
        val AUTO_FRAME_RATE = booleanPreferencesKey("auto_frame_rate")
        val DECODER_MODE = stringPreferencesKey("decoder_mode")
        val SEEK_STEP = intPreferencesKey("seek_step_seconds")
        val SUB_SIZE = stringPreferencesKey("subtitle_size")
        val SUB_BG = booleanPreferencesKey("subtitle_background")
        val SAVED_STREAMS = stringPreferencesKey("saved_streams")
    }

    val audioSettings: Flow<AudioNormalizationSettings> = context.dataStore.data.map { prefs ->
        val mode = prefs[Keys.MODE]?.let { runCatching { NormalizationMode.valueOf(it) }.getOrNull() }
            ?: NormalizationMode.STUDIO
        val eqPreset = prefs[Keys.EQ_PRESET]?.let { runCatching { EqualizerPreset.valueOf(it) }.getOrNull() }
            ?: EqualizerPreset.FLAT
        val bands = prefs[Keys.EQ_BANDS]?.split(",")?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == 5 } ?: eqPreset.bandsDb
        AudioNormalizationSettings(
            mode = mode,
            targetLufs = prefs[Keys.TARGET_LUFS] ?: mode.defaultTargetLufs,
            maxBoostDb = prefs[Keys.MAX_BOOST_DB] ?: mode.defaultMaxBoostDb,
            truePeakCeilingDb = prefs[Keys.TRUE_PEAK_CEILING] ?: -1.0f,
            eqEnabled = prefs[Keys.EQ_ENABLED] ?: false,
            eqPreset = eqPreset,
            eqBandsDb = bands
        )
    }

    val playerPrefs: Flow<PlayerPreferences> = context.dataStore.data.map { prefs ->
        val decMode = prefs[Keys.DECODER_MODE]?.let { runCatching { DecoderMode.valueOf(it) }.getOrNull() }
            ?: DecoderMode.AUTO_HYBRID
        val subSize = prefs[Keys.SUB_SIZE]?.let { runCatching { SubtitleSize.valueOf(it) }.getOrNull() }
            ?: SubtitleSize.LARGE
        val streams = prefs[Keys.SAVED_STREAMS]?.split("\n")?.filter { it.isNotBlank() } ?: emptyList()

        PlayerPreferences(
            backReturnsToHome = prefs[Keys.BACK_TO_HOME] ?: false,
            autoPlayNextEpisode = prefs[Keys.AUTO_NEXT] ?: true,
            rememberPosition = prefs[Keys.REMEMBER_POS] ?: true,
            alwaysBestQuality = prefs[Keys.BEST_QUALITY] ?: true,
            autoPictureEnhance = prefs[Keys.AUTO_PICTURE] ?: false,
            autoFrameRate = prefs[Keys.AUTO_FRAME_RATE] ?: true,
            decoderMode = decMode,
            seekStepSeconds = prefs[Keys.SEEK_STEP] ?: 10,
            subtitleSize = subSize,
            subtitleBackground = prefs[Keys.SUB_BG] ?: true,
            savedStreams = streams
        )
    }

    suspend fun saveAudioSettings(settings: AudioNormalizationSettings) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MODE] = settings.mode.name
            prefs[Keys.TARGET_LUFS] = settings.targetLufs
            prefs[Keys.MAX_BOOST_DB] = settings.maxBoostDb
            prefs[Keys.TRUE_PEAK_CEILING] = settings.truePeakCeilingDb
            prefs[Keys.EQ_ENABLED] = settings.eqEnabled
            prefs[Keys.EQ_PRESET] = settings.eqPreset.name
            prefs[Keys.EQ_BANDS] = settings.eqBandsDb.joinToString(",")
        }
    }

    suspend fun savePlayerPrefs(p: PlayerPreferences) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BACK_TO_HOME] = p.backReturnsToHome
            prefs[Keys.AUTO_NEXT] = p.autoPlayNextEpisode
            prefs[Keys.REMEMBER_POS] = p.rememberPosition
            prefs[Keys.BEST_QUALITY] = p.alwaysBestQuality
            prefs[Keys.AUTO_PICTURE] = p.autoPictureEnhance
            prefs[Keys.AUTO_FRAME_RATE] = p.autoFrameRate
            prefs[Keys.DECODER_MODE] = p.decoderMode.name
            prefs[Keys.SEEK_STEP] = p.seekStepSeconds
            prefs[Keys.SUB_SIZE] = p.subtitleSize.name
            prefs[Keys.SUB_BG] = p.subtitleBackground
            prefs[Keys.SAVED_STREAMS] = p.savedStreams.distinct().take(15).joinToString("\n")
        }
    }

    suspend fun savePosition(mediaKey: String, positionMs: Long) {
        val key = longPreferencesKey("pos_${mediaKey.hashCode()}")
        context.dataStore.edit { prefs ->
            if (positionMs <= 0L) prefs.remove(key) else prefs[key] = positionMs
        }
    }

    suspend fun getSavedPosition(mediaKey: String): Long {
        val key = longPreferencesKey("pos_${mediaKey.hashCode()}")
        return context.dataStore.data.first()[key] ?: 0L
    }
}
