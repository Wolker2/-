package com.auraplay.player.engine

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Hardware OpenGL ES 2.0 GPU shader for Clarity (local midtone detail contrast)
 * and Sharpness (halo-free unsharp mask for crisp anime lines & fine details).
 */
@OptIn(UnstableApi::class)
class ClaritySharpnessEffect(
    private val clarity: Float = 0.20f,
    private val sharpness: Float = 0.15f
) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return ClaritySharpnessShaderProgram(useHdr, clarity, sharpness)
    }

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean {
        return clarity <= 0f && sharpness <= 0f
    }
}

@OptIn(UnstableApi::class)
private class ClaritySharpnessShaderProgram(
    useHdr: Boolean,
    clarity: Float,
    sharpness: Float
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram: GlProgram

    init {
        try {
            glProgram = GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
            glProgram.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
            glProgram.setFloatUniform("uClarity", clarity)
            glProgram.setFloatUniform("uSharpness", sharpness)
            glProgram.setFloatsUniform("uTexelSize", floatArrayOf(1f / 1920f, 1f / 1080f))
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        glProgram.setFloatsUniform(
            "uTexelSize",
            floatArrayOf(1.0f / inputWidth.coerceAtLeast(1), 1.0f / inputHeight.coerceAtLeast(1))
        )
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX_SHADER = """
            attribute vec4 aFramePosition;
            varying vec2 vTexSamplingCoord;
            void main() {
                gl_Position = aFramePosition;
                vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexSampler;
            uniform vec2 uTexelSize;
            uniform float uClarity;
            uniform float uSharpness;
            varying vec2 vTexSamplingCoord;

            void main() {
                vec4 center = texture2D(uTexSampler, vTexSamplingCoord);
                vec3 c = center.rgb;

                // 1. Sharpness (15%): crisp line & fine detail enhancement without ringing/halos
                vec3 s1 = texture2D(uTexSampler, vTexSamplingCoord + vec2(uTexelSize.x, 0.0)).rgb;
                vec3 s2 = texture2D(uTexSampler, vTexSamplingCoord - vec2(uTexelSize.x, 0.0)).rgb;
                vec3 s3 = texture2D(uTexSampler, vTexSamplingCoord + vec2(0.0, uTexelSize.y)).rgb;
                vec3 s4 = texture2D(uTexSampler, vTexSamplingCoord - vec2(0.0, uTexelSize.y)).rgb;
                vec3 fineBlur = (s1 + s2 + s3 + s4) * 0.25;
                vec3 sharpDelta = clamp(c - fineBlur, vec3(-0.12), vec3(0.12));

                // 2. Clarity (20%): local midtone contrast for contour & detail readability
                vec2 wide = uTexelSize * 2.5;
                vec3 w1 = texture2D(uTexSampler, vTexSamplingCoord + vec2(wide.x, wide.y)).rgb;
                vec3 w2 = texture2D(uTexSampler, vTexSamplingCoord + vec2(-wide.x, wide.y)).rgb;
                vec3 w3 = texture2D(uTexSampler, vTexSamplingCoord + vec2(wide.x, -wide.y)).rgb;
                vec3 w4 = texture2D(uTexSampler, vTexSamplingCoord + vec2(-wide.x, -wide.y)).rgb;
                vec3 wideBlur = (w1 + w2 + w3 + w4) * 0.25;
                float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
                float midtoneMask = clamp(4.0 * luma * (1.0 - luma), 0.0, 1.0);
                vec3 clarityDelta = clamp(c - wideBlur, vec3(-0.15), vec3(0.15)) * midtoneMask;

                vec3 outRgb = clamp(c + sharpDelta * (uSharpness * 2.2) + clarityDelta * (uClarity * 1.8), 0.0, 1.0);
                gl_FragColor = vec4(outRgb, center.a);
            }
        """
    }
}
