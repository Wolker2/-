package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение ТВ/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная экономия заряда, только системные кодеки"
    )
}

/**
 * Shadow-safe 3D-LUT & GPU shader presets (no linear black-crush!):
 * - midContrast: smooth midtone S-curve strength (0.0 = neutral)
 * - shadowLift: gentle shadow detail recovery (protects pure black < 0.015)
 * - highlightRoll: gentle highlight roll-off (negative = softer bright peaks)
 * - saturation: color saturation multiplier (1.0 = neutral)
 * - redScale / blueScale: subtle warm/cool tint
 */
enum class PictureEnhanceMode(
    val titleRu: String,
    val descriptionRu: String,
    val midContrast: Double,
    val shadowLift: Double,
    val highlightRoll: Double,
    val saturation: Double,
    val redScale: Double,
    val blueScale: Double,
    val clarity: Float = 0f,
    val sharpness: Float = 0f
) {
    OFF("Отключить", "Оригинальная картинка без обработки (лучше для HDR)", 0.0, 0.0, 0.0, 1.00, 1.00, 1.00),
    ANIME("Аниме", "Сочные чистые цвета и мягкий контраст без провала теней", 0.08, 0.025, -0.02, 1.15, 1.00, 1.01),
    ANIME_2("Аниме 2", "Чёткость (Clarity) 20% + Резкость (Sharpness) 15% для контуров и мелких деталей", 0.04, 0.015, -0.015, 1.06, 1.00, 1.00, clarity = 0.20f, sharpness = 0.15f),
    MOVIE("Фильм", "Благородный кино-контраст с сохранением деталей в тенях и тёплым оттенком", 0.09, 0.020, -0.03, 1.05, 1.02, 0.97),
    SERIES("Сериал", "Естественная чёткость и хорошо читаемые тёмные сцены", 0.06, 0.035, -0.02, 1.06, 1.01, 1.00),
    EVERYDAY("Повседневное", "Деликатное оживление картинки без перегибов", 0.04, 0.015, -0.015, 1.04, 1.00, 1.00),
    AUTO("Авто", "Умный 3D-LUT: мягко осветляет тёмные тени и приглушает пересветы без дымки и скачков", 0.05, 0.065, -0.065, 1.05, 1.00, 1.00)
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceMode: PictureEnhanceMode = PictureEnhanceMode.OFF,
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
