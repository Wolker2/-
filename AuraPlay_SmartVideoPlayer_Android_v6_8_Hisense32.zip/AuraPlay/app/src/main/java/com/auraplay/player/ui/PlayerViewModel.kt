package com.auraplay.player.ui

import android.app.Application
import android.net.Uri
import androidx.annotation.OptIn
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.SeekParameters
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.AudioTelemetry
import com.auraplay.player.audio.DialogueBalancerStrength
import com.auraplay.player.audio.EqualizerPreset
import com.auraplay.player.audio.NormalizationMode
import com.auraplay.player.audio.SmartLoudnessAudioProcessor
import com.auraplay.player.data.DecoderMode
import com.auraplay.player.data.LocalVideoRepository
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.data.SettingsStore
import com.auraplay.player.data.VideoItem
import com.auraplay.player.engine.SmartAudioRenderersFactory
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

data class TrackOption(
    val id: String,
    val label: String,
    val groupIndex: Int,
    val trackIndex: Int,
    val isSelected: Boolean
)

data class MediaDetailedInfo(
    val resolution: String = "—",
    val videoCodec: String = "—",
    val videoFps: String = "—",
    val videoBitrate: String = "—",
    val audioCodec: String = "—",
    val audioChannels: String = "—",
    val audioSampleRate: String = "—",
    val audioBitrate: String = "—",
    val audioLanguage: String = "—"
)

data class PlayerUiState(
    val currentTitle: String = "",
    val currentUri: Uri? = null,
    val launchedExternally: Boolean = false,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val videoTracks: List<TrackOption> = emptyList(),
    val audioTracks: List<TrackOption> = emptyList(),
    val subtitleTracks: List<TrackOption> = emptyList(),
    val videoCodecInfo: String = "",
    val audioCodecInfo: String = "",
    val mediaDetails: MediaDetailedInfo = MediaDetailedInfo(),
    val folderEpisodes: List<VideoItem> = emptyList(),
    val currentEpisodeIndex: Int = -1,
    val nextEpisode: VideoItem? = null,
    val prevEpisode: VideoItem? = null,
    val nextEpisodeCountdownSec: Int? = null,
    val sleepTimerRemainingMin: Int? = null,
    val sleepAtEndOfEpisode: Boolean = false,
    val errorMessage: String? = null
)

@OptIn(UnstableApi::class)
class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsStore = SettingsStore(application)
    val smartAudioProcessor = SmartLoudnessAudioProcessor()

    private val _videos = MutableStateFlow<List<VideoItem>>(emptyList())
    val videos: StateFlow<List<VideoItem>> = _videos.asStateFlow()

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private val initialAudioSettings = runBlocking { settingsStore.audioSettings.first() }
    private val initialPlayerPrefs = runBlocking { settingsStore.playerPrefs.first() }

    private val _audioSettings = MutableStateFlow(initialAudioSettings)
    val audioSettings: StateFlow<AudioNormalizationSettings> = _audioSettings.asStateFlow()

    private val _playerPrefs = MutableStateFlow(initialPlayerPrefs)
    val playerPrefs: StateFlow<PlayerPreferences> = _playerPrefs.asStateFlow()

    private val _playerInstance = MutableStateFlow(
        buildExoPlayer(initialPlayerPrefs.decoderMode, initialPlayerPrefs)
    )
    val playerInstance: StateFlow<ExoPlayer> = _playerInstance.asStateFlow()
    val exoPlayer: ExoPlayer get() = _playerInstance.value

    val telemetry: StateFlow<AudioTelemetry> = smartAudioProcessor.telemetry

    private var sleepDeadlineMs: Long? = null
    private var nextCountdownCancelled = false
    private var lastPositionSaveMs = 0L
    private var lastPlayPauseToggleMs = 0L

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.value = _uiState.value.copy(isPlaying = isPlaying)
            if (!isPlaying) persistCurrentPosition()
        }

        override fun onPlaybackStateChanged(state: Int) {
            _uiState.value = _uiState.value.copy(
                isBuffering = state == Player.STATE_BUFFERING,
                durationMs = exoPlayer.duration.coerceAtLeast(0L)
            )
            if (state == Player.STATE_ENDED) {
                clearFinishedPosition()
                if (_uiState.value.sleepAtEndOfEpisode) {
                    _uiState.value = _uiState.value.copy(sleepAtEndOfEpisode = false)
                    exoPlayer.pause()
                    return
                }
                val next = _uiState.value.nextEpisode
                if (_playerPrefs.value.autoPlayNextEpisode && next != null && !nextCountdownCancelled) {
                    playVideoItem(next)
                }
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            parseTracks(tracks)
        }

        override fun onPlayerError(error: PlaybackException) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Ошибка воспроизведения: ${error.localizedMessage ?: error.errorCodeName}"
            )
        }
    }

    init {
        exoPlayer.addListener(playerListener)

        smartAudioProcessor.updateSettings(initialAudioSettings)
        applyTrackAndVideoPreferences(exoPlayer, initialPlayerPrefs)

        viewModelScope.launch {
            while (true) {
                val state = _uiState.value
                if (state.currentUri != null) {
                    val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                    val dur = exoPlayer.duration.coerceAtLeast(0L)

                    var countdown: Int? = null
                    if (_playerPrefs.value.autoPlayNextEpisode &&
                        state.nextEpisode != null &&
                        !nextCountdownCancelled &&
                        dur > 30_000L &&
                        pos > 0L
                    ) {
                        val remainingSec = ((dur - pos) / 1000L).toInt()
                        if (remainingSec in 1..10) {
                            countdown = remainingSec
                        }
                    }

                    var sleepRemMin: Int? = null
                    val deadline = sleepDeadlineMs
                    if (deadline != null) {
                        val remMs = deadline - System.currentTimeMillis()
                        if (remMs <= 0L) {
                            sleepDeadlineMs = null
                            exoPlayer.pause()
                        } else {
                            sleepRemMin = ((remMs + 59_999L) / 60_000L).toInt()
                        }
                    }

                    _uiState.value = state.copy(
                        positionMs = pos,
                        durationMs = dur,
                        nextEpisodeCountdownSec = countdown,
                        sleepTimerRemainingMin = sleepRemMin
                    )

                    val now = System.currentTimeMillis()
                    if (exoPlayer.isPlaying && now - lastPositionSaveMs > 5000L) {
                        lastPositionSaveMs = now
                        persistCurrentPosition()
                    }
                }
                delay(500)
            }
        }
    }

    private fun buildExoPlayer(decoderMode: DecoderMode, prefs: PlayerPreferences = _playerPrefs.value): ExoPlayer {
        val app = getApplication<Application>()
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(6_000)
            .setReadTimeoutMs(8_000)
            .setUserAgent("AuraPlay/1.6.7 (Android TV)")
        val mediaSourceFactory = DefaultMediaSourceFactory(
            DefaultDataSource.Factory(app, httpFactory)
        )
        val fastLoadControl = DefaultLoadControl.Builder()
            .setTargetBufferBytes(16 * 1024 * 1024) // 16 MB RAM-safe cap for 1-1.5 GB TVs (MSD6683)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setBufferDurationsMs(
                10_000, // minBufferMs
                25_000, // maxBufferMs
                350,    // bufferForPlaybackMs: instant 1-2s stream startup!
                1_200   // bufferForPlaybackAfterRebufferMs
            )
            .build()
        val player = ExoPlayer.Builder(app)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(fastLoadControl)
            .setRenderersFactory(SmartAudioRenderersFactory(app, smartAudioProcessor, decoderMode))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .build()
        applyTrackAndVideoPreferences(player, prefs)
        return player
    }

    private fun applyTrackAndVideoPreferences(player: ExoPlayer, prefs: PlayerPreferences) {
        val paramsBuilder = player.trackSelectionParameters.buildUpon()
        if (prefs.alwaysBestQuality) {
            val maxW = if (android.os.Build.VERSION.SDK_INT <= android.os.Build.VERSION_CODES.P) 1920 else Int.MAX_VALUE
            val maxH = if (android.os.Build.VERSION.SDK_INT <= android.os.Build.VERSION_CODES.P) 1080 else Int.MAX_VALUE
            paramsBuilder
                .setForceHighestSupportedBitrate(true)
                .setMaxVideoSize(maxW, maxH)
                .setMaxVideoBitrate(Int.MAX_VALUE)
                .setMaxAudioBitrate(Int.MAX_VALUE)
        } else {
            paramsBuilder
                .setForceHighestSupportedBitrate(false)
                .clearVideoSizeConstraints()
                .setMaxVideoBitrate(Int.MAX_VALUE)
        }
        player.trackSelectionParameters = paramsBuilder.build()
        player.videoChangeFrameRateStrategy = if (prefs.autoFrameRate) {
            C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS
        } else {
            C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF
        }
    }

    private fun recreatePlayer(newDecoderMode: DecoderMode) {
        val oldPlayer = exoPlayer
        val curUri = _uiState.value.currentUri
        val curPos = oldPlayer.currentPosition.coerceAtLeast(0L)
        val wasPlaying = oldPlayer.playWhenReady

        oldPlayer.removeListener(playerListener)
        oldPlayer.release()

        val fresh = buildExoPlayer(newDecoderMode)
        fresh.addListener(playerListener)
        applyTrackAndVideoPreferences(fresh, _playerPrefs.value)
        _playerInstance.value = fresh

        if (curUri != null) {
            fresh.setMediaItem(MediaItem.fromUri(curUri))
            fresh.prepare()
            if (curPos > 0L) fresh.seekTo(curPos)
            fresh.playWhenReady = wasPlaying
        }
    }

    fun refreshLocalVideos() {
        viewModelScope.launch {
            _videos.value = LocalVideoRepository.loadDeviceVideos(getApplication())
        }
    }

    fun playVideoItem(item: VideoItem) {
        val existingPlaylist = _uiState.value.folderEpisodes
        val episodes = if (existingPlaylist.any { it.uri == item.uri }) {
            existingPlaylist
        } else {
            LocalVideoRepository.sortEpisodesNaturally(
                _videos.value.filter { it.folderName == item.folderName }
            )
        }
        val idx = episodes.indexOfFirst { it.uri == item.uri }
        val prevEp = if (idx > 0) episodes[idx - 1] else null
        val nextEp = if (idx >= 0 && idx + 1 < episodes.size) episodes[idx + 1] else null

        playMedia(
            uri = item.uri,
            title = item.title,
            launchedExternally = _uiState.value.launchedExternally,
            folderEpisodes = episodes,
            currentEpisodeIndex = idx,
            prevEpisode = prevEp,
            nextEpisode = nextEp
        )
    }

    fun playExternalWithPlaylist(
        uri: Uri,
        title: String,
        playlistUris: List<Uri>,
        playlistNames: List<String>
    ) {
        if (playlistUris.size > 1) {
            val episodes = playlistUris.mapIndexed { i, epUri ->
                VideoItem(
                    id = i.toLong() + 1L,
                    title = playlistNames.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Серия ${i + 1}",
                    uri = epUri,
                    durationMs = 0L,
                    sizeBytes = 0L,
                    folderName = "Плейлист",
                    mimeType = "video/*"
                )
            }
            val idx = episodes.indexOfFirst { it.uri == uri }.let { if (it >= 0) it else 0 }
            playMedia(
                uri = uri,
                title = episodes.getOrNull(idx)?.title ?: title,
                launchedExternally = true,
                folderEpisodes = episodes,
                currentEpisodeIndex = idx,
                prevEpisode = if (idx > 0) episodes[idx - 1] else null,
                nextEpisode = if (idx + 1 < episodes.size) episodes[idx + 1] else null
            )
        } else {
            playMedia(uri = uri, title = title, launchedExternally = true)
            if (uri.scheme !in listOf("http", "https", "rtsp")) viewModelScope.launch {
                val allVideos = _videos.value.ifEmpty {
                    LocalVideoRepository.loadDeviceVideos(getApplication()).also { _videos.value = it }
                }
                val matched = allVideos.firstOrNull {
                    it.uri == uri || it.title.equals(title, ignoreCase = true)
                }
                if (matched != null) {
                    val siblings = LocalVideoRepository.sortEpisodesNaturally(
                        allVideos.filter { it.folderName == matched.folderName }
                    )
                    if (siblings.size > 1) {
                        val idx = siblings.indexOfFirst { it.id == matched.id }
                        _uiState.value = _uiState.value.copy(
                            folderEpisodes = siblings,
                            currentEpisodeIndex = idx,
                            prevEpisode = if (idx > 0) siblings[idx - 1] else null,
                            nextEpisode = if (idx + 1 < siblings.size) siblings[idx + 1] else null
                        )
                    }
                }
            }
        }
    }

    fun playMedia(
        uri: Uri,
        title: String,
        launchedExternally: Boolean = false,
        folderEpisodes: List<VideoItem> = emptyList(),
        currentEpisodeIndex: Int = -1,
        prevEpisode: VideoItem? = null,
        nextEpisode: VideoItem? = null
    ) {
        persistCurrentPosition()
        nextCountdownCancelled = false

        _uiState.value = _uiState.value.copy(
            currentUri = uri,
            currentTitle = title,
            launchedExternally = launchedExternally,
            folderEpisodes = folderEpisodes,
            currentEpisodeIndex = currentEpisodeIndex,
            prevEpisode = prevEpisode,
            nextEpisode = nextEpisode,
            nextEpisodeCountdownSec = null,
            errorMessage = null
        )

        if (uri.scheme in listOf("http", "https", "rtsp")) {
            val existing = _playerPrefs.value.savedStreams
            val updated = (listOf(uri.toString()) + existing).distinct().take(15)
            updatePlayerPrefs(_playerPrefs.value.copy(savedStreams = updated))
        }

        applyTrackAndVideoPreferences(exoPlayer, _playerPrefs.value)
        exoPlayer.setMediaItem(MediaItem.fromUri(uri))
        exoPlayer.playWhenReady = true // Start immediately without waiting for DataStore I/O!
        exoPlayer.prepare()

        if (_playerPrefs.value.rememberPosition) {
            viewModelScope.launch {
                val savedPos = settingsStore.getSavedPosition(uri.toString())
                if (savedPos > 5_000L && _uiState.value.currentUri == uri) {
                    exoPlayer.seekTo(savedPos)
                }
            }
        }
    }

    fun playNextEpisode() {
        _uiState.value.nextEpisode?.let { playVideoItem(it) }
    }

    fun playPreviousEpisode() {
        _uiState.value.prevEpisode?.let { playVideoItem(it) }
    }

    fun cancelNextEpisodeCountdown() {
        nextCountdownCancelled = true
        _uiState.value = _uiState.value.copy(nextEpisodeCountdownSec = null)
    }

    /** Stops playback and returns to AuraPlay HomeScreen (only when explicitly requested). */
    fun closePlayerToHome() {
        persistCurrentPosition()
        exoPlayer.pause()
        exoPlayer.stop()
        _uiState.value = PlayerUiState()
    }

    /** Stops playback cleanly WITHOUT clearing currentUri so HomeScreen never flickers before finish(). */
    fun stopForExit() {
        persistCurrentPosition()
        exoPlayer.pause()
        exoPlayer.stop()
    }

    fun togglePlayPause() {
        val now = System.currentTimeMillis()
        if (now - lastPlayPauseToggleMs < 240L) return
        lastPlayPauseToggleMs = now
        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
    }

    fun seekTo(positionMs: Long) {
        val clamped = positionMs.coerceIn(0L, exoPlayer.duration.coerceAtLeast(0L))
        exoPlayer.seekTo(clamped)
        _uiState.value = _uiState.value.copy(positionMs = clamped)
    }

    fun seekBy(deltaMs: Long) {
        seekTo(exoPlayer.currentPosition + deltaMs)
    }

    fun setPlaybackSpeed(speed: Float) {
        exoPlayer.setPlaybackSpeed(speed)
        _uiState.value = _uiState.value.copy(playbackSpeed = speed)
    }

    fun setSleepTimerMinutes(minutes: Int?) {
        if (minutes == null) {
            sleepDeadlineMs = null
            _uiState.value = _uiState.value.copy(sleepTimerRemainingMin = null, sleepAtEndOfEpisode = false)
        } else if (minutes == -1) {
            sleepDeadlineMs = null
            _uiState.value = _uiState.value.copy(sleepTimerRemainingMin = null, sleepAtEndOfEpisode = true)
        } else {
            sleepDeadlineMs = System.currentTimeMillis() + minutes * 60_000L
            _uiState.value = _uiState.value.copy(sleepTimerRemainingMin = minutes, sleepAtEndOfEpisode = false)
        }
    }

    fun setNormalizationMode(mode: NormalizationMode) {
        applyAudioSettings(
            _audioSettings.value.copy(
                mode = mode,
                targetLufs = mode.defaultTargetLufs,
                maxBoostDb = mode.defaultMaxBoostDb
            )
        )
    }

    fun updateTargetLufs(lufs: Float) = applyAudioSettings(_audioSettings.value.copy(targetLufs = lufs))
    fun updateMaxBoostDb(maxBoost: Float) = applyAudioSettings(_audioSettings.value.copy(maxBoostDb = maxBoost))

    fun setDialogueBalancerEnabled(enabled: Boolean) =
        applyAudioSettings(_audioSettings.value.copy(dialogueBalancerEnabled = enabled))

    fun setDialogueBalancerStrength(strength: DialogueBalancerStrength) =
        applyAudioSettings(_audioSettings.value.copy(dialogueBalancerEnabled = true, dialogueBalancerStrength = strength))

    fun setEqEnabled(enabled: Boolean) = applyAudioSettings(_audioSettings.value.copy(eqEnabled = enabled))

    fun setEqPreset(preset: EqualizerPreset) {
        applyAudioSettings(
            _audioSettings.value.copy(
                eqEnabled = true,
                eqPreset = preset,
                eqBandsDb = preset.bandsDb
            )
        )
    }

    fun setEqBand(index: Int, gainDb: Float) {
        val bands = _audioSettings.value.eqBandsDb.toMutableList()
        if (index in bands.indices) {
            bands[index] = gainDb
            applyAudioSettings(
                _audioSettings.value.copy(
                    eqEnabled = true,
                    eqPreset = EqualizerPreset.CUSTOM,
                    eqBandsDb = bands
                )
            )
        }
    }

    private fun applyAudioSettings(settings: AudioNormalizationSettings) {
        _audioSettings.value = settings
        smartAudioProcessor.updateSettings(settings)
        viewModelScope.launch { settingsStore.saveAudioSettings(settings) }
    }

    fun updatePlayerPrefs(updated: PlayerPreferences) {
        val old = _playerPrefs.value
        _playerPrefs.value = updated
        viewModelScope.launch { settingsStore.savePlayerPrefs(updated) }

        if (old.decoderMode != updated.decoderMode) {
            recreatePlayer(updated.decoderMode)
        } else {
            applyTrackAndVideoPreferences(exoPlayer, updated)
        }
    }

    fun selectTrack(type: Int, option: TrackOption?) {
        val paramsBuilder = exoPlayer.trackSelectionParameters.buildUpon()
        if (option == null) {
            if (type == C.TRACK_TYPE_VIDEO) {
                paramsBuilder.clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                if (_playerPrefs.value.alwaysBestQuality) {
                    paramsBuilder.setForceHighestSupportedBitrate(true)
                }
            } else {
                paramsBuilder.setTrackTypeDisabled(type, true)
            }
        } else {
            paramsBuilder.setTrackTypeDisabled(type, false)
            val groups = exoPlayer.currentTracks.groups
            if (option.groupIndex in groups.indices) {
                val mediaGroup = groups[option.groupIndex].mediaTrackGroup
                paramsBuilder.setOverrideForType(
                    TrackSelectionOverride(mediaGroup, listOf(option.trackIndex))
                )
            }
        }
        exoPlayer.trackSelectionParameters = paramsBuilder.build()
    }

    private fun persistCurrentPosition() {
        val uri = _uiState.value.currentUri ?: return
        if (!_playerPrefs.value.rememberPosition) return
        val pos = exoPlayer.currentPosition
        val dur = exoPlayer.duration
        if (dur > 15_000L && pos > 5_000L && pos < dur * 0.95) {
            viewModelScope.launch { settingsStore.savePosition(uri.toString(), pos) }
        }
    }

    private fun clearFinishedPosition() {
        val uri = _uiState.value.currentUri ?: return
        viewModelScope.launch { settingsStore.savePosition(uri.toString(), 0L) }
    }

    private fun parseTracks(tracks: Tracks) {
        val videoList = mutableListOf<TrackOption>()
        val audioList = mutableListOf<TrackOption>()
        val subList = mutableListOf<TrackOption>()
        var vInfo = ""
        var aInfo = ""
        var details = MediaDetailedInfo()

        tracks.groups.forEachIndexed { gIdx, group ->
            for (tIdx in 0 until group.length) {
                val format = group.getTrackFormat(tIdx)
                val selected = group.isTrackSelected(tIdx)
                when (group.type) {
                    C.TRACK_TYPE_VIDEO -> {
                        val codec = format.sampleMimeType?.substringAfter("/")?.uppercase() ?: "VIDEO"
                        val br = if (format.bitrate > 0) " • ${format.bitrate / 1000} kbps" else ""
                        val fps = if (format.frameRate > 0f) " • ${format.frameRate.toInt()}fps" else ""
                        val label = "${format.width}x${format.height} ($codec$fps$br)"
                        videoList.add(TrackOption("v_${gIdx}_$tIdx", label, gIdx, tIdx, selected))
                        if (selected) {
                            vInfo = "$codec ${format.width}x${format.height}$fps"
                            details = details.copy(
                                resolution = if (format.width > 0) "${format.width} x ${format.height}" else "—",
                                videoCodec = "${format.sampleMimeType ?: "—"} (${format.codecs ?: codec})",
                                videoFps = if (format.frameRate > 0f) String.format(java.util.Locale.US, "%.2f fps", format.frameRate) else "—",
                                videoBitrate = if (format.bitrate > 0) "${format.bitrate / 1000} кбит/с" else "Авто / VBR"
                            )
                        }
                    }
                    C.TRACK_TYPE_AUDIO -> {
                        val lang = format.language?.uppercase() ?: "UND"
                        val ch = if (format.channelCount > 0) "${format.channelCount}ch" else ""
                        val codec = format.sampleMimeType?.substringAfter("/")?.uppercase() ?: "AUDIO"
                        val label = listOfNotNull(
                            format.label,
                            "$lang • $codec $ch".trim()
                        ).joinToString(" — ")
                        audioList.add(TrackOption("a_${gIdx}_$tIdx", label, gIdx, tIdx, selected))
                        if (selected) {
                            aInfo = "$codec ${format.sampleRate / 1000}kHz $ch".trim()
                            val chLabel = when (format.channelCount) {
                                1 -> "1.0 (Моно)"
                                2 -> "2.0 (Стерео)"
                                6 -> "5.1 (Объёмный)"
                                8 -> "7.1 (Объёмный)"
                                else -> if (format.channelCount > 0) "${format.channelCount} каналов" else "—"
                            }
                            details = details.copy(
                                audioCodec = "${format.sampleMimeType ?: "—"} (${format.codecs ?: codec})",
                                audioChannels = chLabel,
                                audioSampleRate = if (format.sampleRate > 0) "${format.sampleRate} Гц" else "—",
                                audioBitrate = if (format.bitrate > 0) "${format.bitrate / 1000} кбит/с" else "Авто / VBR",
                                audioLanguage = format.label ?: lang
                            )
                        }
                    }
                    C.TRACK_TYPE_TEXT -> {
                        val lang = format.language?.uppercase() ?: "SUB"
                        val label = format.label ?: "Субтитры ($lang)"
                        subList.add(TrackOption("s_${gIdx}_$tIdx", label, gIdx, tIdx, selected))
                    }
                }
            }
        }

        _uiState.value = _uiState.value.copy(
            videoTracks = videoList,
            audioTracks = audioList,
            subtitleTracks = subList,
            videoCodecInfo = vInfo,
            audioCodecInfo = aInfo,
            mediaDetails = details
        )
    }

    override fun onCleared() {
        super.onCleared()
        persistCurrentPosition()
        exoPlayer.release()
    }
}
