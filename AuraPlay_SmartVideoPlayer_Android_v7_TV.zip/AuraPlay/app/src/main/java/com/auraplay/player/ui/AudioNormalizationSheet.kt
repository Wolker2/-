package com.auraplay.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.auraplay.player.audio.AudioNormalizationSettings
import com.auraplay.player.audio.AudioTelemetry
import com.auraplay.player.audio.DialogueBalancerStrength
import com.auraplay.player.audio.EqualizerPreset
import com.auraplay.player.audio.NormalizationMode
import com.auraplay.player.ui.theme.tvFocusBorder
import java.util.Locale

@Composable
fun AudioNormalizationSheet(
    settings: AudioNormalizationSettings,
    telemetry: AudioTelemetry,
    onSelectMode: (NormalizationMode) -> Unit,
    onTargetLufsChange: (Float) -> Unit,
    onMaxBoostChange: (Float) -> Unit,
    onDialogueBalancerToggle: (Boolean) -> Unit,
    onDialogueBalancerStrength: (DialogueBalancerStrength) -> Unit,
    onEqEnabledChange: (Boolean) -> Unit,
    onEqPresetSelect: (EqualizerPreset) -> Unit,
    onEqBandChange: (Int, Float) -> Unit,
    onDismiss: () -> Unit
) {
    val bandLabels = listOf("60 Гц", "230 Гц", "910 Гц", "3.6 кГц", "14 кГц")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .widthIn(max = 760.dp)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Звук: Автобалансировка, Нормализация и EQ",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "32-bit Float PCM • ${telemetry.sampleRateHz / 1000} кГц • ${telemetry.channelCount}ch • LR4 + EBU R128 + Look-Ahead Limiter",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    TextButton(onClick = onDismiss, modifier = Modifier.tvFocusBorder()) {
                        Text("Закрыть")
                    }
                }

                Spacer(Modifier.height(10.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Live Telemetry Strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        TelemetryMetric("Громкость", String.format(Locale.US, "%.1f LUFS", telemetry.shortTermLufs))
                        TelemetryMetric(
                            "Усиление",
                            String.format(Locale.US, "%+.1f дБ", telemetry.appliedGainDb),
                            MaterialTheme.colorScheme.primary
                        )
                        TelemetryMetric(
                            "Лимитер",
                            String.format(Locale.US, "%.1f дБ", telemetry.limiterReductionDb),
                            if (telemetry.limiterReductionDb < -0.5f) Color(0xFFFFB74D) else MaterialTheme.colorScheme.onSurface
                        )
                        TelemetryMetric("True Peak", String.format(Locale.US, "%.1f дБ", telemetry.truePeakDbtp))
                    }

                    // Multiband Auto-Dialogue Balancer Card
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .tvFocusBorder()
                                .clickable { onDialogueBalancerToggle(!settings.dialogueBalancerEnabled) }
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                                Text(
                                    text = "Умная автобалансировка речи и эффектов",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                Text(
                                    text = "В экшен-сценах мягко прижимает взрывы, стрельбу и громкую музыку, удерживая речь ровной и разборчивой без резких перепадов",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = settings.dialogueBalancerEnabled,
                                onCheckedChange = onDialogueBalancerToggle
                            )
                        }

                        if (settings.dialogueBalancerEnabled) {
                            Spacer(Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                DialogueBalancerStrength.entries.forEach { st ->
                                    FilterChip(
                                        selected = settings.dialogueBalancerStrength == st,
                                        onClick = { onDialogueBalancerStrength(st) },
                                        label = { Text(st.titleRu) },
                                        modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                                    )
                                }
                            }
                        }
                    }

                    // EBU R128 Normalization Modes
                    Text(
                        text = "Режим автонормализации громкости",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    NormalizationMode.entries.forEach { mode ->
                        val isSelected = settings.mode == mode
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .tvFocusBorder()
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                )
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectMode(mode) }
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = mode.titleRu,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = mode.descriptionRu,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    if (settings.mode != NormalizationMode.BYPASS) {
                        Text(
                            text = String.format(Locale.US, "Целевая громкость: %.1f LUFS", settings.targetLufs),
                            style = MaterialTheme.typography.labelLarge
                        )
                        Slider(
                            value = settings.targetLufs,
                            onValueChange = onTargetLufsChange,
                            valueRange = -23.0f..-11.0f
                        )

                        Text(
                            text = String.format(Locale.US, "Макс. усиление тихих сцен: +%.1f дБ", settings.maxBoostDb),
                            style = MaterialTheme.typography.labelLarge
                        )
                        Slider(
                            value = settings.maxBoostDb,
                            onValueChange = onMaxBoostChange,
                            valueRange = 0.0f..18.0f
                        )
                    }

                    // 5-Band Parametric Equalizer
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .tvFocusBorder()
                            .clickable { onEqEnabledChange(!settings.eqEnabled) }
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "5-полосный эквалайзер (32-bit float)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Работает до лимитера — без клиппинга и искажений",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = settings.eqEnabled, onCheckedChange = onEqEnabledChange)
                    }

                    if (settings.eqEnabled) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            EqualizerPreset.entries.forEach { preset ->
                                FilterChip(
                                    selected = settings.eqPreset == preset,
                                    onClick = { onEqPresetSelect(preset) },
                                    label = { Text(preset.titleRu) },
                                    modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                                )
                            }
                        }
                        bandLabels.forEachIndexed { idx, label ->
                            val valDb = settings.eqBandsDb.getOrElse(idx) { 0f }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = String.format(Locale.US, "%-7s %+.1f", label, valDb),
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(end = 10.dp)
                                )
                                Slider(
                                    value = valDb,
                                    onValueChange = { onEqBandChange(idx, it) },
                                    valueRange = -6.0f..6.0f,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetric(
    label: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(2.dp))
        Text(value, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
