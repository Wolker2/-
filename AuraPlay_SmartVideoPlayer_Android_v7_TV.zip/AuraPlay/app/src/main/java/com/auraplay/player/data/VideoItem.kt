package com.auraplay.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoItem(
    val id: Long,
    val title: String,
    val uri: Uri,
    val durationMs: Long,
    val sizeBytes: Long,
    val folderName: String,
    val mimeType: String
)

object LocalVideoRepository {

    suspend fun loadDeviceVideos(context: Context): List<VideoItem> = withContext(Dispatchers.IO) {
        val videos = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

        runCatching {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    videos.add(
                        VideoItem(
                            id = id,
                            title = cursor.getString(nameCol) ?: "Видео #$id",
                            uri = uri,
                            durationMs = cursor.getLong(durCol),
                            sizeBytes = cursor.getLong(sizeCol),
                            folderName = cursor.getString(bucketCol) ?: "Внутренняя память",
                            mimeType = cursor.getString(mimeCol) ?: "video/*"
                        )
                    )
                }
            }
        }
        videos
    }

    /** Natural sorting for TV series episodes (S01E02 < S01E10, Episode 2 < Episode 10). */
    fun sortEpisodesNaturally(items: List<VideoItem>): List<VideoItem> {
        val regex = Regex("(\\d+|\\D+)")
        return items.sortedWith { a, b ->
            val aParts = regex.findAll(a.title.lowercase()).map { it.value }.toList()
            val bParts = regex.findAll(b.title.lowercase()).map { it.value }.toList()
            val len = minOf(aParts.size, bParts.size)
            for (i in 0 until len) {
                val ap = aParts[i]
                val bp = bParts[i]
                val an = ap.toLongOrNull()
                val bn = bp.toLongOrNull()
                val cmp = if (an != null && bn != null) an.compareTo(bn) else ap.compareTo(bp)
                if (cmp != 0) return@sortedWith cmp
            }
            aParts.size.compareTo(bParts.size)
        }
    }
}
