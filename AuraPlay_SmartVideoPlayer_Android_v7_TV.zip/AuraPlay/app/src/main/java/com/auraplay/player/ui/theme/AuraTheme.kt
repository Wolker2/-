package com.auraplay.player.ui.theme

import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

private val AuraDarkColors = darkColorScheme(
    primary = Color(0xFF4F9CFF),
    onPrimary = Color(0xFF001C3B),
    secondary = Color(0xFF38D9A9),
    onSecondary = Color(0xFF002117),
    background = Color(0xFF0D0F14),
    onBackground = Color(0xFFE8ECF4),
    surface = Color(0xFF151922),
    onSurface = Color(0xFFE8ECF4),
    surfaceVariant = Color(0xFF1F2533),
    onSurfaceVariant = Color(0xFF9BA5B7),
    error = Color(0xFFFF6B6B)
)

@Composable
fun AuraPlayTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AuraDarkColors,
        content = content
    )
}

/** High-contrast focus border for Android TV D-Pad navigation. */
fun Modifier.tvFocusBorder(
    shape: Shape = RoundedCornerShape(12.dp),
    focusedColor: Color = Color(0xFF6BB5FF)
): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    this
        .onFocusChanged { focused = it.isFocused }
        .border(
            width = if (focused) 2.5.dp else 0.dp,
            color = if (focused) focusedColor else Color.Transparent,
            shape = shape
        )
}
