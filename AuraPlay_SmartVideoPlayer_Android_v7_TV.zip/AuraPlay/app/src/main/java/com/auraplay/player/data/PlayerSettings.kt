package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение ТВ/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная экономия заряда, только системные кодеки"
    )
}

/**
 * Hardware OpenGL ES video enhancement presets via Media3 Effect (works on Android 8–16 on SurfaceView):
 * - contrastDelta: Contrast(-1.0 .. +1.0)
 * - saturationDelta: HslAdjustment saturation (-100 .. +100)
 * - lightnessDelta: HslAdjustment lightness (-100 .. +100)
 * - redScale / greenScale / blueScale: RgbAdjustment
 */
enum class PictureEnhanceMode(
    val titleRu: String,
    val descriptionRu: String,
    val contrastDelta: Float,
    val saturationDelta: Float,
    val lightnessDelta: Float,
    val redScale: Float,
    val greenScale: Float,
    val blueScale: Float
) {
    OFF("Отключить", "Оригинальная картинка без обработки (лучше для HDR)", 0f, 0f, 0f, 1.00f, 1.00f, 1.00f),
    ANIME("Аниме", "Сочные цвета, чёткие контуры и яркая палитра", 0.18f, 28f, 3f, 1.00f, 1.00f, 1.02f),
    MOVIE("Фильм", "Глубокий кино-контраст и тёплый кинематографичный оттенок", 0.15f, 10f, -2f, 1.04f, 1.00f, 0.94f),
    SERIES("Сериал", "Сбалансированная чёткость и читаемые тёмные сцены", 0.10f, 14f, 5f, 1.01f, 1.00f, 1.00f),
    EVERYDAY("Повседневное", "Мягкое естественное оживление картинки без перегибов", 0.08f, 10f, 2f, 1.00f, 1.00f, 1.00f)
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceMode: PictureEnhanceMode = PictureEnhanceMode.OFF,
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
