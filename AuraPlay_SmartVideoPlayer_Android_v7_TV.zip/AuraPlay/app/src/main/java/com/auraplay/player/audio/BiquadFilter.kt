package com.auraplay.player.audio

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class BiquadFilter(
    private val b0: Double,
    private val b1: Double,
    private val b2: Double,
    private val a1: Double,
    private val a2: Double
) {
    private var z1 = 0.0
    private var z2 = 0.0

    fun process(input: Double): Double {
        val output = b0 * input + z1
        z1 = b1 * input - a1 * output + z2
        z2 = b2 * input - a2 * output
        return output
    }

    fun reset() {
        z1 = 0.0
        z2 = 0.0
    }

    companion object {
        fun kWeightingPreFilter(sampleRate: Double): BiquadFilter {
            val dbGain = 3.999843853973347
            val f0 = 1681.974450955533
            val q = 0.7071752369554196
            val k = tan(PI * f0 / sampleRate)
            val vh = 10.0.pow(dbGain / 20.0)
            val vb = vh.pow(0.4996667741545416)
            val a0 = 1.0 + k / q + k * k
            val b0 = (vh + vb * k / q + k * k) / a0
            val b1 = 2.0 * (k * k - vh) / a0
            val b2 = (vh - vb * k / q + k * k) / a0
            val a1 = 2.0 * (k * k - 1.0) / a0
            val a2 = (1.0 - k / q + k * k) / a0
            return BiquadFilter(b0, b1, b2, a1, a2)
        }

        fun kWeightingRlbFilter(sampleRate: Double): BiquadFilter {
            val f0 = 38.13547087602444
            val q = 0.5003270373238773
            val k = tan(PI * f0 / sampleRate)
            val a0 = 1.0 + k / q + k * k
            val b0 = 1.0 / a0
            val b1 = -2.0 / a0
            val b2 = 1.0 / a0
            val a1 = 2.0 * (k * k - 1.0) / a0
            val a2 = (1.0 - k / q + k * k) / a0
            return BiquadFilter(b0, b1, b2, a1, a2)
        }

        fun butterworthLowPass(sampleRate: Double, freqHz: Double): BiquadFilter {
            val safeFreq = freqHz.coerceIn(20.0, sampleRate * 0.45)
            val omega = 2.0 * PI * safeFreq / sampleRate
            val sinW = sin(omega)
            val cosW = cos(omega)
            val alpha = sinW / (2.0 * (1.0 / sqrt(2.0)))
            val a0 = 1.0 + alpha
            val b0 = ((1.0 - cosW) * 0.5) / a0
            val b1 = (1.0 - cosW) / a0
            val b2 = ((1.0 - cosW) * 0.5) / a0
            val a1 = (-2.0 * cosW) / a0
            val a2 = (1.0 - alpha) / a0
            return BiquadFilter(b0, b1, b2, a1, a2)
        }

        fun butterworthHighPass(sampleRate: Double, freqHz: Double): BiquadFilter {
            val safeFreq = freqHz.coerceIn(20.0, sampleRate * 0.45)
            val omega = 2.0 * PI * safeFreq / sampleRate
            val sinW = sin(omega)
            val cosW = cos(omega)
            val alpha = sinW / (2.0 * (1.0 / sqrt(2.0)))
            val a0 = 1.0 + alpha
            val b0 = ((1.0 + cosW) * 0.5) / a0
            val b1 = -(1.0 + cosW) / a0
            val b2 = ((1.0 + cosW) * 0.5) / a0
            val a1 = (-2.0 * cosW) / a0
            val a2 = (1.0 - alpha) / a0
            return BiquadFilter(b0, b1, b2, a1, a2)
        }

        fun peakingEq(sampleRate: Double, freqHz: Double, q: Double, gainDb: Double): BiquadFilter {
            if (abs(gainDb) < 0.05) {
                return BiquadFilter(1.0, 0.0, 0.0, 0.0, 0.0)
            }
            val safeFreq = freqHz.coerceIn(20.0, sampleRate * 0.45)
            val a = 10.0.pow(gainDb / 40.0)
            val omega = 2.0 * PI * safeFreq / sampleRate
            val sinW = sin(omega)
            val cosW = cos(omega)
            val alpha = sinW / (2.0 * q)

            val a0 = 1.0 + alpha / a
            val b0 = (1.0 + alpha * a) / a0
            val b1 = (-2.0 * cosW) / a0
            val b2 = (1.0 - alpha * a) / a0
            val a1 = (-2.0 * cosW) / a0
            val a2 = (1.0 - alpha / a) / a0
            return BiquadFilter(b0, b1, b2, a1, a2)
        }
    }
}

/** Linkwitz-Riley 4th-order (24 dB/oct) cascaded filter: LP + HP sums flat to 0.00 dB. */
class LR4Filter(private val s1: BiquadFilter, private val s2: BiquadFilter) {
    fun process(input: Double): Double = s2.process(s1.process(input))
    fun reset() {
        s1.reset()
        s2.reset()
    }

    companion object {
        fun lowPass(sampleRate: Double, freqHz: Double) =
            LR4Filter(
                BiquadFilter.butterworthLowPass(sampleRate, freqHz),
                BiquadFilter.butterworthLowPass(sampleRate, freqHz)
            )

        fun highPass(sampleRate: Double, freqHz: Double) =
            LR4Filter(
                BiquadFilter.butterworthHighPass(sampleRate, freqHz),
                BiquadFilter.butterworthHighPass(sampleRate, freqHz)
            )
    }
}
