package com.auraplay.player.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

class SmartLoudnessAudioProcessorTest {

    @Test
    fun bypassMode_isBitExact() {
        val processor = SmartLoudnessAudioProcessor()
        processor.updateSettings(
            AudioNormalizationSettings(
                mode = NormalizationMode.BYPASS,
                dialogueBalancerEnabled = false,
                eqEnabled = false
            )
        )
        processor.configure(AudioProcessor.AudioFormat(48000, 2, C.ENCODING_PCM_FLOAT))
        processor.flush(AudioProcessor.StreamMetadata.DEFAULT)

        val samples = floatArrayOf(0.125f, -0.25f, 0.5f, -0.75f, 0.001f, -0.002f)
        val input = ByteBuffer.allocateDirect(samples.size * 4).order(ByteOrder.nativeOrder())
        samples.forEach { input.putFloat(it) }
        input.flip()

        processor.queueInput(input)
        val out = processor.output
        assertEquals(samples.size * 4, out.remaining())
        for (expected in samples) {
            assertEquals(expected, out.float, 0.0f)
        }
    }

    @Test
    fun actionSceneWithDialogueBalancerAndEq_neverClips() {
        val processor = SmartLoudnessAudioProcessor()
        processor.updateSettings(
            AudioNormalizationSettings(
                mode = NormalizationMode.STUDIO,
                targetLufs = -16.0f,
                maxBoostDb = 9.0f,
                truePeakCeilingDb = -1.0f,
                dialogueBalancerEnabled = true,
                dialogueBalancerStrength = DialogueBalancerStrength.STRONG,
                eqEnabled = true,
                eqPreset = EqualizerPreset.CINEMA,
                eqBandsDb = EqualizerPreset.CINEMA.bandsDb
            )
        )
        val sr = 48000
        processor.configure(AudioProcessor.AudioFormat(sr, 2, C.ENCODING_PCM_FLOAT))
        processor.flush(AudioProcessor.StreamMetadata.DEFAULT)

        // Mix loud 80 Hz explosion + 1.2 kHz voice + 6 kHz gunfire
        val frames = sr / 2
        val input = ByteBuffer.allocateDirect(frames * 2 * 4).order(ByteOrder.nativeOrder())
        for (i in 0 until frames) {
            val bass = 0.8 * sin(2.0 * PI * 80.0 * i / sr)
            val voice = 0.25 * sin(2.0 * PI * 1200.0 * i / sr)
            val high = 0.35 * sin(2.0 * PI * 6000.0 * i / sr)
            val l = (bass + voice + high).toFloat()
            val r = (bass + voice - high).toFloat()
            input.putFloat(l)
            input.putFloat(r)
        }
        input.flip()

        processor.queueInput(input)
        val out = processor.output
        var maxPeak = 0.0f
        while (out.hasRemaining()) {
            val v = abs(out.float)
            if (v > maxPeak) maxPeak = v
        }
        assertTrue("Output peak $maxPeak exceeded -1.0 dBTP ceiling", maxPeak <= 0.90f)
    }

    @Test
    fun silenceGate_doesNotAmplifyNoiseFloor() {
        val processor = SmartLoudnessAudioProcessor()
        processor.updateSettings(
            AudioNormalizationSettings(
                mode = NormalizationMode.NIGHT,
                dialogueBalancerEnabled = true
            )
        )
        val sr = 48000
        processor.configure(AudioProcessor.AudioFormat(sr, 2, C.ENCODING_PCM_FLOAT))
        processor.flush(AudioProcessor.StreamMetadata.DEFAULT)

        val frames = sr / 2
        val input = ByteBuffer.allocateDirect(frames * 2 * 4).order(ByteOrder.nativeOrder())
        for (i in 0 until frames) {
            val s = (0.00018 * sin(2.0 * PI * 440.0 * i / sr)).toFloat()
            input.putFloat(s)
            input.putFloat(s)
        }
        input.flip()

        processor.queueInput(input)
        val out = processor.output
        var maxPeak = 0.0f
        while (out.hasRemaining()) {
            val v = abs(out.float)
            if (v > maxPeak) maxPeak = v
        }
        assertTrue("Silence gate amplified noise floor to $maxPeak", maxPeak < 0.001f)
    }
}
