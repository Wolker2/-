package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение телевизора/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная плавность и стабильность, только встроенные кодеки устройства"
    )
}

/**
 * Native Android picture enhancement presets (zero heavy external OpenGL pipelines).
 * Uses built-in Android ColorMatrix/RenderEffect when enabled, and pure SurfaceView when OFF.
 */
enum class PictureEnhanceMode(
    val titleRu: String,
    val descriptionRu: String,
    val contrast: Float,
    val saturation: Float,
    val brightnessOffset: Float,
    val redScale: Float,
    val blueScale: Float
) {
    OFF(
        "Отключить",
        "Чистая оригинальная картинка напрямую через аппаратный движок телевизора (лучше для HDR и максимальной стабильности)",
        1.00f, 1.00f, 0f, 1.00f, 1.00f
    ),
    ANIME(
        "Аниме",
        "Сочные чистые цвета и живая палитра без провала деталей в тенях",
        1.07f, 1.18f, 3f, 1.00f, 1.01f
    ),
    ANIME_2(
        "Аниме 2",
        "Повышенная чёткость контуров и читаемость мелких деталей с аккуратным естественным цветом",
        1.12f, 1.08f, 4f, 1.00f, 1.00f
    ),
    BALANCE(
        "Баланс",
        "Слегка осветляет слишком тёмные сцены и мягко приглушает чрезмерно яркие участки без резких перепадов",
        0.92f, 1.06f, 10f, 1.00f, 1.00f
    )
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceMode: PictureEnhanceMode = PictureEnhanceMode.OFF,
    val autoFrameRate: Boolean = false,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
