package com.auraplay.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.auraplay.player.data.DecoderMode
import com.auraplay.player.data.PictureEnhanceMode
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.data.SubtitleSize
import com.auraplay.player.ui.theme.tvFocusBorder

@Composable
fun SettingsSheet(
    prefs: PlayerPreferences,
    uiState: PlayerUiState,
    isInsidePlayer: Boolean,
    onUpdatePrefs: (PlayerPreferences) -> Unit,
    onSleepTimerSelect: (Int?) -> Unit,
    onOpenAudioSheet: () -> Unit,
    onGoToHomeLibrary: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .widthIn(max = 760.dp)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Настройки AuraPlay",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onDismiss, modifier = Modifier.tvFocusBorder()) {
                        Text("Закрыть")
                    }
                }

                Spacer(Modifier.height(10.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                onDismiss()
                                onOpenAudioSheet()
                            },
                            modifier = Modifier.weight(1f).tvFocusBorder()
                        ) {
                            Text("Звук, Автобаланс и EQ")
                        }
                        if (isInsidePlayer) {
                            OutlinedButton(
                                onClick = {
                                    onDismiss()
                                    onGoToHomeLibrary()
                                },
                                modifier = Modifier.weight(1f).tvFocusBorder()
                            ) {
                                Text("Библиотека AuraPlay")
                            }
                        }
                    }

                    // Low-end Android TV Stability Mode
                    SectionHeader("Производительность Android TV")

                    ToggleRow(
                        title = "Режим для слабого Android TV (Макс. плавность)",
                        subtitle = "Отключает GPU-фильтры картинки и тяжёлый DSP, включает аппаратный HW-декодер и 16-bit AudioTrack для идеально плавной работы на любом ТВ",
                        checked = prefs.lowEndTvMode,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(lowEndTvMode = it)) }
                    )

                    // Quality & Picture Enhancement Presets
                    SectionHeader("Качество видео и улучшение картинки")

                    ToggleRow(
                        title = "Всегда максимальное качество",
                        subtitle = "Автоматически выбирать наилучшее разрешение и битрейт в потоках (HLS/DASH) и файлах",
                        checked = prefs.alwaysBestQuality,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(alwaysBestQuality = it)) }
                    )

                    Text(
                        text = "Авто-улучшение картинки: ${prefs.pictureEnhanceMode.titleRu}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = prefs.pictureEnhanceMode.descriptionRu,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PictureEnhanceMode.entries.forEach { mode ->
                            FilterChip(
                                selected = prefs.pictureEnhanceMode == mode,
                                onClick = { onUpdatePrefs(prefs.copy(pictureEnhanceMode = mode)) },
                                label = { Text(mode.titleRu) },
                                modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                            )
                        }
                    }

                    ToggleRow(
                        title = "Автоподстройка частоты кадров (AFR)",
                        subtitle = "Подгонять герцовку экрана под FPS фильма для плавности",
                        checked = prefs.autoFrameRate,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(autoFrameRate = it)) }
                    )

                    // Codecs / Decoders
                    SectionHeader("Видео и аудио кодеки (Декодер)")
                    DecoderMode.entries.forEach { mode ->
                        val selected = prefs.decoderMode == mode
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .tvFocusBorder()
                                .background(
                                    if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                )
                                .clickable { onUpdatePrefs(prefs.copy(decoderMode = mode)) }
                                .padding(10.dp)
                        ) {
                            Text(
                                text = mode.titleRu,
                                style = MaterialTheme.typography.titleSmall,
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = mode.descriptionRu,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Playback & TV Remote
                    SectionHeader("Воспроизведение и пульт ТВ")

                    ToggleRow(
                        title = "Автозапуск следующей серии",
                        subtitle = "Автоматически переключаться на следующую серию в папке",
                        checked = prefs.autoPlayNextEpisode,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(autoPlayNextEpisode = it)) }
                    )

                    ToggleRow(
                        title = "Запоминать позицию просмотра",
                        subtitle = "Продолжать фильм с того места, где остановились",
                        checked = prefs.rememberPosition,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(rememberPosition = it)) }
                    )

                    ToggleRow(
                        title = "Кнопка «Назад» открывает библиотеку",
                        subtitle = "Если выкл — «Назад» на пульте сразу выходит в предыдущее приложение без мелькания",
                        checked = prefs.backReturnsToHome,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(backReturnsToHome = it)) }
                    )

                    Text("Шаг перемотки с пульта / двойного тапа", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 10, 15, 30).forEach { sec ->
                            FilterChip(
                                selected = prefs.seekStepSeconds == sec,
                                onClick = { onUpdatePrefs(prefs.copy(seekStepSeconds = sec)) },
                                label = { Text("${sec}с") },
                                modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                            )
                        }
                    }

                    // Sleep Timer
                    SectionHeader("Таймер сна")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val timers = listOf(null to "Выкл", 15 to "15м", 30 to "30м", 60 to "60м", -1 to "Конец серии")
                        timers.forEach { (minVal, label) ->
                            val isSel = when (minVal) {
                                null -> uiState.sleepTimerRemainingMin == null && !uiState.sleepAtEndOfEpisode
                                -1 -> uiState.sleepAtEndOfEpisode
                                else -> uiState.sleepTimerRemainingMin == minVal
                            }
                            FilterChip(
                                selected = isSel,
                                onClick = { onSleepTimerSelect(minVal) },
                                label = { Text(label) },
                                modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                            )
                        }
                    }

                    // Subtitles
                    SectionHeader("Субтитры")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SubtitleSize.entries.forEach { sz ->
                            FilterChip(
                                selected = prefs.subtitleSize == sz,
                                onClick = { onUpdatePrefs(prefs.copy(subtitleSize = sz)) },
                                label = { Text(sz.titleRu) },
                                modifier = Modifier.tvFocusBorder(RoundedCornerShape(8.dp))
                            )
                        }
                    }

                    ToggleRow(
                        title = "Тёмная подложка субтитров",
                        subtitle = "Улучшает читаемость субтитров на светлых сценах",
                        checked = prefs.subtitleBackground,
                        onCheckedChange = { onUpdatePrefs(prefs.copy(subtitleBackground = it)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 6.dp)
    )
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .tvFocusBorder()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 6.dp, horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
