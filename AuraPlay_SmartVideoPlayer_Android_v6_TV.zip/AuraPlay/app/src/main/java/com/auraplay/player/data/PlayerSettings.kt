package com.auraplay.player.data

enum class DecoderMode(val titleRu: String, val descriptionRu: String) {
    AUTO_HYBRID(
        "Аппаратный + FFmpeg (Авто)",
        "Аппаратное ускорение ТВ/телефона + FFmpeg для редких форматов"
    ),
    PREFER_FFMPEG(
        "Приоритет FFmpeg (Программный)",
        "Декодирует через FFmpeg/dav1d, если аппаратный кодек даёт артефакты"
    ),
    HARDWARE_ONLY(
        "Только аппаратный (HW)",
        "Максимальная экономия заряда, только системные кодеки"
    )
}

enum class PictureEnhanceMode(
    val titleRu: String,
    val descriptionRu: String,
    val contrast: Float,
    val saturation: Float,
    val brightnessOffset: Float,
    val redScale: Float,
    val blueScale: Float
) {
    OFF("Отключить", "Оригинальная картинка без обработки (лучше для HDR)", 1.00f, 1.00f, 0f, 1.00f, 1.00f),
    ANIME("Аниме", "Сочные цвета, чёткие контуры и живая палитра", 1.12f, 1.24f, 4f, 1.00f, 1.02f),
    MOVIE("Фильм", "Глубокий кино-контраст и тёплый оттенок", 1.10f, 1.08f, -2f, 1.03f, 0.96f),
    SERIES("Сериал", "Сбалансированная чёткость и читаемые тёмные сцены", 1.06f, 1.10f, 6f, 1.01f, 1.00f),
    EVERYDAY("Повседневное", "Мягкое естественное улучшение без перегибов", 1.04f, 1.06f, 2f, 1.00f, 1.00f)
}

enum class SubtitleSize(val titleRu: String, val scale: Float) {
    SMALL("Мелкий", 0.8f),
    NORMAL("Обычный", 1.0f),
    LARGE("Крупный (ТВ)", 1.3f),
    EXTRA_LARGE("Очень крупный", 1.6f)
}

data class PlayerPreferences(
    val backReturnsToHome: Boolean = false,
    val autoPlayNextEpisode: Boolean = true,
    val rememberPosition: Boolean = true,
    val alwaysBestQuality: Boolean = true,
    val pictureEnhanceMode: PictureEnhanceMode = PictureEnhanceMode.OFF,
    val autoFrameRate: Boolean = true,
    val decoderMode: DecoderMode = DecoderMode.AUTO_HYBRID,
    val seekStepSeconds: Int = 10,
    val subtitleSize: SubtitleSize = SubtitleSize.LARGE,
    val subtitleBackground: Boolean = true,
    val savedStreams: List<String> = emptyList()
)
