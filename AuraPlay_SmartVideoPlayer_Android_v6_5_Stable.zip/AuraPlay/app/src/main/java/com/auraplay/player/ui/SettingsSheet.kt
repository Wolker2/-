package com.auraplay.player.ui

import android.view.KeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.auraplay.player.data.DecoderMode
import com.auraplay.player.data.PlayerPreferences
import com.auraplay.player.data.SubtitleSize
import com.auraplay.player.ui.theme.tvFocusBorder

internal data class ChoiceOption(
    val title: String,
    val description: String,
    val isSelected: Boolean,
    val onSelect: () -> Unit
)

internal data class ChoiceDialogState(
    val title: String,
    val options: List<ChoiceOption>
)

@Composable
fun SettingsSheet(
    prefs: PlayerPreferences,
    uiState: PlayerUiState,
    isInsidePlayer: Boolean,
    onUpdatePrefs: (PlayerPreferences) -> Unit,
    onSleepTimerSelect: (Int?) -> Unit,
    onOpenAudioSheet: () -> Unit,
    onGoToHomeLibrary: () -> Unit,
    onDismiss: () -> Unit
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }

    var activeSubMenu by remember { mutableStateOf<ChoiceDialogState?>(null) }

    val seekSteps = listOf(5, 10, 15, 30)
    val sleepOptions = listOf(
        Triple(null, "Выкл", "Таймер сна отключён"),
        Triple(15, "15 мин", "Поставит видео на паузу через 15 минут"),
        Triple(30, "30 мин", "Поставит видео на паузу через 30 минут"),
        Triple(60, "60 мин", "Поставит видео на паузу через 1 час"),
        Triple(-1, "Конец серии", "Остановит воспроизведение сразу после окончания текущей серии")
    )
    val currentSleepIdx = sleepOptions.indexOfFirst { (v, _, _) ->
        when (v) {
            null -> uiState.sleepTimerRemainingMin == null && !uiState.sleepAtEndOfEpisode
            -1 -> uiState.sleepAtEndOfEpisode
            else -> uiState.sleepTimerRemainingMin == v
        }
    }.coerceAtLeast(0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.86f)
                .widthIn(max = 720.dp)
                .fillMaxHeight(0.86f),
            shape = RoundedCornerShape(20.dp),
            color = if (prefs.transparentMenu) Color(0x990D111A) else MaterialTheme.colorScheme.surface,
            tonalElevation = if (prefs.transparentMenu) 0.dp else 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "Настройки AuraPlay",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "▲▼ выбор • ◄► быстро переключить • OK открыть подробный список • Назад закрыть",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )

                Spacer(Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        TvActionRow(
                            title = "Звук: Автобалансировка, Нормализация и Эквалайзер",
                            valueText = "Открыть →",
                            modifier = Modifier.focusRequester(firstFocus),
                            onClick = {
                                onDismiss()
                                onOpenAudioSheet()
                            }
                        )
                    }

                    if (isInsidePlayer) {
                        item {
                            TvActionRow(
                                title = "Открыть библиотеку AuraPlay",
                                valueText = "Перейти →",
                                onClick = {
                                    onDismiss()
                                    onGoToHomeLibrary()
                                }
                            )
                        }
                    }

                    item { TvSectionHeader("Видео и картинка") }

                    item {
                        TvToggleRow(
                            title = "Улучшение картинки",
                            subtitle = "Увеличивает чёткость, резкость и сочность цветов (зелень и детали заметно живее)",
                            checked = prefs.pictureEnhanceEnabled,
                            onToggle = { onUpdatePrefs(prefs.copy(pictureEnhanceEnabled = it)) }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Прозрачное окно меню",
                            subtitle = "Полупрозрачный фон настроек, чтобы сразу видеть изменения картинки за окном",
                            checked = prefs.transparentMenu,
                            onToggle = { onUpdatePrefs(prefs.copy(transparentMenu = it)) }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Всегда максимальное качество",
                            subtitle = "Автовыбор наилучшего разрешения и битрейта в потоках и файлах",
                            checked = prefs.alwaysBestQuality,
                            onToggle = { onUpdatePrefs(prefs.copy(alwaysBestQuality = it)) }
                        )
                    }

                    item {
                        val decs = DecoderMode.entries
                        val curIdx = decs.indexOf(prefs.decoderMode).coerceAtLeast(0)
                        TvStepperRow(
                            title = "Видео и аудио декодер",
                            subtitle = prefs.decoderMode.descriptionRu,
                            valueText = prefs.decoderMode.titleRu,
                            onPrev = {
                                val next = decs[(curIdx - 1 + decs.size) % decs.size]
                                onUpdatePrefs(prefs.copy(decoderMode = next))
                            },
                            onNext = {
                                val next = decs[(curIdx + 1) % decs.size]
                                onUpdatePrefs(prefs.copy(decoderMode = next))
                            },
                            onOpenDetails = {
                                activeSubMenu = ChoiceDialogState(
                                    title = "Выбор видео и аудио декодера",
                                    options = decs.map { d ->
                                        ChoiceOption(
                                            title = d.titleRu,
                                            description = d.descriptionRu,
                                            isSelected = d == prefs.decoderMode,
                                            onSelect = {
                                                onUpdatePrefs(prefs.copy(decoderMode = d))
                                                activeSubMenu = null
                                            }
                                        )
                                    }
                                )
                            }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Автоподстройка частоты кадров (AFR)",
                            subtitle = "Подгонять герцовку экрана под FPS видео (отключено по умолчанию для плавности)",
                            checked = prefs.autoFrameRate,
                            onToggle = { onUpdatePrefs(prefs.copy(autoFrameRate = it)) }
                        )
                    }

                    item { TvSectionHeader("Воспроизведение и пульт ТВ") }

                    item {
                        TvToggleRow(
                            title = "Автозапуск следующей серии",
                            subtitle = "Автоматически переходить к следующей серии в плейлисте/папке",
                            checked = prefs.autoPlayNextEpisode,
                            onToggle = { onUpdatePrefs(prefs.copy(autoPlayNextEpisode = it)) }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Запоминать позицию просмотра",
                            subtitle = "Продолжать видео с места остановки",
                            checked = prefs.rememberPosition,
                            onToggle = { onUpdatePrefs(prefs.copy(rememberPosition = it)) }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Кнопка «Назад» открывает библиотеку",
                            subtitle = "Если выкл — «Назад» сразу выходит в предыдущее приложение без мелькания",
                            checked = prefs.backReturnsToHome,
                            onToggle = { onUpdatePrefs(prefs.copy(backReturnsToHome = it)) }
                        )
                    }

                    item {
                        val curIdx = seekSteps.indexOf(prefs.seekStepSeconds).coerceAtLeast(0)
                        TvStepperRow(
                            title = "Шаг перемотки с пульта",
                            subtitle = "Базовый шаг при нажатии Влево / Вправо",
                            valueText = "${prefs.seekStepSeconds} сек",
                            onPrev = {
                                val next = seekSteps[(curIdx - 1 + seekSteps.size) % seekSteps.size]
                                onUpdatePrefs(prefs.copy(seekStepSeconds = next))
                            },
                            onNext = {
                                val next = seekSteps[(curIdx + 1) % seekSteps.size]
                                onUpdatePrefs(prefs.copy(seekStepSeconds = next))
                            },
                            onOpenDetails = {
                                activeSubMenu = ChoiceDialogState(
                                    title = "Шаг перемотки с пульта",
                                    options = seekSteps.map { sec ->
                                        ChoiceOption(
                                            title = "$sec секунд",
                                            description = "Одиночное нажатие Влево/Вправо перематывает на $sec сек (при удержании ускоряется)",
                                            isSelected = sec == prefs.seekStepSeconds,
                                            onSelect = {
                                                onUpdatePrefs(prefs.copy(seekStepSeconds = sec))
                                                activeSubMenu = null
                                            }
                                        )
                                    }
                                )
                            }
                        )
                    }

                    item {
                        TvStepperRow(
                            title = "Таймер сна",
                            subtitle = sleepOptions[currentSleepIdx].third,
                            valueText = sleepOptions[currentSleepIdx].second,
                            onPrev = {
                                val next = sleepOptions[(currentSleepIdx - 1 + sleepOptions.size) % sleepOptions.size]
                                onSleepTimerSelect(next.first)
                            },
                            onNext = {
                                val next = sleepOptions[(currentSleepIdx + 1) % sleepOptions.size]
                                onSleepTimerSelect(next.first)
                            },
                            onOpenDetails = {
                                activeSubMenu = ChoiceDialogState(
                                    title = "Таймер сна",
                                    options = sleepOptions.mapIndexed { idx, (minVal, title, desc) ->
                                        ChoiceOption(
                                            title = title,
                                            description = desc,
                                            isSelected = idx == currentSleepIdx,
                                            onSelect = {
                                                onSleepTimerSelect(minVal)
                                                activeSubMenu = null
                                            }
                                        )
                                    }
                                )
                            }
                        )
                    }

                    item { TvSectionHeader("Субтитры") }

                    item {
                        val sizes = SubtitleSize.entries
                        val curIdx = sizes.indexOf(prefs.subtitleSize).coerceAtLeast(0)
                        TvStepperRow(
                            title = "Размер шрифта субтитров",
                            subtitle = "Удобный размер для чтения с телевизора",
                            valueText = prefs.subtitleSize.titleRu,
                            onPrev = {
                                val next = sizes[(curIdx - 1 + sizes.size) % sizes.size]
                                onUpdatePrefs(prefs.copy(subtitleSize = next))
                            },
                            onNext = {
                                val next = sizes[(curIdx + 1) % sizes.size]
                                onUpdatePrefs(prefs.copy(subtitleSize = next))
                            },
                            onOpenDetails = {
                                activeSubMenu = ChoiceDialogState(
                                    title = "Размер шрифта субтитров",
                                    options = sizes.map { sz ->
                                        ChoiceOption(
                                            title = sz.titleRu,
                                            description = "Масштаб шрифта ${(sz.scale * 100).toInt()}%",
                                            isSelected = sz == prefs.subtitleSize,
                                            onSelect = {
                                                onUpdatePrefs(prefs.copy(subtitleSize = sz))
                                                activeSubMenu = null
                                            }
                                        )
                                    }
                                )
                            }
                        )
                    }

                    item {
                        TvToggleRow(
                            title = "Тёмная подложка субтитров",
                            subtitle = "Улучшает читаемость на светлых сценах",
                            checked = prefs.subtitleBackground,
                            onToggle = { onUpdatePrefs(prefs.copy(subtitleBackground = it)) }
                        )
                    }

                    item {
                        Spacer(Modifier.height(6.dp))
                        TvActionRow(
                            title = "Закрыть настройки",
                            valueText = "OK",
                            onClick = onDismiss
                        )
                    }
                }
            }
        }
    }

    activeSubMenu?.let { menu ->
        TvChoiceSubMenuDialog(
            state = menu,
            onDismiss = { activeSubMenu = null }
        )
    }
}

@Composable
internal fun TvChoiceSubMenuDialog(
    state: ChoiceDialogState,
    onDismiss: () -> Unit
) {
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.80f)
                .widthIn(max = 640.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 10.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                Text(
                    text = state.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "▲▼ выбор • OK применить • Назад вернуться",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(Modifier.height(12.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(state.options) { idx, opt ->
                        var focused by remember { mutableStateOf(false) }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(if (idx == 0) Modifier.focusRequester(firstFocus) else Modifier)
                                .clip(RoundedCornerShape(12.dp))
                                .onFocusChanged { focused = it.isFocused }
                                .tvFocusBorder(RoundedCornerShape(12.dp))
                                .background(
                                    when {
                                        focused -> MaterialTheme.colorScheme.primary.copy(alpha = 0.24f)
                                        opt.isSelected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                                        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                    }
                                )
                                .border(
                                    width = if (opt.isSelected) 1.5.dp else 0.dp,
                                    color = if (opt.isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable(onClick = opt.onSelect)
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = opt.isSelected,
                                onClick = null,
                                modifier = Modifier.focusProperties { canFocus = false }
                            )
                            Column(modifier = Modifier.weight(1f).padding(start = 10.dp)) {
                                Text(
                                    text = opt.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (opt.isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                if (opt.description.isNotBlank()) {
                                    Text(
                                        text = opt.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun TvSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp, start = 4.dp)
    )
}

@Composable
internal fun TvActionRow(
    title: String,
    valueText: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
    }
}

@Composable
internal fun TvToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    modifier: Modifier = Modifier,
    onToggle: (Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            )
            .onPreviewKeyEvent { ev ->
                if (ev.type == KeyEventType.KeyDown &&
                    (ev.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_LEFT || ev.nativeKeyEvent.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
                ) {
                    onToggle(!checked)
                    true
                } else false
            }
            .clickable { onToggle(!checked) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = null,
            modifier = Modifier.focusProperties { canFocus = false }
        )
    }
}

@Composable
internal fun TvStepperRow(
    title: String,
    subtitle: String,
    valueText: String,
    modifier: Modifier = Modifier,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onOpenDetails: (() -> Unit)? = null
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .background(
                if (focused) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            )
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (ev.nativeKeyEvent.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        onPrev()
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        onNext()
                        true
                    }
                    else -> false
                }
            }
            .clickable { (onOpenDetails ?: onNext)() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(
            text = "◄  $valueText  ►",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = if (focused) Color.White else MaterialTheme.colorScheme.primary
        )
    }
}
